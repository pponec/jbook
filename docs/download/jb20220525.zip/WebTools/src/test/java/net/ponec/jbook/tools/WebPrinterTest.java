package net.ponec.jbook.tools;

import org.ujorm.tools.xml.model.XmlModel;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Pavel Ponec
 */
public class WebPrinterTest {

    /**
     * Test of write method, of class WebPrinter.
     */
    @Test
    public void testWrite_value() {
        System.out.println("write");
        CharSequence label = "Label";
        WebPrinter instance = createInstance();

        instance.write(1, label);
        instance.write((Integer) 1, label);
        instance.write("1", label);

        String expResult = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                + "<table class=\"numbers printer\">\n"
                + "<tr>\n"
                + "<th>#</th>\n"
                + "<th>Expression / Statement</th>\n"
                + "<th>Result</th>\n"
                + "<th class=\"dataType\">Type</th></tr>\n"
                + "<tr>\n"
                + "<td>1.</td>\n"
                + "<td>Label</td>\n"
                + "<td>1</td>\n"
                + "<td class=\"dataType\">int</td></tr>\n"
                + "<tr>\n"
                + "<td>2.</td>\n"
                + "<td>Label</td>\n"
                + "<td>1</td>\n"
                + "<td class=\"dataType\">java.lang.Integer</td></tr>\n"
                + "<tr>\n"
                + "<td>3.</td>\n"
                + "<td>Label</td>\n"
                + "<td>1</td>\n"
                + "<td class=\"dataType\">java.lang.String</td></tr></table>";
        assertEquals(expResult, instance.toString());
    }

    /**
     * Test of write method, of class WebPrinter.
     */
    @Test
    public void testWrite_array() {
        System.out.println("write");
        CharSequence label = "Label";
        WebPrinter instance = createInstance();

        instance.write(new int[]{1, 2}, label);
        instance.write(new Integer[]{1, 2}, label);
        instance.write(new String[]{"1", "2"}, label);

        String expResult = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                + "<table class=\"numbers printer\">\n"
                + "<tr>\n"
                + "<th>#</th>\n"
                + "<th>Expression / Statement</th>\n"
                + "<th>Result</th>\n"
                + "<th class=\"dataType\">Type</th></tr>\n"
                + "<tr>\n"
                + "<td>1.</td>\n"
                + "<td>Label</td>\n"
                + "<td>1, 2</td>\n"
                + "<td class=\"dataType\">int[]</td></tr>\n"
                + "<tr>\n"
                + "<td>2.</td>\n"
                + "<td>Label</td>\n"
                + "<td>1, 2</td>\n"
                + "<td class=\"dataType\">java.lang.Integer[]</td></tr>\n"
                + "<tr>\n"
                + "<td>3.</td>\n"
                + "<td>Label</td>\n"
                + "<td>1, 2</td>\n"
                + "<td class=\"dataType\">java.lang.String[]</td></tr></table>";
        assertEquals(expResult, instance.toString());
    }

    /**
     * Test of write method, of class WebPrinter.
     */
    @Test
    public void testWrite_null() {
        System.out.println("write");
        CharSequence label = "Label";
        WebPrinter instance = createInstance();

        instance.write(null, label);

        String expResult = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
                + "<table class=\"numbers printer\">\n"
                + "<tr>\n"
                + "<th>#</th>\n"
                + "<th>Expression / Statement</th>\n"
                + "<th>Result</th>\n"
                + "<th class=\"dataType\">Type</th></tr>\n"
                + "<tr>\n"
                + "<td>1.</td>\n"
                + "<td>Label</td>\n"
                + "<td>null</td>\n"
                + "<td class=\"dataType\">?</td></tr></table>";
        assertEquals(expResult, instance.toString());
    }

    /**
     * Test of writeEmptyLine method, of class WebPrinter.
     */
    @Test
    public void testWriteEmptyLine() {
        System.out.println("writeEmptyLine");
        WebPrinter instance = createInstance();
        instance.writeEmptyLine();
    }


    /** Create new Instance */
    private WebPrinter createInstance() {
        return WebPrinter.of(new XmlModel("root"));
    }

}
