/* Copyright 2020-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.tools.model;

import org.jetbrains.annotations.NotNull;
import org.ujorm.tools.Assert;

/** A common message with an error signature */
public class Message {

    private final String text;
    private final boolean error;

    public Message(String text, boolean error) {
        this.text = text;
        this.error = error;
    }

    public String getText() {
        return text;
    }

    public boolean isError() {
        return error;
    }

    public static Message of(@NotNull final String text) {
        return new Message(Assert.notNull(text, "text"), false);
    }

    public static Message of(@NotNull Throwable e) {
        String text = "%s: %s".formatted(e.getClass().getSimpleName(), e.getMessage());
        return new Message(text, true);
    }

    @Override
    public String toString() {
        return getText();
    }
}