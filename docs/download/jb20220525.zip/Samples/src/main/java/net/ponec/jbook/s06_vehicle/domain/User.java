/* Copyright 2018-2022 Pavel Ponec, https;//jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

import java.time.LocalDate;

/**
 * Car data model
 */
public class User {

    /** Personal number */
    private int personalNumber;
    /** FirstName */
    private String firstname;
    /** Surname */
    private String surname;
    /** Birth Date */
    private LocalDate birthDate;
    /** Email. */
    private String email;
    
    /**
     * Personal number
     * @return the personalNumber
     */
    public int getPersonalNumber() {
        return personalNumber;
    }

    /**
     * Personal number
     * @param personalNumber the personalNumber to set
     */
    public void setPersonalNumber(int personalNumber) {
        this.personalNumber = personalNumber;
    }

    /**
     * FirstName
     * @return the firstname
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     * FirstName
     * @param firstname the firstname to set
     */
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    /**
     * Surname
     * @return the surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Surname
     * @param surname the surname to set
     */
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * Birth Date
     * @return the birthDate
     */
    public LocalDate getBirthDate() {
        return birthDate;
    }

    /**
     * Birth Date
     * @param birthDate the birthDate to set
     */
    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    /**
     * Email.
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Email.
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

}
