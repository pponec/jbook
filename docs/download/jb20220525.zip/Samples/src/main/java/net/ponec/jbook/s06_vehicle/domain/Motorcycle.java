/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

/** Car data model */
public class Motorcycle extends MotorVehicle {

}
