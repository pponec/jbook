/* Copyright 2020-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s80_ajax;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.RegexpService;
import net.ponec.jbook.tools.WebTools;
import net.ponec.jbook.tools.model.Message;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.web.ajax.JavaScriptWriter;
import static org.ujorm.tools.web.ajax.JavaScriptWriter.DEFAULT_AJAX_REQUEST_PARAM;
import org.ujorm.tools.web.json.JsonBuilder;

/**
 * A live example of the HtmlElement inside a servlet using a Dom4j library.
 * @author Pavel Ponec
 */
@WebServlet("/regexp")
public class RegexpServlet extends HttpServlet {
    /** Logger */
    private static final Logger LOGGER = Logger.getLogger(RegexpServlet.class.getName());
    /** A service */
    private final RegexpService service = new RegexpService();

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet response
     * @param response servlet request
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (HtmlElement html = HtmlElement.niceOf("Regular expressions", response,
                "css/regexp.css", "css/bootstrap.css")) {
            new JavaScriptWriter(Html.INPUT, Html.TEXT_AREA).write(html.getHead());
            Message msg = highlight(request);
            try (Element body = html.getBody()) {
                body.addHeading(html.getTitle());
                try (Element form = body.addForm().setMethod(Html.V_POST).setAction("?")) {
                    form.addInput(Constants.CONTROL_CSS)
                            .setType(Html.V_TEXT)
                            .setName(Constants.REGEXP)
                            .setValue(request.getParameter(Constants.REGEXP))
                            .setAttribute(Html.A_PLACEHOLDER, "Regular expression");
                    form.addTextArea(Constants.CONTROL_CSS)
                            .setAttribute(Html.A_PLACEHOLDER, "Plain Text")
                            .setName(Constants.TEXT)
                            .addText(request.getParameter(Constants.TEXT));
                    form.addDiv().addButton("btn", "btn-primary").addText("Evaluate");
                    form.addDiv(Constants.CONTROL_CSS, Constants.OUTPUT_CSS).addRawText(msg);
                }
                WebTools.addFooter(html, this);
            }
        } catch (RuntimeException e) {
            LOGGER.log(Level.WARNING, "Internal server error", e);
            response.setStatus(500);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (DEFAULT_AJAX_REQUEST_PARAM.of(request, false)) {
            doAjax(request, JsonBuilder.of(request, response)).close();
        } else {
            doGet(request, response);
        }
    }

    private JsonBuilder doAjax(HttpServletRequest request, JsonBuilder json)
            throws IOException {
        Message msg = highlight(request);
        json.writeClass(Constants.OUTPUT_CSS, e -> e
                .addElementIf(msg.isError(), Html.SPAN, "error")
                .addRawText(msg));
        return json;
    }

    /** Build a HTML result */
    protected Message highlight(HttpServletRequest input) {
        return service.highlight(
                input.getParameter(Constants.TEXT),
                input.getParameter(Constants.REGEXP));
    }

    /** CSS constants and identifiers */
    static class Constants {
        /** Bootstrap form control CSS class name */
        static final String CONTROL_CSS = "text";
        /** CSS class name for the output box */
        static final String OUTPUT_CSS = "out";
        /** Regular expression parameter name */
        static final String REGEXP = "regexp";
        /** Plain text parameter name */
        static final String TEXT = "text";
    }

}
