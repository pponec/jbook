package net.ponec.jbook.s70_gomoku;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * BoadModelTest
 * @author Pavel Ponec
 */
public class BoadModelTest {

    /**  Test the board model of the go-moku game */
    @Test
    public void testBoardModel() throws Exception {
        System.out.println("BoardModel");

        BoardModel board = new BoardModel(10, 10, null);

        checkStone(0, 0, StoneEnum.WHITE_STONE, board);
        checkStone(0, 2, StoneEnum.BLACK_STONE, board);

        checkStone(1, 0, StoneEnum.WHITE_STONE, board);
        checkStone(1, 2, StoneEnum.BLACK_STONE, board);

        checkStone(3, 2, StoneEnum.WHITE_STONE, board);
        checkStone(3, 4, StoneEnum.BLACK_STONE, board);
    }

    private void checkStone(int x, int y, StoneEnum stone, BoardModel board) {
        BoardPoint point = new BoardPoint(x, y);
        board.setStone(point, stone);
        assertTrue(board.hasStone(point, stone));
        assertEquals(stone, board.getStone(point));

        BoardPoint nexPoint = new BoardPoint(x + 1, y);
        assertEquals(StoneEnum.NO_STONE, board.getStone(nexPoint));
    }

    /**  Test the board model of the go-moku game */
    @Test
    public void testNoStone() throws Exception {
        System.out.println("testIsFree");

        final StoneEnum noStone = StoneEnum.NO_STONE;
        final StoneEnum myStone = StoneEnum.WHITE_STONE;
        final BoardModel board = new BoardModel(10, 10, null);
        final BoardPoint point = new BoardPoint(8, 2);

        board.setStone(point, myStone);

        assertFalse(board.hasStone(point, noStone));
        assertTrue(board.hasStone(point.set(point, 0, 1), noStone));
        assertFalse(board.hasStone(point.set(0, -1), noStone));
        assertFalse(board.hasStone(point.set(-1, 0), noStone));
        assertFalse(board.hasStone(point.set(0, Short.MAX_VALUE), noStone));
        assertFalse(board.hasStone(point.set(Short.MAX_VALUE ,0), noStone));
    }

}
