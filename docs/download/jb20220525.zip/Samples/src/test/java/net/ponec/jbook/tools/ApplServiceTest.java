/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.tools;

import net.ponec.jbook.s01_hello.HelloWorldServlet;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Pavel Ponec
 */
public class ApplServiceTest {

    /** Test of createFooterForHelloWord method, of class ApplService. */
    @Test
    public void testCreateFooterForHelloWord() throws Exception {
        System.out.println("createFooterForHelloWord");
        String expResult = "<div class=\"footer\">";
        String result = WebTools.createFooter(2, new HelloWorldServlet()).toString();
        assertTrue(result.startsWith(expResult, 2));
    }

}
