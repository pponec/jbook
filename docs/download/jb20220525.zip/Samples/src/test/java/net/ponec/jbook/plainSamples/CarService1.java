/* Copyright 2018-2022 Pavel Ponec */
package net.ponec.jbook.plainSamples;

import java.time.LocalDate;
import net.ponec.jbook.plainSamples.domains.Car;
import net.ponec.jbook.plainSamples.tools.MyPrinter;

/**
 * Simple car
 *
 * @author Pavel Ponec
 */
public class CarService1 {

    /**
     * Create an instance of the  Car
     * @return Some car
     */
    public Car createCar() {
        Car car = new Car();

        Car myCar = new Car();
        myCar.setModelName("Auris");
        myCar.setEnginePower(97);

        String model = myCar.getModelName();
        Car theSameCar = myCar;
        boolean identical = car.getEnginePower() == theSameCar.getEnginePower();

        System.out.println("LOG: %s, %s, %s".formatted(
                model, theSameCar, identical));
        return car;
    }

    /**
     * Read an attributes of the car.
     */
    public void printCar() {
        Car car = this.createCar();

        LocalDate made = car.getMade();
        String manufacturer = car.getManufacturer();
        String modelName = car.getModelName();
        Integer trunkVolume = car.getTrunkVolume();
        String owner = car.getOwner();

        MyPrinter.print(made, manufacturer, modelName, trunkVolume, owner);
    }

    /**
     * Find a car by its engine number.
     * @param motorSerialNumber Serial number of the motor
     * @return The required car or the {@code null} value, of no card was found.
     */
    public Car findCar(int motorSerialNumber) {
         throw new UnsupportedOperationException("Not implemented yet");
    }

}
