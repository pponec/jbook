/* Copyright 2018-2022 Pavel Ponec */
package net.ponec.jbook.plainSamples;

import net.ponec.jbook.plainSamples.domains.Car;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Pavel Ponec
 */
public class UndefinedValues {

    @Test
    void test() {
        assertTrue(checkValidCar(new Car()));
        assertFalse(checkValidCar(null));

        assertTrue(checkValidDouble(1.1));
        assertFalse(checkValidDouble(Double.NaN));
        assertFalse(checkValidDouble(0.0 / 0));
    }

    boolean checkValidCar(Car car) {
        if (car == null) {
            return false;
        } else {
            return true;
        }
    }

    boolean checkValidDouble(double number) {
        if (Double.isNaN(number)) {
            return false;
        } else {
            return true;
        }
    }
}
