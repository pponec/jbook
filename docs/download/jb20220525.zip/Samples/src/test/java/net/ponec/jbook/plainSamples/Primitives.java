/* Copyright 2018-2022 Pavel Ponec */
package net.ponec.jbook.plainSamples;

/**
 * Primitives
 *
 * @author Pavel Ponec
 */
public class Primitives {

    public void sample1() {
        int myNumber = 10;            // celé číslo (32 bitů)
        char myCharacter = 'A';       // znak z tabulky Unicode (16 bitů)
        boolean validInterval = true; // Logická hodnota

        byte limitedCharacter = 'A';
    }

    public void sample2() {
        int maxLimit = 4 + 6;
        int myNumber = 2 * 3;
        boolean validInterval = myNumber <= maxLimit;
        boolean evenNumber = (myNumber % 2) == 0;
        boolean validOddNumber = validInterval && evenNumber;
    }
    
    public void sample3() {
        Integer myNumber = 10;
        Character myCharacter = 'A';
        Boolean validInterval = true;
    }

    public void sample4() {
        byte firstCharacter = 'A';
        byte secondCharacter = 'B';
        byte thirdCharacter = 'C';
        byte[] word = {firstCharacter, secondCharacter, thirdCharacter};
    }

    public void sample5() {
        int i = Integer.parseInt("465");
    }

}
