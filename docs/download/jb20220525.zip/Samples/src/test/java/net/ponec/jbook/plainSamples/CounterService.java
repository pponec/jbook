/* Copyright 2020-2022 Pavel Ponec */
package net.ponec.jbook.plainSamples;

public class CounterService {

    private Counter createCounter() {
        return new CounterImpl();
    }

    public int useCounter(int value) {
        Counter counter = createCounter();
        counter.add(value);
        return counter.getMultiCount(10);
    }
}
