/* Copyright 2020-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.tools;

import net.ponec.jbook.tools.model.Message;
import org.jetbrains.annotations.NotNull;
import org.ujorm.tools.xml.builder.XmlPrinter;
import org.ujorm.tools.xml.config.XmlConfig;

import java.security.SecureRandom;
import org.ujorm.tools.xml.config.HtmlConfig;

public class RegexpService {

    /** Max text length */
    private static final int MAX_LENGTH = 1_100;

    /**
     * Highlights the original text according to the regular expression
     * using HTML element {@code <span>}.
     *
     * @param text An original text
     * @param regexp An regular expression
     * @return Raw HTML text.
     */
    public Message highlight(String text, String regexp) {
        if (text == null || regexp == null) {
            return Message.of("");
        }
        try {
            if (text.length() > MAX_LENGTH) {
                String msg = "Shorten text to a maximum of %s characters.".formatted(
                        MAX_LENGTH);
                throw new IllegalArgumentException(msg);
            }
            SecureRandom random = new SecureRandom();
            String begTag = "_" + random.nextLong();
            String endTag = "_" + random.nextLong();
            String rawText = text.replaceAll(
                    "(" + regexp + ")",
                    begTag + "$1" + endTag);
            XmlPrinter printer = new XmlPrinter(new StringBuilder(), XmlConfig.ofDoctype(""));
            printer.write(rawText, false);
            return Message.of(printer.toString()
                    .replaceAll(begTag, "<span>")
                    .replaceAll(endTag, "</span>")
            );
        } catch (Exception | OutOfMemoryError e) {
            return Message.of(e);
        }
    }

    /** Create a configuration for a HTML model */
    public HtmlConfig getConfig(@NotNull String title) {
        return HtmlConfig.ofDefault()
                .setTitle(title)
                .setNiceFormat();
    }
}
