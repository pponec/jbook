/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s80_ajax;

import net.ponec.jbook.s70_gomoku.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.web.ajax.JavaScriptWriter;
import org.ujorm.tools.web.json.JsonBuilder;
import net.ponec.jbook.s70_gomoku.BoardModel;


/** Simple board game */
@WebServlet("/go-moku-ajax")
public class GoMokuAjaxServlet extends GoMokuServlet {

    /** Message bar parameter */
    protected static final String LASTPOINT_PARAM = "lastPoint";

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request HTTP servlet request
     * @param response HTTP servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (JavaScriptWriter.DEFAULT_AJAX_REQUEST_PARAM.of(request, false)) {
            doAjax(request, JsonBuilder.of(request, response)).close();
        } else {
            doGet(request, response);
        }
    }

    /** Write a Javascript to a header */
    @Override
    protected void writeHeaderElements(HtmlElement html) {
        new JavaScriptWriter(Html.BUTTON).write(html.getHead());
    }

    /** Add last point parameter */
    @Override
    protected void createBoardModel(Element form, BoardModel board) {
        form.addInput().setType(Html.V_HIDDEN)
                .setName(LASTPOINT_PARAM)
                .setValue(board.getLastMove().getPointIndex(board));
        super.createBoardModel(form, board);
    }

    private JsonBuilder doAjax(HttpServletRequest request, JsonBuilder json)
            throws ServletException, IOException {
        BoardModel board = service.createBoardModel(request);
        int lastPoint = service.parseInt(request.getParameter(LASTPOINT_PARAM), 0);
        for (BoardPoint point : board.getChangedPoints(lastPoint)) {
            String pointSelector = "tr:nth-child(%s) td:nth-child(%s)".formatted(
                    point.getY() + 1,
                    point.getX() + 1);
            json.write(pointSelector, e -> createStone(e, point, board));
        }
        json.writeId(BOARD_MODEL_ID, e -> createBoardModel(e, board));
        json.writeId(MESSAGE_ID, e -> createMessagePanel(e, board));
        return json;
    }

}
