/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s06_vehicle;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.ponec.jbook.s06_vehicle.domain.*;

/** An example of the service */
public class RegistrationService {

    /** Get a fictional cars */
    public List<Car> getFictionalCars() {

        User owner1 = createUser(1, "Jiří", "Mexedolid", LocalDate.of(2001, Month.MARCH, 15));
        User owner2 = createUser(2, "Lucie", "Zixerfxodf", LocalDate.of(1980, Month.AUGUST, 20));
        User owner3 = createUser(3, "Donald", "Choresisdi", LocalDate.of(1990, Month.OCTOBER, 30));

        Company skoda = new Company("Škoda Auto", new Locale("cs-CZ"));
        Company toyota = new Company("Toyota", Locale.JAPAN);
        Company ford = new Company("Ford", Locale.US);

        VehicleModel fabia = new VehicleModel(skoda, "Fabia", 260);
        VehicleModel rapid = new VehicleModel(skoda, "Rapid", 550);
        VehicleModel auris = new VehicleModel(toyota, "Auris", 354);
        VehicleModel focus = new VehicleModel(ford, "Focus", 375);

        EngineType engine1 = new EngineType("abc-123", "beznin", 47);
        EngineType engine2 = new EngineType("cde-345", "beznin", 81);
        EngineType engine3 = new EngineType("edg-567", "beznin", 85);
        EngineType engine4 = new EngineType("ghi-789", "beznin", 77);

        List<Car> result = new ArrayList<>();
        result.add(createCar(fabia, LocalDate.of(2005,  6,  1), engine1, "ABC-22-33", 123_654_987, 260, owner1));
        result.add(createCar(rapid, LocalDate.of(2013,  1, 15), engine2, "RED-24-33", 359_985_785, 550, owner2));
        result.add(createCar(auris, LocalDate.of(2010, 10, 22), engine3, "JOB-12-33", 987_654_123, 354, owner3));
        result.add(createCar(focus, LocalDate.of(2015,  3, 30), engine4, "XYZ-54-33", 958_232_497, 375, owner3));

        return result;
    }

    /**
     * Find a car by its engine number.
     *
     * @param motorSerialNumber Serial number of the motor
     * @return The required car or the {@code null} value, of no card was found.
     */
    public Car findCar(String motorSerialNumber) {
        if (motorSerialNumber == null) {
            throw new IllegalArgumentException("Undefined motorSerialNumber");
        }
        for (Car car : getFictionalCars()) {
            if (motorSerialNumber.equals(car.getMotorSerialNumber())) {
                return car;
            }

        }
        return null;
    }

    /** Create new user with generated email */
    private User createUser
                 ( int personalNumber
                 , String firstname
                 , String surname
                 , LocalDate birthDate) {

        User result = new User();
        result.setPersonalNumber(personalNumber);
        result.setFirstname(firstname);
        result.setSurname(surname);
        result.setBirthDate(birthDate);
        result.setEmail("%s.%s@test.com".formatted(firstname.toLowerCase(), surname.toLowerCase()));

        return result;
    }

    /** Create an instance of the car */
    private Car createCar
                ( VehicleModel model
                , LocalDate made
                , EngineType engineType
                , String licensePlate
                , int motorSerialNumber
                , int trunkVolume
                , User owner) {

        Car result = new Car();
        result.setModel(model);
        result.setMade(made);
        result.setEnergy(engineType);
        result.setLicensePlate(licensePlate);
        result.setMotorSerialNumber(motorSerialNumber);
        result.setTrunkVolume(trunkVolume);
        result.setOwner(owner);

        return result;
    }

}
