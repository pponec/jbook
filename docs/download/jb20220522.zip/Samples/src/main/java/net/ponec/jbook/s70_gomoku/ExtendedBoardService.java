/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s70_gomoku;

import java.util.Optional;
import java.util.Random;

/** A board game services */
public class ExtendedBoardService extends BoardService {

    /** An extended implementation for getting an opponent draw */
    @Override
    protected Optional<BoardPoint> getNextPoint(final BoardModel board) {
        final BoardPoint lastMove = board.getLastMove().clonePoint();
        final StoneEnum stone = board.getStone(lastMove);
        final byte max = GoMokuServlet.WINNING_STONE_COUNT;
        final byte min = max - 2;

        for (int count = max; count >= min; count--) {
            if (count == min && new Random().nextBoolean()) {
                break; // Random weakness 50%
            }
            for (DirectionEnum direction : DirectionEnum.values()) {
                final BoardPoint[] points = getDirectionBorder(board, direction, 1);
                if (points != null) {
                    for (BoardPoint borderPoint : points) {
                        if (board.hasStone(borderPoint, StoneEnum.NO_STONE)) {
                            BoardModel newBoard = board.cloneBoard();
                            newBoard.setStone(borderPoint, stone);
                            if (getDirectionBorder(newBoard, direction, count) != null) {
                                return Optional.of(newBoard.getLastMove());
                            }
                        }
                    }
                }
            }
        }
        return super.getNextPoint(board);
    }
}
