/* Copyright 2018-2022 Pavel Ponec, https;//jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

/**
 * VehicleModel data model
 */
public class VehicleModel {

    /** A name of vehicle model */
    private String name;
    /** A trunk volume in liter units */
    private int trunkVolume;
    /** A manufacturer */
    private Company manufacturer;

    /** Default constructor */
    public VehicleModel() {
    }
    
    /** Parameter constructor */
    public VehicleModel(Company manufacturer, String name, int trunkVolume) {
        this.name = name;
        this.trunkVolume = trunkVolume;
        this.manufacturer = manufacturer;
    }

    /**
     * A name of vehicle model
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * A name of vehicle model
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * A trunk volume in liter units
     * @return the trunkVolume
     */
    public int getTrunkVolume() {
        return trunkVolume;
    }

    /**
     * A trunk volume in liter units
     * @param trunkVolume the trunkVolume to set
     */
    public void setTrunkVolume(int trunkVolume) {
        this.trunkVolume = trunkVolume;
    }

    /**
     * A manufacturer
     * @return the manufacturer
     */
    public Company getManufacturer() {
        return manufacturer;
    }

    /**
     * A manufacturer
     * @param manufacturer the manufacturer to set
     */
    public void setManufacturer(Company manufacturer) {
        this.manufacturer = manufacturer;
    }

}
