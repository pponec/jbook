/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s70_gomoku;

/** A field locator of the board is a mutable object. */
public final class BoardPoint {

    private short x;
    private short y;

    /** Default constructor */
    public BoardPoint() {
    }

    /** Argument constructor constructor */
    public BoardPoint(final int x, final int y) {
        set(x, y);
    }

    /** Set new coordinates */
    public BoardPoint set(final int x, final int y) {
        this.x = toShort(x);
        this.y = toShort(y);
        return this;
    }

    /** Set new coordinates */
    public BoardPoint set(final BoardPoint point) {
        return set(point.x, point.y);
    }

    /** Set new coordinates */
    public BoardPoint set(final BoardPoint point, final int shiftX, final int shiftY) {
        return set(point.x + shiftX, point.y + shiftY);
    }

    /** Returns a X-coordinate position */
    public short getX() {
        return x;
    }

    /** Returns a Y-coordinate position */
    public short getY() {
        return y;
    }

    /** Get a point index */
    public int getPointIndex(BoardModel board) {
        return x + y * board.getWidth();
    }

    /** Set a point by an field index */
    public BoardPoint setPointIndex(final int i, final int boardWidth) {
        return set(i % boardWidth,
                 i / boardWidth);
    }

    /** Return an absolute length to a next point */
    public int getDistance(BoardPoint param) {
        int dx = Math.abs(this.x - param.x);
        int dy = Math.abs(this.y - param.y);
        return Math.max(dx, dy);
    }

    /** Clone the point */
    public BoardPoint clonePoint() {
        return new BoardPoint().set(this);
    }

    /** Compare the point to another */
    public boolean equals(Object param) {
        return param instanceof BoardPoint && equals((BoardPoint) param);
    }

    /** Compare the point to another */
    public boolean equals(BoardPoint param) {
        return this.x == param.x
            && this.y == param.y;
    }

    /** Check the input has a valid range and convert it to the short type.
     * Note: A negative value is allowed for calculating the response of the counter only. */
    private short toShort(final int i) throws IllegalArgumentException {
        if (i >= -1 && i <= Short.MAX_VALUE) {
            return (short) i;
        } else {
            throw new IllegalArgumentException("Number is out of range: " + i);
        }
    }

    /** Text for a debugging */
    @Override
    public String toString() {
        return "[%s,%s]".formatted(x, y);
    }
}