/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

/**
 * A fuel engine type (a katalog data)
 */
public class EngineType {

    /** Product code */
    private String productCode;
    /** Is a fuel energy type */
    private String fuelName;
    /** Engine Power in kW */
    private Integer power;

    /** Default constructor */
    public EngineType() {
    }

    /** Constructor for a fuel engine */
    public EngineType(String productCode, String fuelName, Integer power) {
        this.fuelName = fuelName;
        this.power = power;
    }

    /**
     * Product code
     * @return the productCode
     */
    public String getProductCode() {
        return productCode;
    }

    /**
     * Product code
     * @param productCode the productCode to set
     */
    public void setProductCode(String productCode) {
        this.productCode = productCode;
    }

    /**
     * Is a fuel energy type
     * @return the fuelName
     */
    public String getFuelName() {
        return fuelName;
    }

    /**
     * Is a fuel energy type
     * @param fuelName the fuelName to set
     */
    public void setFuelName(String fuelName) {
        this.fuelName = fuelName;
    }

    /**
     * Engine Power in kW
     * @return the power
     */
    public Integer getPower() {
        return power;
    }

    /**
     * Engine Power in kW
     * @param power the power to set
     */
    public void setPower(Integer power) {
        this.power = power;
    }

}
