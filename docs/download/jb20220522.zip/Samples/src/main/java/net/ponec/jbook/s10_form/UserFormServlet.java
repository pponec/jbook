/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s10_form;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;

/** A live example inside a servlet */
@WebServlet("/userFormServlet")
public class UserFormServlet extends HttpServlet {

    /* A common code page form request and response. Try the {@code  Charset.forName("windows-1250")} for example. */
    private static final Charset CHARSET = StandardCharsets.UTF_8;

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request HTTP servlet request
     * @param response HTTP servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding(CHARSET.toString());

        try (HtmlElement html = HtmlElement.niceOf("Simple user form", response, CHARSET, "css/form.css")) {
            html.getBody().addHeading(html.getTitle());
            Element form = html.getBody().addForm()
                    .setMethod(Html.V_POST)
                    .setAction(request.getRequestURI());
            for (FieldDescriptor field : getFieldDescriptors()) {
                createInputField(field, form, request);
            }
            WebTools.addFooter(html, this);
        }
    }

    /** Create an input field including label and validation message */
    private void createInputField(FieldDescriptor field, Element form, HttpServletRequest request) {
        String cssStyle = field.isSubmit() ? "submit" : "";
        Element result = form.addDiv(cssStyle); // An envelope
        result.addLabel().setFor(field.getName())
                .addText(field.getLabel());
        Element inputRow = result.addDiv();
        inputRow.addInput()
                .setType(field.isSubmit() ? "submit" : "text")
                .setName(field.getName())
                .setValue(field.getValue(request));

        String errorMessage = getErrorMessage(request, field);
        if (errorMessage != null) {
             inputRow.addSpan().addText(errorMessage);
        }
    }

    /** Check the POST value and return an error message of the null */
    public String getErrorMessage(HttpServletRequest request, FieldDescriptor field) {
        boolean postMethod = "post".equalsIgnoreCase(request.getMethod());
        if (postMethod) {
            final String value = field.getValue(request);
            if (value == null || value.isEmpty()) {
                return "Required field";
            } else if (!Pattern.matches(field.getRegexp(), value)) {
                return "Wrong value for: " + field.getRegexp(); // Localize it!
            }
        }
        return null;
    }

    /** Form field description data */
    private FieldDescriptor[] getFieldDescriptors() {
        FieldDescriptor[] result =
                        { new FieldDescriptor("First name", "firstname", ".{2,30}")
                        , new FieldDescriptor("Last name", "lastname", ".{2,30}")
                        , new FieldDescriptor("E-mail", "email", "[a-z0-9.-]+@[a-z0-9.-]+\\.[a-z]{2,4}")
                        , new FieldDescriptor("Phone number", "phone", "[+ 0-9]{9,15}")
                        , new FieldDescriptor("Nickname", "nick", ".{3,10}")
                        , new FieldDescriptor("", "submit", ".*", true)};
        return result;
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request HTTP servlet request
     * @param response HTTP servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
