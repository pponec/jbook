/* Copyright 2018-2022 Pavel Ponec */
package net.ponec.jbook.tools;

import java.util.Base64;

/** Binary converter to Base64 format */
public class Base64Converter {

    /** Byte compressor */
    private final Compressor compressor = new Compressor();

    /** Convert value to Base 64 */
    public String convert(final byte[] value) {
        return Base64.getUrlEncoder().encodeToString(compressor.compress(value));
    }

    /** Deconvert value from Base 64 */
    public byte[] deconvert(String value) {
        return compressor.decompress(Base64.getUrlDecoder().decode(value));
    }

}
