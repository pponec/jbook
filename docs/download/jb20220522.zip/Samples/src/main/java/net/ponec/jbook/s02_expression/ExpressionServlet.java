/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s02_expression;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebPrinter;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.HtmlElement;

/** Servlet for printing an expression examples */
@WebServlet("/expressions")
public class ExpressionServlet extends HttpServlet {

    /** Two Non Break Spaces */
    private final String fixedSpaces = "\u00A0\u00A0";

    /** Try yourself examples */
    private void printPrimitives(WebPrinter printer) {

        // Primitive constants and changes of type
        printer.write(65, "65");
        printer.write(6_500_000, "6_500_000");
        printer.write(true, "true");
        printer.write((byte) 65, "(byte) 65");
        printer.write((short) 65, "(short) 65");
        printer.write('A', "'A'");
        printer.write((char) 65, "(char) 65");
        printer.write(65L, "65L");
        printer.write(65.73F, "65.73F");
        printer.write(65.73, "65.73");
        printer.write(6.573e3, "6.573e3");
        printer.write((int) 65.82, "(int) 65.82");
        printer.write((short) 654321, "(short) 654321");

        // Additions
        printer.writeEmptyLine();
        printer.write(2 + 3, "2 + 3");
        printer.write(2 + 3L, "2 + 3L");

        // Joining text strings
        printer.write("2" + "3", "\"2\" + \"3\"");

        // Multiplication and priorities
        printer.write(2 * 3, "2 * 3");
        printer.write(1 + 2 * 3, "1 + 2 * 3");
        printer.write((1 + 2) * 3, "(1 + 2) * 3");

        // Division
        printer.write(7 / 3, "7 / 3");

        // Modulo
        printer.write(7 % 3, "7 % 3");

        // Additions
        printer.write('A' + (char) 1, "'A' + (char) 1");
        printer.write((char) ('A' + 1), "(char) ('A' + 1)");

        // Comparison of primitive types
        printer.write(2 + 3 == 6 - 1, "2 + 3 == 6 - 1");
        printer.write(2 + 3 <= 6 - 2, "2 + 3 <= 6 - 2");
        printer.write(2 + 3 <= Short.MAX_VALUE, "2 + 3 <= Short.MAX_VALUE");

        // Booleans
        printer.write(true || false, "true || false");
        printer.write(true && false, "true && false");
        printer.write(! false, "! false");

        // Functions
        printer.writeEmptyLine();
        printer.write(Math.max(2, 3), "Math.max(2, 3)");
        printer.write(Math.pow(2, 3), "Math.pow(2, 3)");
        printer.write(Math.round(65.73), "Math.round(65.73)");
        printer.write(Integer.parseInt("23"), "Integer.parseInt(\"23\")");

        // Autoboxing
        printer.write((Integer) 37, "(Integer) 37");
        printer.write((int) Integer.valueOf(37), "(int) Integer.valueOf(37)");

        // BigDecimal
        printer.writeEmptyLine();
        BigDecimal a = new BigDecimal("1.45");
        printer.write(a, "BigDecimal a = new BigDecimal(\"1.45\")");
        BigDecimal b = new BigDecimal(1.45f, new MathContext(10));
        printer.write(b, "BigDecimal b = new BigDecimal(1.45f,",
                fixedSpaces + "new MathContext(10));");
        BigDecimal c = b.setScale(1, RoundingMode.HALF_UP);
        printer.write(c, "BigDecimal c = b.setScale(1, RoundingMode.HALF_UP)");

        printer.write(a.add(c), "a.add(c)");
        printer.write(a.subtract(b), "a.subtract(b)");
        printer.write(a.multiply(c), "a.multiply(c)");
        printer.write(a.divide(c, new MathContext(10)), "a.divide(c, new MathContext(10))");
        printer.write(a.setScale(9).equals(a), "a.setScale(9).equals(a)");
        printer.write(a.setScale(9).compareTo(a) == 0, "a.setScale(9).compareTo(a) == 0");
    }

    /** Try Variables */
    private void printVariables(WebPrinter printer) {

        boolean agreement = true;
        printer.write(agreement, "boolean agreement = true;");

        char myCharacter = 'A';
        printer.write(myCharacter, "char myCharacter = 'A';");

        int count = 5;
        printer.write(count, "int count = 5;");

        int goodsPrice = count * 100;
        printer.write(goodsPrice, "int goodsPrice = count * 100;");

        int myCash = 2 * 100 + 3 * 20 + 1;
        printer.write(myCash, "int myCash = 2 * 100 + 3 * 20 + 1;");

        boolean shopping = myCash >= goodsPrice;
        printer.write(shopping, "boolean shopping = myCash >= goodsPrice;");

        myCash = myCash + 1_000;
        printer.write(myCash, "myCash = myCash + 1_000;");

        myCash += 1_000;
        printer.write(myCash, "myCash += 1_000;");

        shopping = myCash >= goodsPrice;
        printer.write(shopping, "shopping = myCash >= goodsPrice;");

        myCash -= goodsPrice;
        printer.write(myCash, "myCash -= goodsPrice;");
    }

    /** Character arrays */
    private void printArrays(WebPrinter printer) {

        // Simple use:
        char[] array = {'A', 'B', 'C'};
        printer.write(array,
                "char[] array = {'A', 'B', 'C'};");

        // Next array:
        array = new char[] {'N', 'E', 'X', 'T'};
        printer.write(array, "array = new char[] {'N', 'E', 'X', 'T'};");

        // Write an empty line:
        printer.writeEmptyLine();

        // Character array:
        array = new char[2];
        printer.write(array, "array = new char[2];");

        // Writing values:
        array[0] = 'O';
        array[1] = 'K';
        printer.write(array,
                "array[0] = 'O'; \n" +
                "array[1] = 'K';"
        );

        // Reading a length of the array:
        printer.write(array.length, "array.length");

        // Reading a cell:
        printer.write(array[0], "array[0]");
        printer.write(array[1], "array[1]");

        // Write an empty line:
        printer.writeEmptyLine();

        // Create array from String:
        array = "HELLO".toCharArray();
        printer.write(array, "array = \"HELLO\".toCharArray();");

        // Sort array:
        Arrays.sort(array);
        printer.write(array, "Arrays.sort(array);");

        // Create new String form an array:
        printer.write(new String(array), "new String(array)");

        // String array
        printer.write(new String[] {"AB", "CD", "EF"},
                "new String[] {\"AB\", \"CD\", \"EF\"}");
    }

    /** Object type of String */
    private void printString(WebPrinter printer) {

        String name = "Joe";
        printer.write(name, "String name = \"Joe\";");

        name = name + " Black";
        printer.write(name, "name = name + \" Black\";");

        // Reading the first char:
        printer.write(name.charAt(0), "name.charAt(0)");

        // Reading a next char:
        printer.write(name.charAt(1), "name.charAt(1)");

        // Reading a length of the array:
        printer.write(name.length(), "name.length()");

        // Find first character:
        printer.write(name.indexOf('B'), "name.indexOf('B')");

        // Substring:
        printer.write(name.substring(4, 9), "name.substring(4, 9)");

        // To upper case:
        printer.write(name.toUpperCase(), "name.toUpperCase()");

        // To upper case:
        printer.write(name.toLowerCase(), "name.toLowerCase()");

        // Write an empty line:
        printer.writeEmptyLine();

        // Comparison of object types
        printer.write(name.equals("Joe Black"), "name.equals(\"Joe Black\")");

        // Compare the object instances only!
        printer.write(name == "Joe Black", "name == \"Joe Black\"");

        // Compare the object instances only!
        printer.write(name == name, "name == name");

        // Compare the beginning of the text
        printer.write(name.startsWith("Joe"), "name.startsWith(\"Joe\")");

        // Compare the end of the text
        printer.write(name.endsWith("Black"), "name.endsWith(\"Black\")");

        // Compare the end of the text
        printer.write(" Joe ".trim().equals("Joe"), "\" Joe \".trim().equals(\"Joe\")");

        // Join two Strings
        printer.write("This is ".concat(name), "\"This is \".concat(name)");

        // Build string by a join method
        printer.write(String.join(" ", "This", "is", name, "!"), ""
                + "String.join(\" \", \"This\", \"is\", name, \"!\")");

        // Build string by a template
        printer.write("This is %s!".formatted(name),
                "\"This is %s!\".formatted(name)");
    }

    /** Plain ArrayList */
    private void printPlainList(WebPrinter printer) {

        // New List:
        List list = new ArrayList();
        printer.write(list, "List list = new ArrayList();");

        // Writing values to object:
        list.add( 8 );
        list.add("K");
        printer.write(list,
                "list.add( 8 ); \n" +
                "list.add('K');"
        );

        // Reading a length of the list:
        printer.write(list.size(), "list.size()");

        // Reading an item:
        printer.write(list.get(0), "list.get(0);");
        Object c = list.get(1);
        printer.write(c, "Object c = list.get(1);");
    }

    /** A generic ArrayList. */
    private void printList(WebPrinter printer) {

        // New List:
        List<Character> list = new ArrayList<>();
        printer.write(list, "List<Character> list = new ArrayList<>();");

        // Writing to the object:
        list.add('O');
        list.add('K');
        printer.write(list,
                "list.add('O'); \n" +
                "list.add('K');"
        );

        // Reading an item:
        printer.write(list.get(0), "list.get(0)");
        Character c = list.get(1);
        printer.write(c, "Character c = list.get(1);");

        // Write an empty line:
        printer.writeEmptyLine();

        // Create a List from characters:
        list = Arrays.asList('H', 'E', 'L', 'L', 'O');
        printer.write(list, "list = Arrays.asList('H', 'E', 'L', 'L', 'O');");

        // Sort the list:
        Collections.sort(list);
        printer.write(list, "Collections.sort(list);");

        // List of Strings:
        printer.write(Arrays.asList("AB", "CD", "EF"),
                "Arrays.asList(\"AB\", \"CD\", \"EF\")");

        // Stream:
        printer.write(Stream.of(9, null, 2, 5, 1)
                .filter((Integer i) -> i != null)
                .map((Integer i) -> i * 10)
                .sorted()
                .limit(2)
                .toList()
                , "Stream.of(9, null, 2, 5, 1)"
                , fixedSpaces + ".filter((Integer i) -> i != null)"
                , fixedSpaces + ".map((Integer i) -> i * 10)"
                , fixedSpaces + ".sorted()"
                , fixedSpaces + ".limit(2)"
                , fixedSpaces + ".toList();");
    }

    /** TreeMap class */
    private void printMap(WebPrinter printer) {

        // New Map:
        Map<Integer, String> map = new TreeMap<>();
        printer.write(map, "Map<Integer, String> list = new TreeMap<>();");

        // Writing to the object:
        map.put(7, "K");
        map.put(3, "O");
        printer.write(map,
                "map.put(7, \"K\"); \n" +
                "map.put(3, \"O\");"
        );

        // Reading a length of the map:
        printer.write(map.size(), "map.size()");

        // Reading an item:
        printer.write(map.get(3), "map.get(3)");
        printer.write(map.get(4), "map.get(4)");

        // Reading a keys of map:
        printer.write(map.keySet().toArray(), "map.keySet().toArray()");

        // Remove item:
        printer.write(map.remove(3), "map.remove(3)");
        printer.write(map.size(), "map.size()");
    }

    /** Handles the HTTP GET request */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (HtmlElement html = HtmlElement.niceOf(response, "css/table.css")) {
            Element body = html.getBody();
            try {
                body.addHeading("Java expressions");
                printPrimitives(WebPrinter.of(body));

                body.addHeading(2, "Variables");
                printVariables(WebPrinter.of(body));

                body.addHeading(2, "Array");
                printArrays(WebPrinter.of(body));

                body.addHeading(2, "String");
                printString(WebPrinter.of(body));

                body.addHeading(2, "List");
                printPlainList(WebPrinter.of(body));

                body.addHeading(2, "List with generics");
                printList(WebPrinter.of(body));

                body.addHeading(2, "Map with generics");
                printMap(WebPrinter.of(body));

                throw new IllegalStateException("A test exception");
            } catch (Exception exception) {
                body.addHeading(2, "Sample stack trace of exception");
                WebTools.writeStackTrace(body.addPreformatted(), exception);
            }
            WebTools.addFooter(html, this);
        }
    }
}
