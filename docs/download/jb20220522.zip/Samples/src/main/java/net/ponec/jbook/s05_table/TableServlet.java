/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s05_table;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.HtmlElement;

/** A live example inside a servlet */
@WebServlet("/tableServlet")
public class TableServlet extends HttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (HtmlElement html = HtmlElement.niceOf("The table", response, "css/table.css")) {
            html.getBody().addHeading(html.getTitle());
            // Print table:
            Object[][] model = getTableModel();
            Element table = html.getBody().addElement("table").setClass("numbers");
            for (int y = 0; y < model.length; y++) {
                Object[] rowValues = model[y];
                Element rowElement = table.addTableRow();
                for (int x = 0; x < rowValues.length; x++) {
                    Object value = rowValues[x];  // model[y][x]
                    rowElement.addTableDetail().addText(value);
                }
            }
            WebTools.addFooter(html, this);
        }
    }

    /** A static number array */
    private Object[][] getTableModel() {
        Object[][] result = 
            { {"@", "A", "B", "C", "D", "E", "F", "G"}
            , {"1", 493, 180, 103,  45, 317, 183,  67}
            , {"2", 469,   5, 156,  98, 470, 434, 196}
            , {"3",  73, 383, 413, 221, 156, 340,  79}
            , {"4", 324, 211,  41, 302,  26, 426, 115}
            , {"5", 123, 303, 250, 301, 416, 487, 315}
            , {"6", 326, 493,  16,  11, 346, 240, 280}
            , {"7", 468, 390, 497,  36, 242, 469, 174}
            };
        return result;
    }
}
