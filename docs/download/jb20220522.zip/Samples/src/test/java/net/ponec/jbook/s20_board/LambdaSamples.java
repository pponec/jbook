/* Copyright 2018-2022 Pavel Ponec */
package net.ponec.jbook.s20_board;

import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Sample
 *
 * @author Pavel Ponec
 */
public class LambdaSamples {

    public void acceptSample1() {
        Optional<String> text = Optional.ofNullable("text");

        Consumer<String> consumer = new Consumer<String>() {
            public void accept(String t) {
                doSomething(t);
            }
        };
        text.ifPresent(consumer);
    }

    public void acceptSample2() {
        Optional<String> text = Optional.ofNullable("text");
        Consumer<String> consumer = (String t) -> doSomething(t);
        text.ifPresent(consumer);
    }

    public void acceptSample3() {
        Optional<String> text = Optional.ofNullable("text");
        text.ifPresent((String t) -> doSomething(t));
    }

    // ---
    public void mapSample1() {
        Optional<String> text = Optional.ofNullable("text");
        Function<String, Integer> function = new Function<String, Integer>() {
            public Integer apply(String t) {
                return t.length();
            }
        };
        Integer leghth = text.map(function).orElse(0);
    }

    public void mapSample2() {
        Optional<String> text = Optional.ofNullable("text");
        Function<String, Integer> function = (String t) -> t.length();
        Integer leghth = text.map(function).orElse(0);
    }

    public void mapSample3() {
        Optional<String> text = Optional.ofNullable("text");
        Integer leghth = text.map((String t) -> t.length()).orElse(0);
    }

    // ---
    /**
     * Helper method
     */
    private void doSomething(String text) {
        // do something ....
    }

}
