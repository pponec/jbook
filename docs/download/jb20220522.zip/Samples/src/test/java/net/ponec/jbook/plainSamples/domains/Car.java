/* Copyright 2018-2022 Pavel Ponec */
package net.ponec.jbook.plainSamples.domains;

import java.time.LocalDate;

/**
 * The Car class
 * @author Pavel Ponec
 */
public class Car {

    /** Vehicle model */
    private String modelName;
    /** Engine Power in kW */
    private int enginePower;
    /** A manufacturer */
    private String manufacturer;
    /** Date of manufacture */
    private LocalDate made;
    /** Serial number or the engine */
    private int motorSerialNumber;
    /** Type of fuel */
    private String energy;
    /** Luggage compartment volume in liters. */
    private int trunkVolume;
    /** Owner the the vehicle */
    private String owner;

    /**
     * Vehicle model
     * @return the modelName
     */
    public String getModelName() {
        return modelName;
    }

    /**
     * Vehicle model
     * @param modelName the modelName to set
     */
    public void setModelName(String modelName) {
        this.modelName = modelName;
    }

    /**
     * Engine Power in kW
     * @return the enginePower
     */
    public int getEnginePower() {
        return enginePower;
    }

    /**
     * Engine Power in kW
     * @param enginePower the enginePower to set
     */
    public void setEnginePower(int enginePower) {
        this.enginePower = enginePower;
    }

    /**
     * A manufacturer
     * @return the manufacturer
     */
    public String getManufacturer() {
        return manufacturer;
    }

    /**
     * A manufacturer
     * @param manufacturer the manufacturer to set
     */
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    /**
     * Date of manufacture
     * @return the made
     */
    public LocalDate getMade() {
        return made;
    }

    /**
     * Date of manufacture
     * @param made the made to set
     */
    public void setMade(LocalDate made) {
        this.made = made;
    }

    /**
     * Serial number or the engine
     * @return the motorSerialNumber
     */
    public int getMotorSerialNumber() {
        return motorSerialNumber;
    }

    /**
     * Serial number or the engine
     * @param motorSerialNumber the motorSerialNumber to set
     */
    public void setMotorSerialNumber(int motorSerialNumber) {
        this.motorSerialNumber = motorSerialNumber;
    }

    /**
     * Type of fuel
     * @return the energy
     */
    public String getEnergy() {
        return energy;
    }

    /**
     * Type of fuel
     * @param energy the energy to set
     */
    public void setEnergy(String energy) {
        this.energy = energy;
    }

    /**
     * Luggage compartment volume in liters.
     * @return the trunkVolume
     */
    public int getTrunkVolume() {
        return trunkVolume;
    }

    /**
     * Luggage compartment volume in liters.
     * @param trunkVolume the trunkVolume to set
     */
    public void setTrunkVolume(int trunkVolume) throws IllegalArgumentException {
        if (trunkVolume < 0) {
          throw new IllegalArgumentException("Invalid trunkVolume: " + trunkVolume);
        }        
        this.trunkVolume = trunkVolume;
    }

    /**
     * Owner the the vehicle
     * @return the owner
     */
    public String getOwner() {
        return owner;
    }

    /**
     * Owner the the vehicle
     * @param owner the owner to set
     */
    public void setOwner(String owner) {
        this.owner = owner;
    }
}
