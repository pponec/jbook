/* Copyright 2020-2022 Pavel Ponec */
package net.ponec.jbook.plainSamples;

public class CounterImpl implements Counter {

    private int count;

    public void add(int value) {
        count = count + value;
    }

    public int getCount() {
        return count;
    }
}
