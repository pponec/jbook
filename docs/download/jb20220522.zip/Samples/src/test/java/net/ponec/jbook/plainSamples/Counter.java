/* Copyright 2020-2022 Pavel Ponec */
package net.ponec.jbook.plainSamples;

/** Counter API */
public interface Counter {

    /** Add new events to the counter. */
    void add(int value);

    /** Get the current number of registered events. */
    int getCount();
    
    /** Get the multiple number of registered events. */
    default int getMultiCount(int i) { return i * getCount(); }
}
