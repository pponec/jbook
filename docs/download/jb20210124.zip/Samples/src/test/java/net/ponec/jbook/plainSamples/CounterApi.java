/* Copyright 2020-2020 Pavel Ponec */
package net.ponec.jbook.plainSamples;

public interface CounterApi {

    void add(int i);

    int getCount();
}
