/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s70_gomoku;

/** An enumeration of stones */
public final class MyStoneEnum {
    /** White stone */
    public static final MyStoneEnum WHITE_STONE = new MyStoneEnum(0, "WHITE_STONE");
    /** Black stone */
    public static final MyStoneEnum BLACK_STONE = new MyStoneEnum(1, "BLACK_STONE");
    /** No stone */
    public static final MyStoneEnum NO_STONE = new MyStoneEnum(2, "NO_STONE");

    /** Order */
    private final int order;
    /** Name */
    private final String name;

    private MyStoneEnum(int order, String name) {
        this.order = order;
        this.name = name;
    }

    /** Returns the position of this enumeration in its declaration */
    public int ordinal() {
        return order;
    }

    public String getName() {
        return name;
    }

    public static MyStoneEnum[] values () {
        MyStoneEnum[] result = { WHITE_STONE, BLACK_STONE, NO_STONE };
        return result;
    }

    public static MyStoneEnum valueOf(String name) throws IllegalArgumentException {
        for (MyStoneEnum value : values()) {
            if (value.getName().equals(name)) {
                return value;
            }
        }
        throw new IllegalArgumentException(name);
    }
}
