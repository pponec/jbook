package net.ponec.jbook.plainSamples.tools;

import java.util.StringJoiner;

/**
 * A printer emulator.
 * @author Pavel Ponec
 */
public class Printer {

    /** Print all arguments to a standard output */
    public static void print(Object... items) {
        StringJoiner line = new StringJoiner(" ");
        for (Object item : items) {
            line.add(String.valueOf(item));
        }
        System.out.println(line);
    }
}
