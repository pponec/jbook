/* Copyright 2020-2020 Pavel Ponec */
package net.ponec.jbook.plainSamples;

public class CounterImpl implements CounterApi {

    private int count;

    CounterImpl() {
    }

    public void add(int i) {
        count = count + i;
    }

    public int getCount() {
        return count;
    }

}
