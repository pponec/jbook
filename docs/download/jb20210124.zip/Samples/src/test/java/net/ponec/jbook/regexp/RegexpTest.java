/* Copyright 2018-2020 Pavel Ponec */
package net.ponec.jbook.regexp;

import java.util.regex.Pattern;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Sample
 *
 * @author Pavel Ponec
 */
public class RegexpTest {

    private final String citation = "As is a tale,"
            + " so is life: not how long it is,"
            + " but how good it is, is what matters.";

    /**
     * Mathes pattern
     */
    @Test
    public void testRegexpMatches() {
        assertTrue(Pattern.matches(".*life.*", citation));
        assertTrue(Pattern.matches("^.*life.*$", citation));
    }

    /**
     * Find pattern
     */
    @Test
    public void testRegexpFind() {
        assertTrue(Pattern.compile("life").matcher(citation).find());
        assertTrue(Pattern.compile("^.s").matcher(citation).find());
    }
    
    /**
     * Group replacement
     */
    @Test
    public void testRegexpReplacementGroup() {
        String result = Pattern
                .compile("([^ ]*l[^ ,:]*)")
                .matcher(citation)
                .replaceAll("[$1]");
        String expected = "As is a [tale], so is [life]: "
                + "not how [long] it is, "
                + "but how good it is, is what matters.";

        assertTrue(expected.equals(result));
    }

}
