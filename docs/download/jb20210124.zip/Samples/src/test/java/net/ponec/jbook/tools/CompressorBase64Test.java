/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.tools;

import java.nio.charset.Charset;
import static java.nio.charset.StandardCharsets.UTF_8;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Pavel Ponec
 */
public class CompressorBase64Test {


    /**
     * Test of compress and decompress methods of the class CompressorBase64.
     */
    @Test
    public void testCompressAndDecompress() {
        System.out.println("compressAndDecompress");

        Charset charset = UTF_8;
        String stringData = "ABCDEFGHIJK-0123456789";
        byte[] data = stringData.getBytes(charset);
        Base64Converter instance = new Base64Converter();

        String compress = instance.convert(data);
        byte[] result = instance.deconvert(compress);
        String stringResult = new String(result, charset);

        assertEquals(stringResult, stringData);
    }

}
