/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s70_gomoku;

/** An enumeration of stones */
public enum StoneEnum {
    /** White stone */
    WHITE_STONE,
    /** Black stone */
    BLACK_STONE,
    /** No stone */
    NO_STONE;
}
