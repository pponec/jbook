/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s20_board;

import java.io.IOException;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;

/** Drawing board */
@WebServlet("/boardServlet")
public class BoardServlet extends HttpServlet {

    /** Logger */
    private static final Logger LOGGER = Logger.getLogger(BoardServlet.class.getName());

    /** Hidden data input */
    public static final String BOARD_PARAM = "board";

    /** Cell prefix */
    public static final String CELL_PREFIX_PARAM = "c";

    /**
     * Handles the HTTP <code>GET</code> or <code>POST</code> method.
     * @param request A servlet request
     * @param response A servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (HtmlElement html = HtmlElement.niceOf("Painting board", response, "css/board.css")) {
            SimpleBoardModel boardModel = createBoardModel(request);
            html.getBody().addHeading(html.getTitle());
            Element form = createFormElement(html.getBody(), boardModel);
            boardModel.getErrorMessage().ifPresent(msg -> form.addSpan("msg").addText(msg)); // Print an error message
            createMainBoard(form, boardModel);
            createResetButton(form, "New picture");
            WebTools.addFooter(html, this);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Servlet failed", e);
        }
    }

    /** Create a board model from input parameters */
    private SimpleBoardModel createBoardModel(HttpServletRequest request) {
        int width = 21;
        int height = 9;
        SimpleBoardModel result;

        try {
            result = new SimpleBoardModel(width, height, request.getParameter(BoardServlet.BOARD_PARAM));
            final Enumeration<String> params = request.getParameterNames();
            while (params.hasMoreElements()) {
                final String param = params.nextElement();
                if (param.startsWith(CELL_PREFIX_PARAM)) {
                    int pointer = Integer.parseInt(param.substring(1));
                    result.flipStone(pointer);
                    break;
                }
            }
        } catch (Exception e) {
            String msg = "An error processing parameters";
            LOGGER.log(Level.WARNING, msg, e);
            result = new SimpleBoardModel(width, height, null);
            result.setErrorMessage(msg);
        }
        return result;
    }

    /** Create a form element including hidden fields */
    private Element createFormElement(final Element parent, SimpleBoardModel board) {
        Element result = parent.addForm()
                .setMethod(Html.V_GET);
        result.addInput()
                .setType(Html.V_HIDDEN)
                .setName(BOARD_PARAM)
                .setValue(board.exportBoard());
        return result;
    }

    /** Create a clear button element */
    private void createResetButton(Element parent, String title) {
        parent.addAnchor(WebTools.getUrlOfServlet(getClass()), "btn", "btn-primary").addText(title);
    }

    /** Create a boad element */
    protected void createMainBoard(Element parent, SimpleBoardModel board) {
        final Element table = parent.addTable("board");
        for (int y = 0; y < board.getHeight(); y++) {
            final Element rowElement = table.addTableRow();
            for (int x = 0; x < board.getWidth(); x++) {
                rowElement.addTableDetail(board.hasStone(x, y) ? "s" : null)
                        .addSubmitButton()
                        .setName(CELL_PREFIX_PARAM + (y * board.getWidth() + x))
                        .addText("");
            }
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
