/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s20_board;

import java.util.BitSet;
import java.util.Optional;
import net.ponec.jbook.tools.Base64Converter;

/** The paiting board */
public class SimpleBoardModel {

    /** A width of the board */
    private final int width;
    /** A height of the board */
    private final int height;
    /** Internal fields */
    private final BitSet fields;
    /** An instance of a Base64 converter */
    private final Base64Converter converter;
    /** Optional error message */
    private String errorMessage;

    /** A constructor with defult converter
     * @param width A width of the board
     * @param height A height of th board
     * @param content An optional content taken from the method {@link #exportBoard() }
     */
    public SimpleBoardModel(int width, int height, String content) {
        this(width, height, content, new Base64Converter());
    }    
    
    /** A constructor with an extended converter.
     * @param width A width of the board
     * @param height A height of th board
     * @param content A optional content from the method {@link #exportBoard() }
     */
    public SimpleBoardModel(int width, int height, String content, Base64Converter converter) {
        this.width = width;
        this.height = height;
        this.converter = converter;
        this.fields = (content == null || content.isEmpty())
                    ? new BitSet(width * height)
                    : BitSet.valueOf(converter.deconvert(content));
    }

    /** Set or remove stone */
    public void flipStone(int i) {
        fields.flip(i);
    }

    public void flipStone(int x, int y) {
        flipStone(y * width + x);
    }

    /** Get a field state */
    public boolean hasStone(int x, int y) {
        return fields.get(y * width + x);
    }

    /** A board width */
    public int getWidth() {
        return width;
    }

    /** A board height */
    public int getHeight() {
        return height;
    }

    /** Set a error message */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /** Get an error message */
    public Optional<String> getErrorMessage() {
        return Optional.ofNullable(errorMessage);
    }

    /** Export board content to a String format */
    public String exportBoard() {
        return converter.convert(fields.toByteArray());
    }
}
