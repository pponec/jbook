/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s99_menu;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.s01_hello.HelloWorldExplicit;
import net.ponec.jbook.s01_hello.HelloWorldElement;
import net.ponec.jbook.s01_hello.HelloWorldServlet;
import net.ponec.jbook.s02_expression.ExpressionServlet;
import net.ponec.jbook.s05_table.TableRandomData;
import net.ponec.jbook.s05_table.TableServlet;
import net.ponec.jbook.s10_form.SimpleFormServlet;
import net.ponec.jbook.s10_form.UserFormServlet;
import net.ponec.jbook.s06_vehicle.VehicleServlet;
import net.ponec.jbook.s15_text.WordCounting;
import net.ponec.jbook.s20_board.BoardServlet;
import net.ponec.jbook.s25_charset.StringBuilderServlet;
import net.ponec.jbook.s70_gomoku.GoMokuServlet;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.HtmlElement;

/** A live example inside a servlet */
@WebServlet(value = {"/menu", ""}, description = WebTools.MENU_DESCRIPTION)
public class MenuServlet extends HttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (HtmlElement html = HtmlElement.niceOf("List of samples", response, "css/form.css")) {
            html.getBody().addHeading(html.getTitle());
            Element topList = html.getBody().addOrderedList("menu");
            Element subList = null;
            for (MenuItem item : getItems()) {
                if (item.isTitle()) {
                    subList = topList.addListItem().addText(item.getLabel())
                            .addOrderedList();
                } else if (subList != null) {
                    subList.addListItem()
                           .addAnchoredText(item.getLink(), item.getLabel());
                }
            }
            WebTools.addFooter(html, this);
        }
    }

    /** Form field description data */
    private MenuItem[] getItems() {
        MenuItem[] result =
            { new MenuItem("Basics")
            , new MenuItem(HelloWorldServlet.class, "Hello, World!")
            , new MenuItem(HelloWorldElement.class, "Hello, World! (by element)")
            , new MenuItem(HelloWorldExplicit.class, "Hello, World! (explicit)")
            , new MenuItem(ExpressionServlet.class, "Java expressions")
            , new MenuItem("Tables")
            , new MenuItem(TableServlet.class, "The table")
            , new MenuItem(TableRandomData.class, "Table with random numbers")
            , new MenuItem(VehicleServlet.class, "Vehicle report")
            , new MenuItem("Forms")
            , new MenuItem(SimpleFormServlet.class, "text=Enter some text", "Simple form")
            , new MenuItem(UserFormServlet.class, "firstname=It's+Me!", "Simple user form")
            , new MenuItem(WordCounting.class, "text=How+many+words+does+this+text+contain?", "Word counting")
            , new MenuItem("Fun grids")
            , new MenuItem(BoardServlet.class, "board=eJxjYGhoagoIEPJadSg0dMVqJlFVBh4FAEuUBlI%3D&c123", "Painting board")
            , new MenuItem(StringBuilderServlet.class, "board=eJxbaMy-0JgfAAc_Ab8&c19", "String building by charset")
            , new MenuItem(GoMokuServlet.class, "Go-moku (simple defensive strategy)")
            };
        return result;
    }
}
