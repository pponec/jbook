/* Copyright 2018-2020 Pavel Ponec, https;//jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

import java.time.LocalDate;

/**
 * RoadVehicle data model
 */
public abstract class RoadVehicle {

    /** Date of manufacture */
    private LocalDate made;
    /** Vehicle model */
    private VehicleModel model;
    /** Owner the the vehicle */
    private User owner;

    /** Default constructor */
    public RoadVehicle() {
    }

    /** Parameter constructor */
    public RoadVehicle(LocalDate made, VehicleModel model, User owner) {
        this.made = made;
        this.model = model;
        this.owner = owner;
    }

    /**
     * Date of manufacture
     * @return the made
     */
    public LocalDate getMade() {
        return made;
    }

    /**
     * Date of manufacture
     * @param made A date of manufacture to set
     */
    public void setMade(LocalDate made) {
        this.made = made;
    }

    /**
     * Vehicle model
     * @return the model
     */
    public VehicleModel getModel() {
        return model;
    }

    /**
     * Vehicle model
     * @param model the model to set
     */
    public void setModel(VehicleModel model) {
        this.model = model;
    }

    /**
     * Owner the the vehicle
     * @return the owner
     */
    public User getOwner() {
        return owner;
    }

    /**
     * Owner the the vehicle
     * @param owner the owner to set
     */
    public void setOwner(User owner) {
        this.owner = owner;
    }
}
