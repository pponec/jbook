/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s15_text;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;

/** A live example inside a servlet */
@WebServlet("/wordCounting")
public class WordCounting extends HttpServlet {

    /* A common code page form request and response. */
    private static final Charset CHARSET = StandardCharsets.UTF_8;
    /** A name of supported parameter */
    private static final String PARAMETER_NAME = "text";

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding(CHARSET.toString());
        String message = request.getParameter(PARAMETER_NAME);

        try (HtmlElement html = HtmlElement.niceOf("Word counting", response
                , "css/table.css"
                , "css/form.css")) {
            html.getBody().setClass("counting").addHeading(html.getTitle());
            Element form = html.getBody().addForm("large")
                    .setMethod(Html.V_POST)
                    .setAction(request.getRequestURI());
            try (Element line = form.addDiv()) {
                line.addLabel().addText("Some text");
                line.addTextArea()
                    .setName(PARAMETER_NAME)
                    .setRows(8)
                    .setCols(220)
                    .addText(message);
            }
            form.addSubmitButton().addText("Submit");

            // Make a result to the table:
            html.getBody().addTable(getGridModel(message));

            // Print footer:
            WebTools.addFooter(html, this);
        }
    }

/**
 * Grid model
 * @param message A nullable value
 * @return Data model for a grid
 */
private Object[][] getGridModel(String message) {
    if (message == null) {
        message = "";
    }
    final Object[][] result =
        { {" ", "Count", "Unit"}
        , {"Word count:", countWords(message), "words" }
        , {"Non-white charactes:", countNonWhiteCharacters(message), "characters"}
        , {"Message length:", message.length(), "characters"}
        };
    return result;
}

    /** Returns a count of non-white charactes */
    private int countNonWhiteCharacters(String message) {
        int result = 0;
        for (int i = 0; i < message.length(); i++) {
            if (!Character.isWhitespace(message.charAt(i))) {
                result++;
            }
        }
        return result;
    }

    /** Returns a count of the words */
    private int countWords(String message) {
        int result = 0;
        boolean lastWhitespace = true;
        for (int i = 0; i < message.length(); i++) {
            boolean currentWhitespace = Character.isWhitespace(message.charAt(i));
            if (lastWhitespace != currentWhitespace) {
                lastWhitespace = currentWhitespace;
                if (!currentWhitespace) {
                    ++result;
                }
            }
        }
        return result;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
