/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s10_form;

import javax.servlet.http.HttpServletRequest;

/** A field descriptor of the form */
public class FieldDescriptor {

    /** Label of the field */
    private final String label;
    /** HTML name of the field */
    private final String name;
    /** Validatiton regular expression */
    private final String regexp;
    /** Input type of submit */
    private final boolean submit;

    /** Full argument constructor */
    public FieldDescriptor(String label, String name, String regexp, boolean submit) {
        this.label = label;
        this.name = name;
        this.regexp = regexp;
        this.submit = submit;
    }

    /** Non submit constructor */
    public FieldDescriptor(String label, String key, String regexp) {
        this(label, key, regexp, false);
    }

    /** Get a request value */
    public String getValue(HttpServletRequest request) {
        if (submit) {
            return "Submit";
        } else {
            return request.getParameter(name);
        }
    }

    /** Label of the field */
    public String getLabel() {
        return label;
    }

    /** HTML name of the field */
    public String getName() {
        return name;
    }

    /** Input type of submit */
    public boolean isSubmit() {
        return submit;
    }

    /** Validatiton regular expression */
    public String getRegexp() {
        return regexp;
    }

}
