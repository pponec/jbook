/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s70_gomoku;

import java.util.BitSet;
import java.util.Optional;
import net.ponec.jbook.tools.Base64Converter;

/** The game board */
public class BoardModel {

    /** A width of the board */
    private final int width;
    /** A heigt of the board */
    private final int height;
    /** Internal fields */
    private final BitSet fields;
    /** An initial value is out of border */
    private final BoardPoint lastMove = new BoardPoint(0, Character.MAX_VALUE);
    /** An instance of a Base64 converter */
    private final Base64Converter converter;
    /** Optional error message */
    private String errorMessage;
    /** A game over status */
    private boolean gameOver;

    /** A constructor with defult converter
     * @param width A width of the board
     * @param height a heigh of th board
     * @param content An optional content taken from the method {@link #exportBoard() }
     */
    public BoardModel(int width, int height, String content) {
        this(width, height, content, new Base64Converter());
    }

    /** A constructor with an extended converter.
     * @param width A width of the board
     * @param height a heigh of th board
     * @param content A optional content from the method {@link #exportBoard() }
     */
    public BoardModel(int width, int height, String content, Base64Converter converter) {
        this.width = width;
        this.height = height;
        this.converter = converter;
        this.fields = (content == null || content.isEmpty())
                    ? new BitSet(width * height * 2)
                    : BitSet.valueOf(converter.deconvert(content));
    }
    
    /** Create new model from the original */
    private BoardModel(BoardModel original) {
        this.width = original.width;
        this.height = original.height;
        this.converter = original.converter;
        this.fields = (BitSet) original.fields.clone();
        this.lastMove.set(original.lastMove);
        this.errorMessage = original.errorMessage;
        this.gameOver = original.gameOver;
    }

    /** Set a stone to a free point */
    public void setStone(BoardPoint point, StoneEnum stone) {
        if (gameOver) {
            throw new IllegalStateException("The game is over ... " + point);
        }
        if (!hasStone(point, StoneEnum.NO_STONE)) {
            throw new IllegalStateException("This point is already occupied " + point);
        }
        switch (stone) {
            case BLACK_STONE:
            case WHITE_STONE:
                fields.set(getBitSetIndex(point, stone));
                lastMove.set(point);
                break;
            default:
                throw new IllegalArgumentException("Illegal stone" + stone);
        }
    }
    
    /** Get a field state */
    public StoneEnum getStone(BoardPoint point) {
        StoneEnum[] stones = {StoneEnum.WHITE_STONE, StoneEnum.BLACK_STONE};
        for (StoneEnum stone : stones) {
            if (checkStoneInternal(point, stone)) {
                return stone;
            }
        }
        return StoneEnum.NO_STONE;
    }

    /** Get an opponent stone */
    public StoneEnum getOpponentStone(StoneEnum stone) {
        switch (stone) {
            case BLACK_STONE:
                return StoneEnum.WHITE_STONE;
            case WHITE_STONE:
                return StoneEnum.BLACK_STONE;
            default:
                return stone;
        }
    }

    /** Get an internal index for the BitSet type. The NO_STONE throws an IllegalArgumentException. */
    private int getBitSetIndex(BoardPoint point, final StoneEnum stone) throws IllegalArgumentException {
        switch (stone) {
            case BLACK_STONE:
            case WHITE_STONE:
                return point.getPointIndex(this) * 2 + stone.ordinal();
            default:
                throw new IllegalArgumentException("Illegal stone: " + stone);
        }
    }

    /** Check it the point is inside the board */
    protected boolean isInsideBoard(BoardPoint point) {
        return point.getX() >= 0
            && point.getX() < width
            && point.getY() >= 0
            && point.getY() < height;
    }

    /** Check a required stone inside the boreder */
    public boolean hasStone(BoardPoint point, StoneEnum stone) {
        return isInsideBoard(point) && getStone(point) == stone;
    }

    /** Check the BALACK or WHITE stone on required point of board.
     * The NO_STONE throws an IllegalArgumentException. */
    private boolean checkStoneInternal(BoardPoint point, StoneEnum stone) throws IllegalArgumentException {
        return fields.get(getBitSetIndex(point, stone));
    }

    /** A board width */
    public int getWidth() {
        return width;
    }

    /** A board height */
    public int getHeight() {
        return height;
    }

    /** Get the last move point */
    public BoardPoint getLastMove() {
        return lastMove;
    }

    /** The game is over */
    public void gameOver() {
        gameOver = true;
    }

    /** The game is over */
    public boolean isGamewOver() {
        return gameOver;
    }

    /** Returns a winner name */
    public Optional<String> getWinnerName(String computer, String human) {
        return gameOver
             ? Optional.of(getStone(lastMove) == StoneEnum.WHITE_STONE ? computer : human)
             : Optional.empty();
    }

    /** Set a error message */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /** Get an error message */
    public Optional<String> getErrorMessage() {
        return Optional.ofNullable(errorMessage);
    }

    /** Clone the board model */
    public BoardModel cloneBoard() {
        return new BoardModel(this);
    }

    /** Return a board content in a String format or {@code null} if the game is over. */
    public String exportBoard() {
        return gameOver ? null : converter.convert(fields.toByteArray());
    }

}
