/* Copyright 2018-2020 Pavel Ponec */
package net.ponec.jbook.tools;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import javax.servlet.http.HttpServlet;
import net.ponec.jbook.s10_form.FieldDescriptor;
import net.ponec.jbook.s10_form.UserFormServlet;
import net.ponec.jbook.s06_vehicle.RegistrationService;
import net.ponec.jbook.s06_vehicle.VehicleServlet;
import net.ponec.jbook.s06_vehicle.domain.Car;
import net.ponec.jbook.s06_vehicle.domain.EnergyType;
import net.ponec.jbook.s06_vehicle.domain.MotorVehicle;
import net.ponec.jbook.s06_vehicle.domain.RoadVehicle;
import net.ponec.jbook.s06_vehicle.domain.User;
import net.ponec.jbook.s06_vehicle.domain.VehicleModel;
import net.ponec.jbook.s20_board.BoardServlet;
import net.ponec.jbook.s20_board.SimpleBoardModel;
import net.ponec.jbook.s25_charset.ExtendedBoardModel;
import net.ponec.jbook.s25_charset.StringBuilderServlet;
import net.ponec.jbook.s70_gomoku.BoardModel;
import net.ponec.jbook.s70_gomoku.BoardPoint;
import net.ponec.jbook.s70_gomoku.BoardService;
import net.ponec.jbook.s70_gomoku.DirectionEnum;
import net.ponec.jbook.s70_gomoku.ExtendedBoardService;
import net.ponec.jbook.s70_gomoku.GoMokuServlet;
import net.ponec.jbook.s70_gomoku.StoneEnum;
import net.ponec.jbook.s99_menu.MenuItem;
import net.ponec.jbook.s99_menu.MenuServlet;

/** Mapping the samples */
public class SourceMapImpl implements SourceMap, Serializable {

    /** Servlet mapping */
    final Map<Class,Class[]> classMap = new HashMap<>();

    /** Map servlet to dependecies */
    SourceMapImpl() {
        classMap.put(VehicleServlet.class, array(Car.class, MotorVehicle.class, RoadVehicle.class, EnergyType.class, VehicleModel.class, User.class, RegistrationService.class));
        classMap.put(BoardServlet.class, array(SimpleBoardModel.class));
        classMap.put(UserFormServlet.class, array(FieldDescriptor.class));
        classMap.put(BoardServlet.class, array(SimpleBoardModel.class));
        classMap.put(StringBuilderServlet.class, array(ExtendedBoardModel.class));
        classMap.put(GoMokuServlet.class, array(BoardModel.class, StoneEnum.class, BoardPoint.class, DirectionEnum.class, BoardService.class, ExtendedBoardService.class));
        classMap.put(MenuServlet.class, array(MenuItem.class));
    }

    /** Build an array */
    Class[] array(final Class ... item) {
        return item;
    }

    /** Get servlet dependencies */
    private Optional<Class[]> getDependences(final Class<? extends HttpServlet> servletClass) {
        return Optional.ofNullable(classMap.get(servletClass));
    }

    /** Return an array of related classes */
    @Override
    public List<Class> getClasses(final Class<? extends HttpServlet> servletClass) {
        final ArrayList<Class> result = new ArrayList<>(8);
        result.add(servletClass);
        getDependences(servletClass).ifPresent(items -> result.addAll(Arrays.asList(items)));
        return result;
    }
}
