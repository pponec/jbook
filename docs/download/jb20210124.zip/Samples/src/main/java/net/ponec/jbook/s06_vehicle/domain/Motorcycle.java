/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

import java.time.LocalDate;

/** Car data model */
public class Motorcycle extends MotorVehicle {
    
    /** Date of manufacture */
    private LocalDate made;

    /**
     * Date of manufacture
     * @return the dateOfManufacture
     */
    public LocalDate getMade() {
        return made;
    }

    /**
     * Date of manufacture
     * @param made the dateOfManufacture to set
     */
    public void setMade(LocalDate made) {
        this.made = made;
    }
    
}
