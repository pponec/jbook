/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s01_hello;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.xml.builder.XmlBuilder;

/** An explicit implementation based on the Element model */
@WebServlet("/helloExtended")
public class HelloWorldExplicit extends HttpServlet {
    /** Character set of the HTML page */
    private static final Charset CHARSET = StandardCharsets.UTF_8;

    /** Handles the HTTP GET method */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setCharacterEncoding(CHARSET.toString());
        try (XmlBuilder html = XmlBuilder.forNiceHtml(response.getWriter())) {
            html.setAttribute("lang", "en");
            try(XmlBuilder head = html.addElement("head")) {
               head.addElement("meta").setAttribute("charset", CHARSET);
               head.addElement("title").addText("Demo");
               head.addElement("link").setAttribute("href", "css/basic.css").setAttribute("rel", "stylesheet");
            }
            try(XmlBuilder body = html.addElement("body")) {
               body.addElement("h1").addText("Hello, World! (explicit)");
               WebTools.addFooter(body, this);
            }
        }
    }
}
