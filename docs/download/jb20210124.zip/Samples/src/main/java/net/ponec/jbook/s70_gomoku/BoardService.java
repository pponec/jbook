/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s70_gomoku;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;

/** A board game services */
public class BoardService {

    /** Logger */
    private static final Logger LOGGER = Logger.getLogger(BoardService.class.getName());
    /** Hidden data input */
    public static final String BOARD_PARAM = "board";
    /** Cell prefix */
    public static final String CELL_PREFIX_PARAM = "c";

    /** See a factory metod: {@link #of() } */
    protected BoardService() {
    }

    /** Create a board model from input parameters */
    public BoardModel createBoardModel(HttpServletRequest request) {
        BoardModel result;
        final int width = 23;
        final int height = 13;

        try {
            result = new BoardModel(width, height, request.getParameter(BoardService.BOARD_PARAM));
            final Enumeration<String> params = request.getParameterNames();
            while (params.hasMoreElements()) {
                final String param = params.nextElement();
                if (param.startsWith(CELL_PREFIX_PARAM)) {
                    BoardPoint lastMove = new BoardPoint().setPointIndex(Integer.parseInt(param.substring(1)), width);
                    result.setStone(lastMove, StoneEnum.BLACK_STONE);
                    closeGameOnVictory(result);
                    if (!result.isGamewOver()) {
                        mashineMoves(result);
                        closeGameOnVictory(result);
                    }
                    break;
                }
            }
        } catch (Exception e) {
            String msg = String.format("An internal error (%s)", e.getClass().getSimpleName());
            result = new BoardModel(width, height, null);
            result.setErrorMessage(msg);
            LOGGER.log(Level.WARNING, msg, e);
        }
        return result;
    }

    /** Close the game in case of victory */
    public void closeGameOnVictory(BoardModel board) {
        if (isWinner(board, GoMokuServlet.WINNING_STONE_COUNT)) {
            board.gameOver();
        }
    }

    /** Check it the point is out of border */
    protected boolean isWinner(BoardModel board, int requiredStoneCount) {
        for (DirectionEnum direction : DirectionEnum.values()) {
            if (getDirectionBorder(board, direction, requiredStoneCount) != null) {
                return true;
            }
        }
        return false;
    }

    /** Returns a two border points out of line for a required stones, or the null */
    protected BoardPoint[] getDirectionBorder(BoardModel board, DirectionEnum direction, int requiredStoneCount) {
        final BoardPoint firstPoint = board.getLastMove().clonePoint();
        final BoardPoint lastPoint = firstPoint.clonePoint();
        final StoneEnum myStone = board.getStone(board.getLastMove());

        while (board.hasStone(firstPoint, myStone)) {
            direction.move(firstPoint, true);
        }
        while (board.hasStone(lastPoint, myStone)) {
            direction.move(lastPoint, false);
        }
        if (firstPoint.getDistance(lastPoint) >= (requiredStoneCount + 1)) {
            return new BoardPoint[]{firstPoint, lastPoint};
        }
        return null;
    }

    /** The machine is on the move */
    public void mashineMoves(BoardModel board) {
        final StoneEnum playerStone = board.getStone(board.getLastMove());
        final StoneEnum machineStone = board.getOpponentStone(playerStone);
        getNextPoint(board).ifPresent(point -> board.setStone(point, machineStone));
    }

    /** Get the next point */
    protected Optional<BoardPoint> getNextPoint(final BoardModel board) {
        final BoardPoint lastMove = board.getLastMove();
        for (int count = GoMokuServlet.WINNING_STONE_COUNT - 1; count >= 2; count--) {
            for (DirectionEnum direction : DirectionEnum.values()) {
                final BoardPoint[] points = getDirectionBorder(board, direction, count);
                if (points != null) {
                    for (BoardPoint borderPoint : points) {
                        if (board.hasStone(borderPoint, StoneEnum.NO_STONE)) {
                            return Optional.of(borderPoint);
                        }
                    }
                }
            }
        }
        final List<BoardPoint> points = getFreePoints(board, lastMove);
        return points.isEmpty() 
             ? Optional.empty()
             : Optional.of(points.get(new Random().nextInt(points.size())));
    }

    /** Get all free points arround lastMove */
    public List<BoardPoint> getFreePoints(final BoardModel board, final BoardPoint lastMove) {
        final ArrayList<BoardPoint> result = new ArrayList<>();
        final boolean[] orientations = {true, false};

        for (DirectionEnum direction : DirectionEnum.values()) {
            for (boolean forward : orientations) {
                final BoardPoint borderPoint = direction.move(lastMove.clonePoint(), forward);
                if (board.hasStone(borderPoint, StoneEnum.NO_STONE)) {
                    result.add(borderPoint);
                }
            }
        }
        return result;
    }

    /** Returns a winning message. */
    public Optional<String> getWinnerMessage(BoardModel board) {
        return getWinnerMessage("The game is over, %s won!", "computer", "human", board);
    }

    /** Build a winning message. */
    public Optional<String> getWinnerMessage(String msgTemplate, String computer, String human, BoardModel board) {
        return board.getWinnerName(computer, human).map(who -> String.format(msgTemplate, who));
    }
    
    /** Service factory */
    public static BoardService of() {
        final boolean extendedStrategy = true;
        if (extendedStrategy) {
            return new ExtendedBoardService();
        } else {
            return new BoardService();
        }
    }

}
