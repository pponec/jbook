/* Copyright 2018-2020 Pavel Ponec, https;//jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

/**
 * A data model of a road vehicle that operates on rails and has an engine or a motor
 */
public abstract class MotorVehicle extends RoadVehicle {

    /** License Plate of the Vehicle */
    private String licensePlate;
    /** Serial number or the engine */
    private String motorSerialNumber;
    /** Engine Power in kW */
    private Integer enginePower;
    /** Type of fuel */
    private EnergyType energy;

    /**
     * License Plate of the Vehicle
     * @return the licensePlate
     */
    public String getLicensePlate() {
        return licensePlate;
    }

    /**
     * License Plate of the Vehicle
     * @param licensePlate the licensePlate to set
     */
    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    /**
     * Serial number or the engine
     * @return the motorSerialNumber
     */
    public String getMotorSerialNumber() {
        return motorSerialNumber;
    }

    /**
     * Serial number or the engine
     * @param motorSerialNumber the motorSerialNumber to set
     */
    public void setMotorSerialNumber(String motorSerialNumber) {
        this.motorSerialNumber = motorSerialNumber;
    }

    /**
     * Engine Power in kW
     * @return the enginePower
     */
    public Integer getEnginePower() {
        return enginePower;
    }

    /**
     * Engine Power in kW
     * @param enginePower the enginePower to set
     */
    public void setEnginePower(Integer enginePower) {
        this.enginePower = enginePower;
    }

    /**
     * Type of fuel
     * @return the energy
     */
    public EnergyType getEnergy() {
        return energy;
    }

    /**
     * Type of fuel
     * @param energy the energy to set
     */
    public void setEnergy(EnergyType energy) {
        this.energy = energy;
    }

}
