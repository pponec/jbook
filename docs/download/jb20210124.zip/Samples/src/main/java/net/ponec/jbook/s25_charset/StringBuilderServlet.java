/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s25_charset;

import java.io.IOException;
import java.util.Enumeration;
import java.util.StringJoiner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;

/** User text builder */
@WebServlet("/StringBuilderServlet")
public class StringBuilderServlet extends HttpServlet {

    /** Logger */
    private static final Logger LOGGER = Logger.getLogger(StringBuilderServlet.class.getName());

    /** Count of characters on the board */
    public static final int CHARACTER_COUNT = 6;

    /** Hidden data input */
    public static final String BOARD_PARAM = "board";

    /** Cell prefix */
    public static final String CELL_PREFIX_PARAM = "c";

    /**
     * Handles the HTTP <code>GET</code> or <code>POST</code> method.
     * @param request A servlet request encoded by UTF_8
     * @param respnse A servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse respnse)
            throws ServletException, IOException {
        try (HtmlElement html = HtmlElement.niceOf("String building by charset", respnse, "css/board.css", "css/table.css")) {
            ExtendedBoardModel boardModel = createBoardModel(request);
            html.getBody().addHeading(html.getTitle());
            Element form = createFormElement(html.getBody(), boardModel);
            boardModel.getErrorMessage().ifPresent(msg -> form.addSpan("msg").addText(msg)); // Print an error message
            createMainBoard(form, boardModel);
            createResetButton(form, "New text");
            html.getBody().addTable(getTableModel(boardModel), "data");

            WebTools.addFooter(html, this);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Servlet failed", e);
        }
    }

    /** Create a board model from input parameters */
    private ExtendedBoardModel createBoardModel(HttpServletRequest request) {
        ExtendedBoardModel result;
        try {
            result = new ExtendedBoardModel(CHARACTER_COUNT, request.getParameter(StringBuilderServlet.BOARD_PARAM));
            final Enumeration<String> params = request.getParameterNames();
            while (params.hasMoreElements()) {
                final String param = params.nextElement();
                if (param.startsWith(CELL_PREFIX_PARAM)) {
                    int pointer = Integer.parseInt(param.substring(1));
                    result.flipStone(pointer);
                    break;
                }
            }
        } catch (Exception e) {
            String msg = "An error processing parameters";
            LOGGER.log(Level.WARNING, msg, e);
            result = new ExtendedBoardModel(CHARACTER_COUNT, null);
            result.setErrorMessage(msg);
        }
        return result;
    }

    /** Create a form element including hidden field */
    private Element createFormElement(final Element parent, ExtendedBoardModel board) {
        Element result = parent.addForm()
                .setMethod(Html.V_GET);
        result.addInput()
                .setType(Html.V_HIDDEN)
                .setName(StringBuilderServlet.BOARD_PARAM)
                .setValue(board.exportBoard());
        return result;
    }

    /** Create a clear button element */
    private void createResetButton(Element parent, String title) {
        parent.addAnchor(WebTools.getUrlOfServlet(getClass()), "btn", "btn-primary").addText(title);
    }

    /** Create a boad element */
    protected void createMainBoard(Element parent, ExtendedBoardModel board) {
        final Element table = parent.addTable("board");
        final Element titleRow = table.addTableRow();
        for (int x = 0; x < CHARACTER_COUNT; x++) {
            titleRow.addTableDetail(createCss(board, true, x))
                    .setColSpan(ExtendedBoardModel.BITS_PER_CHAR)
                    .addText(board.getCharOfTable(x));
        }
        Element boardRow = table.addTableRow();
        for (int x = 0; x < board.getWidth(); x++) {
            boardRow.addTableDetail(createCss(board, false, x))
                .addSubmitButton()
                .setName(CELL_PREFIX_PARAM + x)
                .setValue("")
                .addText("");
        }
    }

    /** Create CSS style by a HTML table coordinates */
    private String createCss(ExtendedBoardModel board, boolean title, int x) {
        final StringJoiner result = new StringJoiner(" ");
        if (!title && board.hasStone(x, 0)) {
            result.add("s");
        }
        if (title || (x + 1) % ExtendedBoardModel.BITS_PER_CHAR == 0) {
            result.add("border");
        }
        return result.toString();
    }

    /** Returns a CharacterSet data report */
    public Object[][] getTableModel(ExtendedBoardModel boardModel) {
        int mask = (int) Math.pow(2, ExtendedBoardModel.BITS_PER_CHAR);
        Object[][] result = new Object[boardModel.getCharsetSize() + 1][];
        result[0] = new Object[] {"Number", "Character", "Binary"};

        for (int i = 0; i < boardModel.getCharsetSize(); i++) {
            result[i + 1] = new Object[] 
                { i
                , boardModel.getCharOfSet(i)
                , Integer.toBinaryString(i | mask).substring(1)
                };
        }
        return result;
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
