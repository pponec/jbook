/* Copyright 2018-2020 Pavel Ponec */
package net.ponec.jbook.tools;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.annotation.Nonnull;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.ujorm.tools.Check;
import org.ujorm.tools.msg.MsgFormatter;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.HtmlElement;

/**
 * Source viewer
 * @author Pavel Ponec
 */
@WebServlet(SourceViewer.URL_PATTERN)
public class SourceViewer extends HttpServlet {

    /** A private logger */
    private static final Logger LOGGER = Logger.getLogger(SourceViewer.class.getName());

    /** Max rows of the source code */
    public static final int DEFAULT_SOURCE_ROWS = 13;

    /** URL pattern */
    public static final String URL_PATTERN = "/sample";

    /** Source parameter */
    public static final String PARAM_SRC = "src";

    /** Index parameter */
    public static final String PARAM_IDX = "idx";

    /** Google pretify URL */
    public static final String PRETIFY_URL = "/css/google-code-prettify/";

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param input servlet request
     * @param output servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest input, HttpServletResponse output) throws ServletException, IOException {
        final Model model = new Model(input);
        final String title = MsgFormatter.format("Source code{} of the {} servlet class"
                , model.size() > 1 ? "s" : ""
                , model.getMainClass().getSimpleName());
        final CharSequence[] css =
                { PRETIFY_URL.concat("prettify.css")
                , "/css/source.css"
                , "/css/tabs.css"
        };

        try (HtmlElement html = HtmlElement.of(title, output, css)) {
            html.addJavascriptLink(true, PRETIFY_URL.concat("prettify.js"));
            Element body = html.getBody().setAttribute("onload", "prettyPrint()");
            body.addHeading(1, title);

            try (Element content = body.addDiv("content")) {
                try (Element ul = content.addUnorderedlist("nav", "nav-pills")) {
                    for (int i = 0, max = model.size(); i < max; i++) {
                        String url = WebTools.getUrlOfServlet(getClass()
                                , String.join("=", PARAM_SRC, model.getMainClass().getName())
                                , String.join("=", PARAM_IDX, Integer.toString(i)));
                        ul.addListItem(i == model.getIndex() ? "active" : null)
                                .addAnchoredText(url, model.getClass(i).getSimpleName(), ".java");
                    }
                }
                if (HttpServlet.class.isAssignableFrom(model.getMainClass())) {
                    content.addPreformatted("prettyprint lang-java linenums")
                           .addText(WebTools.getResourceAsString(model.getSelectedClass(), 
                                   SourceViewer.this.getMaxSourceRows(model.getMainClass())));
                }
            }
            WebTools.createSourceFooter(body, model.getMainClass());
        }
    }
    
    /** Get souce count from a resource bundle */ 
    private int getMaxSourceRowCount() {
        final Properties prop = new Properties();
        try (InputStream is = getClass().getResourceAsStream("/WebTools.properties")) {
            prop.load(is);
            int result = Integer.parseInt(prop.getProperty("maxSourceRows", "" + DEFAULT_SOURCE_ROWS));
            return result <= 0 ? Integer.MAX_VALUE : result;
        } 
        catch (Exception e) {
            return DEFAULT_SOURCE_ROWS;
        }
    }

    private int getMaxSourceRows(Class<HttpServlet> mainClass) {
        int maxSources = getMaxSourceRowCount();
        if (maxSources == Integer.MAX_VALUE) {
            return maxSources;
        }
        if (Pattern.matches(".*\\.s0[1-5]_.*", mainClass.getPackage().toString())) {
            return Integer.MAX_VALUE;
        }
        return maxSources;
    }

    /** To post */
    @Override
    protected void doPost(HttpServletRequest input, HttpServletResponse output) throws ServletException, IOException {
        doGet(input, output);
    }

    /** Servlet data model */
    private static final class Model {

        /** Sample Map */
        private static final SourceMap SAMPLE_MAP = SourceMap.createInstance(false);

        /** Main servlet class */
        private final Class<HttpServlet> mainClass;

        /** Class list */
        private final List<Class> classList;

        /** An index of the class list */
        private final int index;

        public Model(@Nonnull final HttpServletRequest request) {
            mainClass = createClass(request);
            classList = SAMPLE_MAP.getClasses(mainClass);
            index = createIndex(request);
        }

        /** Get a resource class where a HttpServlet class is returned by default */
        @Nonnull
        private Class<HttpServlet> createClass(@Nonnull HttpServletRequest input) {
            try {
                return (Class<HttpServlet>) Class.forName(input.getParameter(PARAM_SRC));
            } catch (ClassNotFoundException e) {
                LOGGER.log(Level.WARNING, "Missing source for the " + input.getClass(), e);
                return HttpServlet.class;
            }
        }

        public int createIndex(@Nonnull HttpServletRequest input) {
            final String index = input.getParameter(PARAM_IDX);
            try {
                int result = Check.hasLength(index) ? Integer.parseInt(index) : 0;
                return getClass(result) != null ? result : 0; // Check renge of the result;
            } catch (Exception e) {
                LOGGER.log(Level.WARNING, "Incorrect parametr value:" + index, e);
                return 0;
            }
        }

        public Class getClass(int i) {
            return classList.get(i);
        }

        public Class getSelectedClass() {
            return classList.get(index);
        }

        public Class<HttpServlet> getMainClass() {
            return mainClass;
        }

        public int getIndex() {
            return index;
        }

        public int size() {
            return classList.size();
        }
    }
}

