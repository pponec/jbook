# File README.txt

* Projed License:  Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net
* English home page: https://jbook.ponec.net/
* Czech home page: https://jbook.ponec.net/cs.html

## Environment

- Internet Access
- Java Development Kit version 8.0 or better
- Apache Maven version 3.5.0 or better
- Internet browser supporting with HTML5 support including CSS 3 (for example latest Chrome, Mozilla Firefox)

## Run the project on Windows:

- Download an unzip the project to a new directory
- In the directory run command sequentions
-- $ mvnw clean install
-- $ mvnw -f Samples/pom.xml jetty:run
-- $ firefox http://localhost:8080/

## Run the project on Linux:

- Download an unzip the project to a new directory
- In the directory run command sequentions
-- $ sh mvnw clean install
-- $ sh mvnw -f Samples/pom.xml jetty:run
-- $ firefox http://localhost:8080/

--EOF
