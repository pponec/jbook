package net.ponec.jbook.s70_database.dao;

import net.ponec.jbook.s70_database.entity.City;
import org.ujorm.tools.sql.SqlParamBuilder;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.logging.Logger;

public class CityDao extends AbstractDao<City> {
    private static final Logger LOGGER = Logger.getLogger(CityDao.class.getName());

    public CityDao(Connection connection) {
        super(connection);
    }

    @Override
    public void createTable() {
        executeStatements("""
                CREATE TABLE city (
                    id BIGINT PRIMARY KEY AUTO_INCREMENT,
                    name VARCHAR(255) NOT NULL,
                    country_code CHAR(2) NOT NULL
                );
                CREATE UNIQUE INDEX idx_city_name ON city(name);
                """);
    }

    @Override
    public Optional<City> findById(long id) {
        var sql = """
                SELECT id, name, country_code
                FROM city
                WHERE id = :id
                """;
        try (SqlParamBuilder builder = builder()) {
            return builder.sql(sql)
                    .bind("id", id)
                    .streamMap(resultSet -> map(resultSet))
                    .findFirst();
        }
    }

    public Optional<City> findByName(String name) {
        var sql = """
                SELECT id, name, country_code
                FROM city 
                WHERE name = :name
                """;
        try (SqlParamBuilder builder = builder()) {
            return builder.sql(sql)
                    .bind("name", name)
                    .streamMap(resultSet -> map(resultSet))
                    .findFirst();
        }
    }

    /** Map a ResultSet to City */
    private static City map(ResultSet rs) throws SQLException {
        City result = new City();
        result.setId(rs.getLong("id"));
        result.setName(rs.getString("name"));
        result.setCountryCode(rs.getString("country_code"));
        return result;
    }

    @Override
    public long insert(City entity) {
        String sql = """
                        INSERT INTO city
                        ( name, country_code ) VALUES
                        ( :name, :countryCode )
                        """;
        try (SqlParamBuilder builder = builder()) {
            LOGGER.fine("City: " + entity);
            builder.sql(sql)
                    .bind("name", entity.getName())
                    .bind("countryCode", entity.getCountryCode())
                    .executeInsert();
            return getFirstInsertedId(builder);
        }
    }
}
