/* Copyright 2018-2026 Pavel Ponec */
package net.ponec.jbook.tools;

import java.io.BufferedReader;
import java.io.CharArrayWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import static java.nio.charset.StandardCharsets.UTF_8;
import java.util.Enumeration;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletResponse;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.ujorm.tools.Check;
import org.ujorm.tools.msg.MsgFormatter;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.xml.ApiElement;
import org.ujorm.tools.xml.builder.XmlBuilder;
import org.ujorm.tools.xml.builder.XmlPrinter;
import org.ujorm.tools.xml.config.XmlConfig;
import org.ujorm.tools.xml.config.impl.DefaultXmlConfig;

/**
 * Sample tools
 * @author Pavel Ponec
 */
public class WebTools {

    /** Internal Server Error
     * A generic error message, given when an unexpected condition was encountered and no more specific message is suitable */
    public static final int INTERNAL_SERVER_ERROR_CODE = 500;

    private static final Pattern MULTI_SPACE = Pattern.compile("\\s+");

    /** A private logger */
    private static final Logger LOGGER = Logger.getLogger(WebTools.class.getName());

    /** Link to the home page of the book */
    public static final String JBOOK_LINK = "https://jbook.ponec.net/cs3";

    /** Enable version */
    private static final boolean ENABLE_VERSION = false;

    /** Image presentation mode */
    private static final Image IMAGE = Image.ENABLED;

    /** Open the realation in the new window of the broser */
    private static final boolean RELATION_TO_NEW_WINDOW = false;

    /** Markup descriptor for a menu servlet */
    public static final String MENU_DESCRIPTION = "MENU";

    /** Navigation text to a source code */
    private static final String SOURCE_CODE = "source code";

    /** Navigation text to a source code */
    private static final String SPACE = " ";

    /** Maximal row count of the text to the print */
    private static final int MAX_SOURCE_ROWS = 10_000;

    /** Template for a source link */
    public static final String SOURCE_LINK_TEMPLATE = MsgFormatter.format("{}?{}={}",
            SourceViewer.URL_PATTERN,
            SourceViewer.PARAM_SRC,
            "{}");

    /** Create a link to the source code of the sample */
    private static String getSourceLink(Class<? extends HttpServlet> servletClass) {
        return MsgFormatter.format(SOURCE_LINK_TEMPLATE, servletClass.getName());
    }

    /**
     * Add a common footer for DOM
     * @param parent A target element or an instance of the HtmlElement
     * @param servlet The current servlet
     * @throws IOException
     */
    public static void addFooter(final HtmlElement parent, HttpServlet servlet) {
        ApiElement element = (parent instanceof HtmlElement) ? parent.getBody() : parent;
        buildFooter(element.addElement(Html.DIV), servlet.getClass());
    }

    /** Add a common footer for DOM */
    public static void writeError(HttpServletResponse servlet, Throwable e) throws IOException {
        final Throwable causedBy = e.getCause() != null ? e.getCause() : e;
        final String msg = "An internal error (%s)".formatted(causedBy.getClass().getSimpleName());
        LOGGER.log(Level.WARNING, msg, e);
        servlet.getWriter().write(msg);
        servlet.setStatus(INTERNAL_SERVER_ERROR_CODE);
    }

    /** Write a stackTrace to the element */
    public static void writeStackTrace(final ApiElement element, final Throwable exception) {
        CharArrayWriter writer = new CharArrayWriter();
        exception.printStackTrace(new PrintWriter(writer, true));
        element.addText(writer);
    }

    /** Build the footer of the body */
    public static void buildFooter(final ApiElement footer, Class<? extends HttpServlet> servletClass) {
        footer.setAttribute(Html.A_CLASS, "footer");
        Element builder = Element.of(footer);
        if (isDefaultServlet(servletClass)) {
            builder.addText("See a ");
            builder.addLinkedText(getSourceLink(servletClass), servletClass.getSimpleName());
            builder.addText(SPACE, SOURCE_CODE);
        } else {
            switch (IMAGE) {
                case EMBEDDED:
                    builder.addImage(WebTools.class.getResourceAsStream("/META-INF/resources/image/house.png"), "Home");
                    break;
                case ENABLED:
                    builder.addImage("/image/house.png", "Home");
                    break;
            }
            builder.addText(SPACE);
            builder.addText("Go back to", SPACE);
            builder.addLinkedText("/", "the menu");
            builder.addText(SPACE, "or show a", SPACE);
            builder.addLinkedText(getSourceLink(servletClass), SOURCE_CODE);
            builder.addText(SPACE, "(").addText(servletClass.getSimpleName()).addText(")");
        }
        addBookLink(builder, true);
        if (ENABLE_VERSION) {
            addVersion(builder, true);
        }
        builder.addRawText("\n\t\t");
    }

    /** Create a single line footer for the {@code HelloWorldServlet} */
    public static CharSequence createFooter(@NotNull final HttpServlet servlet) throws IOException {
        return MULTI_SPACE.matcher(createFooter(0, servlet)).replaceAll(" ");
    }

    /** Create a footer for the {@code HelloWorldServlet} */
    public static CharSequence createFooter(int level, @NotNull final HttpServlet servlet) {
        StringBuilder result = new StringBuilder();
        DefaultXmlConfig config = XmlConfig.ofDefault();
        config.setNiceFormat();
        config.setDoctype("");
        config.setFirstLevel(level);
        XmlPrinter printer = new XmlPrinter(result, config);
        try (XmlBuilder builder = new XmlBuilder(Html.DIV, printer, level)) {
            buildFooter(builder, servlet.getClass());
        }
        return result.substring(1);
    }

    /** Create a source footer */
    public static void createSourceFooter(@NotNull final ApiElement parent, @NotNull final Class<? extends HttpServlet> servletClass) {
        Element builder = Element.of(parent).addDiv("footer");
        switch (IMAGE) {
            case EMBEDDED:
                builder.addImage(WebTools.class.getResourceAsStream("/META-INF/resources/image/house.png"), "Home");
                break;
            case ENABLED:
                builder.addImage("/image/house.png", "Home");
                break;
        }
        builder.addText(SPACE, "Go back to a", SPACE)
                .addAnchor(WebTools.getUrlOfServlet(servletClass, MENU_DESCRIPTION))
                .setAttribute(Html.A_TARGET, RELATION_TO_NEW_WINDOW ? Html.V_BLANK : null)
                .addText("web page");
        builder.addText(SPACE, "or go to", SPACE)
                .addLinkedText("/", "the menu");
        addBookLink(builder, true);
        if (ENABLE_VERSION) {
            addVersion(builder, true);
        }
    }

    /** Is it the main menu servlet?
     * @param servletClass
     * @see #MENU_DESCRIPTION
     */
    public static boolean isMenu(Class<?> servletClass) {
        final WebServlet[] webServlet = servletClass.getAnnotationsByType(WebServlet.class);
        return Check.hasLength(webServlet)
                && MENU_DESCRIPTION.equals(webServlet[0].description());
    }

    /** Is it the root servlet? */
    public static boolean isDefaultServlet(Class<?> servletClass) {
        return hasUrlPatterns(servletClass, "");
    }

    /** Is it the main menu servlet? */
    public static boolean hasUrlPatterns(@NotNull final Class<?> servletClass, @Nullable final String urlParent) {
        for (WebServlet servlet : servletClass.getAnnotationsByType(WebServlet.class)) {
            for (String pattern : servlet.value()) {
                if (pattern.equals(urlParent)) {
                    return true;
                }
            }
            for (String pattern : servlet.urlPatterns()) {
                if (pattern.equals(urlParent)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Reads required source file as a string.
     *
     * @param javaClass the path to the resource file
     * @return the file's contents or null if the file could not be opened
     */
    public static String getResourceAsString(@NotNull Class javaClass, int maxRows) {
        try {
            final String javaSource = MsgFormatter.format("/{}.java", javaClass.getName().replace('.', '/'));
            final InputStream is = javaClass.getClassLoader().getResourceAsStream(javaSource);
            if (is != null) {
                final BufferedReader reader = new BufferedReader(new InputStreamReader(is, UTF_8));
                return cropRows(reader, maxRows);
            } else {
                LOGGER.log(Level.WARNING, "Missing source: {}", javaSource);
            }
        } catch (RuntimeException e) {
            LOGGER.log(Level.WARNING, "Wrong resource " + javaClass, e);
        }
        return String.valueOf(javaClass);
    }

    /** Crop the rows according to the limit */
    private static @NotNull String cropRows(final BufferedReader reader, int limit) {
        final var myLimit = limit > MAX_SOURCE_ROWS || limit < 1 ? MAX_SOURCE_ROWS : limit;
        final var message = "// The source code has a limited number of lines here ...";
        final var newLine = "\n";
        final var counter = new AtomicInteger();
        return reader.lines()
                .limit(myLimit + 1)
                .map(row -> counter.incrementAndGet() > myLimit ? message : row)
                .collect(Collectors.joining(newLine));
    }

    /** Returns URL of the servlet of the root */
    @NotNull
    public static String getUrlOfServlet(@NotNull final Class<? extends HttpServlet> servlet, String... params) {
        final String result = getUrlOfServlet(servlet);
        if (Check.hasLength(params) && params[0] != null) {
            return result + "?" + String.join("&", params);
        }
        return result;
    }

    /** Returns an URL of the servlet of the root */
    @NotNull
    public static String getUrlOfServlet(@NotNull final Class<? extends HttpServlet> servlet) {
        String result = null;
        try {
            final WebServlet[] webServlet = servlet.getAnnotationsByType(WebServlet.class);
            if (Check.hasLength(webServlet)) {
                String[] values = webServlet[0].value();
                result = Check.hasLength(values)
                        ? values[0]
                        : null;
            }
        } catch (RuntimeException e) {
            LOGGER.log(Level.WARNING, "Servlet %s lacks anotation: %s".formatted(
                            servlet.getSimpleName(),
                            WebServlet.class.getSimpleName()),
                    e);
        }
        return result != null
                ? result
                : "/";
    }

    /** Write a footer to the element */
    protected static void addVersion(final Element parent, final boolean newLine) throws IllegalStateException {
        if (newLine) {
            parent.addBreak();
        }
        parent.addText("(Application ",
                getManifestVersion(),
                ", Java ",
                System.getProperty("java.version"),
                ")");
    }

    /** Write a footer to the element */
    protected static void addBookLink(final Element parent, final boolean newLine) throws IllegalStateException {
        if (newLine) {
            parent.addBreak();
        }
        parent.addText("of the book", SPACE);
        parent.addLinkedText(JBOOK_LINK, "Teach Yourself Java");
        parent.addText(SPACE, "by Pavel Ponec.");
        addPrivacyPolicyLink(parent);
    }

    protected static void addPrivacyPolicyLink(Element element) {
        element.addText(" See a ");
        element.addAnchor(PrivacyPolicyServlet.URL_PATTERN).addText("Privacy Policy");
    }

    /** Returns version of the current library or the {@code "UNDEFINED"} text */
    @NotNull
    public static String getManifestVersion() {
        try {
            Enumeration resEnum = Thread.currentThread().getContextClassLoader().getResources(JarFile.MANIFEST_NAME);
            while (resEnum.hasMoreElements()) {
                try {
                    URL url = (URL) resEnum.nextElement();
                    InputStream is = url.openStream();
                    if (is != null) {
                        Manifest manifest = new Manifest(is);
                        Attributes mainAttribs = manifest.getMainAttributes();
                        String vendor = mainAttribs.getValue("Implementation-Vendor-Id");
                        if (Check.hasLength(vendor)
                                && WebTools.class.getPackage().getName().startsWith(vendor)) {
                            return mainAttribs.getValue("Implementation-Version");
                        }
                    }
                } catch (RuntimeException e) {
                    LOGGER.finest(e.getMessage());
                }
            }
        } catch (IOException e) {
            LOGGER.finest(e.getMessage());
        }
        return "-";
    }

    /** Image presentation mode */
    private enum Image {
        ENABLED,
        EMBEDDED,
        DISABLED
    }
}
