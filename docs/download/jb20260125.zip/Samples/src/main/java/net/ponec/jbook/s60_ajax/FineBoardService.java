/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s60_ajax;

import net.ponec.jbook.s50_gomoku.*;
import java.util.Optional;

/**
 * Enhanced strategy for GoMoku (Connect Five).
 * It focuses on evaluating positions for both attack and defense
 * to determine the optimal move.
 */
public class FineBoardService extends BoardService {

    // Scoring constants
    private static final int SCORE_WIN = 100_000;
    private static final int SCORE_BLOCK_WIN = 90_000; // Priority: Winning > Not Losing
    private static final int SCORE_OPEN_FOUR = 10_000;
    private static final int SCORE_BLOCK_OPEN_FOUR = 9_000;
    private static final int SCORE_OPEN_THREE = 1_000;
    private static final int SCORE_BLOCK_OPEN_THREE = 900;

    @Override
    public String getTitle() {
        return "Go-moku (AI Heuristic Strategy)";
    }

    /**
     * Main method to select the best next move.
     * It iterates through free points, evaluates them, and picks the one with the highest score.
     */
    @Override
    protected Optional<BoardPoint> getNextPoint(BoardModel board) {
        // Assuming getters for width/height exist in BoardModel,
        // or using the standard 23x13 dimensions from the parent class context.
        int width = board.getWidth();
        int height = board.getHeight();

        // Determine stone types
        var lastMove = board.getLastMove();
        if (lastMove == null) {
            // If the board is empty (AI starts), play in the center
            return Optional.of(createPoint(width / 2, height / 2, width));
        }

        var humanStone = board.getStone(lastMove);
        var aiStone = board.getOpponentStone(humanStone);

        BoardPoint bestPoint = null;
        int maxScore = -1;

        // Iterate over the board grid
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                var p = createPoint(x, y, width);

                // Skip occupied points
                if (!board.hasStone(p, StoneEnum.NO_STONE)) {
                    continue;
                }

                // Optimization: Skip points far from any existing stones
                if (!hasNeighbor(board, p)) {
                    continue;
                }

                // Calculate scores
                int attackScore = evaluatePoint(board, p, aiStone);  // Benefit for AI
                int defenseScore = evaluatePoint(board, p, humanStone); // Disruption for Opponent

                // Total score combines attack and defense capabilities of the move.
                // If defenseScore is huge (blocking a win), this move becomes high priority.
                // If attackScore is huge (winning), it also becomes high priority.
                int currentScore = attackScore + defenseScore;

                // Instant Win Condition: If this move wins the game, take it immediately.
                if (attackScore >= SCORE_WIN) {
                    return Optional.of(p);
                }

                if (currentScore > maxScore) {
                    maxScore = currentScore;
                    bestPoint = p;
                }
            }
        }

        // If no strategic point is found, fallback to the parent logic (random/first available)
        return Optional.ofNullable(bestPoint).or(() -> super.getNextPoint(board));
    }

    /**
     * Evaluates the strength of a specific point for a specific stone type.
     * It checks all 4 axes (horizontal, vertical, diagonals).
     */
    private int evaluatePoint(BoardModel board, BoardPoint p, StoneEnum stoneType) {
        int totalScore = 0;

        for (DirectionEnum direction : DirectionEnum.values()) {
            totalScore += evaluateDirection(board, p, stoneType, direction);
        }

        return totalScore;
    }

    /**
     * Analyzes a specific direction from the start point.
     * Counts consecutive stones and checks if ends are open or blocked.
     */
    private int evaluateDirection(BoardModel board, BoardPoint startPoint, StoneEnum myStone, DirectionEnum direction) {
        // 1 represents the stone we are hypothetically placing at startPoint
        int consecutive = 1;
        boolean openStart = false;
        boolean openEnd = false;

        // -- Scan Forward --
        var forwardScanner = startPoint.clonePoint();
        while (true) {
            direction.move(forwardScanner, true); // move forward
            if (board.hasStone(forwardScanner, myStone)) {
                consecutive++;
            } else {
                // Check if the end of the line is empty (open) or blocked (edge/opponent)
                if (board.hasStone(forwardScanner, StoneEnum.NO_STONE)) {
                    openStart = true;
                }
                break;
            }
        }

        // -- Scan Backward --
        var backwardScanner = startPoint.clonePoint();
        while (true) {
            direction.move(backwardScanner, false); // move backward
            if (board.hasStone(backwardScanner, myStone)) {
                consecutive++;
            } else {
                if (board.hasStone(backwardScanner, StoneEnum.NO_STONE)) {
                    openEnd = true;
                }
                break;
            }
        }

        return calculateShapeScore(consecutive, openStart, openEnd);
    }

    /**
     * Maps the line shape (length + openness) to a numerical score.
     */
    private int calculateShapeScore(int length, boolean openStart, boolean openEnd) {
        if (length >= 5) {
            return SCORE_WIN;
        }
        if (length == 4) {
            if (openStart && openEnd) return SCORE_OPEN_FOUR; // Unstoppable win next turn
            if (openStart || openEnd) return SCORE_BLOCK_OPEN_FOUR / 2; // Semi-closed 4
        }
        if (length == 3) {
            if (openStart && openEnd) return SCORE_OPEN_THREE;
            if (openStart || openEnd) return SCORE_BLOCK_OPEN_THREE / 5;
        }
        if (length == 2) {
            if (openStart && openEnd) return 100;
        }
        return 0;
    }

    /**
     * Helper to reconstruct a BoardPoint from X, Y coordinates.
     * Based on the logic found in BoardService/BoardPoint.
     */
    private BoardPoint createPoint(int x, int y, int width) {
        int index = (y * width) + x;
        return new BoardPoint().setPointIndex(index, width);
    }

    /**
     * Optimization: Checks if the point has any stones in its immediate vicinity.
     * Prevents calculating scores for empty areas of the board.
     */
    private boolean hasNeighbor(BoardModel board, BoardPoint p) {
        int range = 2; // Check radius of 2 cells

        for (DirectionEnum dir : DirectionEnum.values()) {
            for (boolean forward : new boolean[]{true, false}) {
                var neighbor = p.clonePoint();
                for (int i = 0; i < range; i++) {
                    dir.move(neighbor, forward);
                    // If we find a stone (Black or White), this is a relevant area
                    if (!board.hasStone(neighbor, StoneEnum.NO_STONE)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}