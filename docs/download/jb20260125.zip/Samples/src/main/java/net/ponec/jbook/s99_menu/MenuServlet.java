/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s99_menu;

import java.io.IOException;

import jakarta.servlet.annotation.WebServlet;
import net.ponec.jbook.s01_hello.HelloWorldElement;
import net.ponec.jbook.s01_hello.HelloWorldServlet;
import net.ponec.jbook.s02_expression.ExpressionServlet;
import net.ponec.jbook.s05_table.TableRandomData;
import net.ponec.jbook.s05_table.TableServlet;
import net.ponec.jbook.s06_vehicle.VehicleServlet;
import net.ponec.jbook.s10_form.SimpleFormServlet;
import net.ponec.jbook.s10_form.UserFormServlet;
import net.ponec.jbook.s15_text.WordCounting;
import net.ponec.jbook.s20_board.BoardServlet;
import net.ponec.jbook.s20_board.HelloContext;
import net.ponec.jbook.s25_charset.StringBuilderServlet;
import net.ponec.jbook.s50_gomoku.GoMokuServlet;
import net.ponec.jbook.s60_ajax.GoMokuAjaxServlet;
import net.ponec.jbook.s60_ajax.RegexpServlet;
import net.ponec.jbook.s70_database.HotelTableServlet;
import net.ponec.jbook.tools.MyHttpServlet;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.web.request.HttpContext;

/** A live example inside a servlet */
@WebServlet(value = {"/menu", ""}, description = WebTools.MENU_DESCRIPTION)
public class MenuServlet extends MyHttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param ctx Servlet request context
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpContext ctx)  {
        try (var html = HtmlElement.niceOf("List of samples", ctx, "css/menu.css")) {
            html.getBody().addHeading(html.getTitle());
            var topList = html.getBody().addOrderedList("menu");
            var subList = (Element) null;
            for (var item : getItems()) {
                if (item.isTitle()) {
                    subList = topList.addListItem().addText(item.getLabel())
                            .addOrderedList();
                } else if (subList != null) {
                    subList.addListItem()
                           .addLinkedText(item.getLink(), item.getLabel());
                }
            }
            WebTools.addFooter(html, this);
            preloadAllIcons(html.getBody());
        }
    }

    /** Prelodad all icons by CSS */
    private void preloadAllIcons(Element element) {
        element.addDiv("preload-icons");
    }

    /** Form field description data */
    private MenuItem[] getItems() {
        return new MenuItem[]
            { new MenuItem("Basics")
            , new MenuItem(HelloWorldServlet.class, "Hello, World!")
            , new MenuItem(HelloWorldElement.class, "Hello, World! (by Element)")
            , new MenuItem(ExpressionServlet.class, "Java expressions")
            , new MenuItem("Tables")
            , new MenuItem(TableServlet.class, "The table")
            , new MenuItem(TableRandomData.class, "Table with random numbers")
            , new MenuItem(VehicleServlet.class, "Vehicle report")
            , new MenuItem("Forms")
            , new MenuItem(SimpleFormServlet.class, "text=Enter some text", "Simple form")
            , new MenuItem(UserFormServlet.class, "firstname=It's+Me!", "Simple user form")
            , new MenuItem(WordCounting.class, "text=How+many+words+does+this+text+contain?", "Word counting")
            , new MenuItem("Fun grids")
            , new MenuItem(HelloContext.class, "Hello, World! (by Context)")
            , new MenuItem(BoardServlet.class, "board=eJxjYGhoagoIEPDyOhQaumI1k2goIw8LAEefBgU%3D", "Painting board")
            , new MenuItem(StringBuilderServlet.class, "board=eJxbaMy_0JgfAAdfAcc%3D", "String building by charset")
            , new MenuItem(GoMokuServlet.class, "Go-moku (simple defensive strategy)")
            , new MenuItem("AJAX")
            , new MenuItem(RegexpServlet.class, "regexp=%5Baeiyou%5D&text=Write+once%2C+run+anywhere.+--+Sun+Microsystems", "Regular expressions")
            , new MenuItem(GoMokuAjaxServlet.class, "Go-moku with AJAX")
            , new MenuItem("Database")
            , new MenuItem(HotelTableServlet.class, "Hotel Report")
            };
    }
}
