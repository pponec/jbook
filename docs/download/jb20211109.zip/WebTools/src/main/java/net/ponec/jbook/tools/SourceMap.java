/* Copyright 2018-2020 Pavel Ponec */
package net.ponec.jbook.tools;

import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Nullable;
import javax.servlet.http.HttpServlet;

/**
 * Mapping the samples
 * @author Pavel Ponec
 */
@SuppressWarnings("ALL")
public interface SourceMap {

    /** Return an array of related classes (including the parent) */
    public List<Class> getClasses(final Class<? extends HttpServlet> servletClass);

    /** Create a target instance */
    @Nullable
    public static SourceMap createInstance(boolean throwsException) throws IllegalStateException {
        try {
            return (SourceMap) Class.forName("net.ponec.jbook.tools.SourceMapImpl").newInstance();
        } catch (ReflectiveOperationException ex) {
            if (throwsException) {
                throw new IllegalStateException(ex);
            } else {
                Logger.getLogger(SourceMap.class.getName()).log(Level.SEVERE, "Building failed", ex);
                return (Class<? extends HttpServlet> servletClass) -> Arrays.asList(servletClass);
            }
        }
    }
}
