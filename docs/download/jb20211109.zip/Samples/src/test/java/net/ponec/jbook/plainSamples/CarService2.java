/* Copyright 2018-2020 Pavel Ponec */
package net.ponec.jbook.plainSamples;

import java.time.LocalDate;
import java.time.Month;
import java.util.Locale;
import net.ponec.jbook.plainSamples.tools.Printer;
import net.ponec.jbook.s06_vehicle.domain.Car;
import net.ponec.jbook.s06_vehicle.domain.Company;
import net.ponec.jbook.s06_vehicle.domain.User;
import net.ponec.jbook.s06_vehicle.domain.VehicleModel;

/**
 * Cars
 *
 * @author Pavel Ponec
 */
public class CarService2 {

    public Car createCar() {
        Car car = new Car();
        car.setTrunkVolume(354);
        car.setMade(LocalDate.of(2010, 10, 22));

        VehicleModel model = new VehicleModel();
        model.setManufacturer(new Company("Toyota", Locale.JAPAN));
        model.setName("Yaris");
        model.setTrunkVolume(436); // liters
        car.setModel(model);

        User user = new User();
        user.setPersonalNumber(10);
        user.setFirstname("Donald");
        user.setSurname("Choresisdi");
        user.setBirthDate(LocalDate.of(1990, Month.OCTOBER, 30));
        car.setOwner(user);

        return car;
    }

    public void printCar() {
        Car car = this.createCar();

        LocalDate made = car.getMade();
        String manufacturer = car.getModel().getManufacturer().getName();
        String modelName = car.getModel().getName();
        Integer trunkVolume = car.getTrunkVolume();
        String firstname = car.getOwner().getFirstname();
        String surname = car.getOwner().getSurname();
        String owner = firstname + " " + surname;
        
        Printer.print(made, manufacturer, modelName, trunkVolume, firstname, surname, owner);

        return; // An optional statement
    }

    public String readEnergyNameOfCar() {
        return createCar().getEnergy().getName();
    }

    public void writeNulls() {
        Car car = this.createCar();
        car.getOwner().setEmail(null);
        car.setOwner(null);
        car = null;

        boolean undefinedCar = (car == null);
    }
}
