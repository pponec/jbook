/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s70_gomoku;

import org.junit.jupiter.api.Test;
import org.ujorm.tools.msg.MsgFormatter;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Pavel Ponec
 */
public class BoardPointTest {
    
     /**
     * Test of set method, of class BoardPoint.
     */
    @Test
    public void testSetXy() {
        System.out.println("set");
        int x = 1;
        int y = 2;
        BoardPoint instance = new BoardPoint();
        BoardPoint result = instance.set(x, y);
        
        assertEquals(x, result.getX());
        assertEquals(y, result.getY());

    }

    /**
     * Test of set method, of class BoardPoint.
     */
    @Test
    public void testSet_BoardPoint() {
        System.out.println("set");
        int x = 1;
        int y = 2;
        BoardPoint point = new BoardPoint(x, y);
        BoardPoint instance = new BoardPoint();
        BoardPoint result = instance.set(point);

        assertEquals(x, result.getX());
        assertEquals(y, result.getY());
    }

    /**
     * Test of getPointIndex() method of class BoardPoint.
     */
    @Test
    public void testPointIndex() {
        int x = 1;
        int y = 2;
        BoardPoint point = new BoardPoint(x, y);
        BoardModel board = new BoardModel(3, 3, null);
        int index = point.getPointIndex(board);
        assertEquals(7, index);
    }

    /**
     * Test of set method, of class BoardPoint.
     */
    @Test
    public void testSetShift() {
        System.out.println("set");
        int x = 1;
        int y = 2;
        int shiftX = 4;
        int shiftY = 5;
        BoardPoint instance = new BoardPoint(x, y);
        BoardPoint expResult = new BoardPoint(x + shiftX, y + shiftY);
        BoardPoint result = instance.set(instance, shiftX, shiftY);

        assertTrue(expResult.equals(result)); 
        assertEquals(expResult, result);
    }

    /**
     * Test of getPointIndex method, of class BoardPoint.
     */
    @Test
    public void testGetPointIndex() {
        System.out.println("getPointIndex");
        int x = 1;
        int y = 2;
        BoardModel board = new BoardModel(3, 3, null);
        BoardPoint instance = new BoardPoint(x, y);
        int expResult = board.getWidth() * y + x;
        int result = instance.getPointIndex(board);
        assertEquals(expResult, result);
    }

    /**
     * Test of setPointIndex method, of class BoardPoint.
     */
    @Test
    public void testSetPointIndex() {
        System.out.println("setPointIndex");
        int x = 1;
        int y = 2;
        int boardWidth = 3 ;
        int i = boardWidth * y + x;
        BoardPoint instance = new BoardPoint().setPointIndex(i, boardWidth);
        BoardPoint expResult = new BoardPoint(x, y);
        
        assertEquals(expResult, instance);
    }

    /**
     * Test of getDistance method, of class BoardPoint.
     */
    @Test
    public void testGetDistance() {
        System.out.println("getDistance");
        BoardPoint param =  new BoardPoint(0,0);
        BoardPoint instance = new BoardPoint(2,2);
        int expResult = 2;
        int result = instance.getDistance(param);
        assertEquals(expResult, result);
    }

    /**
     * Test of clonePoint method, of class BoardPoint.
     */
    @Test
    public void testClonePoint() {
        System.out.println("clonePoint");
        int x = 1;
        int y = 2;
        BoardPoint instance = new BoardPoint(x, y);
        BoardPoint expResult = new BoardPoint(x, y);
        BoardPoint result = instance.clonePoint();

        assertTrue(expResult.equals(result));
        assertEquals(expResult, result);
        
        instance.set(instance, 1, 1);
        assertEquals(expResult, result);
    }

    /**
     * Test of equals method, of class BoardPoint.
     */
    @Test
    public void testEquals() {
        System.out.println("equals");
        int x = 1;
        int y = 2;
        BoardPoint instance = new BoardPoint(x, y);
        BoardPoint expResult = new BoardPoint(x, y);
        
        assertTrue(expResult.equals(instance));
        assertEquals(expResult, instance);
        
        instance = expResult.clonePoint();
        assertEquals(expResult, instance);        
    }

    /**
     * Test of toString method, of class BoardPoint.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        int x = 1;
        int y = 2;
        BoardPoint instance = new BoardPoint(x, y);
        String expResult = MsgFormatter.format("[{},{}]", x, y);
        String result = instance.toString();
        assertEquals(expResult, result);
    }
    
}
