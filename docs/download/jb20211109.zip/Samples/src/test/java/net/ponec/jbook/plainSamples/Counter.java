package net.ponec.jbook.plainSamples;
import java.util.concurrent.atomic.AtomicInteger;

/** A JavaDoc description */
public class Counter {
    private final AtomicInteger count = new AtomicInteger();

    void add(int i) {
        count.addAndGet(i);
    }
    int getCount() {
        return count.get();
    }
}
