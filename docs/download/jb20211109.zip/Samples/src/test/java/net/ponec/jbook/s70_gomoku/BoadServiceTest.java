/* Copyright 2018-2020 Pavel Ponec */
package net.ponec.jbook.s70_gomoku;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * A test of BoardService class
 * @author Pavel Ponec
 */
public class BoadServiceTest {

    /**  Test the board model of the go-moku game */
    @Test
    public void testIsWinnerHorizontal() throws Exception {
        System.out.println("testIsWinner");

        final BoardService service = new BoardService();
        final StoneEnum myStone = StoneEnum.WHITE_STONE;
        final BoardModel board = new BoardModel(10, 10, null);
        final DirectionEnum horizontal = DirectionEnum.RIGHT;
        final int requiredBoardStones = 3;

        BoardPoint point = new BoardPoint(2, 2);
        board.setStone(point, myStone);
        assertNull(service.getDirectionBorder(board, horizontal, requiredBoardStones));

        point.set(point, 1, 0);
        board.setStone(point, myStone);
        assertNull(service.getDirectionBorder(board, horizontal, requiredBoardStones));

        point.set(point, 1, 0);
        board.setStone(point, myStone);
        assertNotNull(service.getDirectionBorder(board, horizontal, requiredBoardStones));

        point.set(point, 1, 0);
        board.setStone(point, myStone);
        assertNotNull(service.getDirectionBorder(board, horizontal, requiredBoardStones));
    }

    /**  Test the board model of the go-moku game */
    @Test
    public void testIsWinnerVertical() throws Exception {
        System.out.println("testIsWinner");

        final BoardService service = new BoardService();
        final StoneEnum myStone = StoneEnum.WHITE_STONE;
        final BoardModel board = new BoardModel(10, 10, null);
        final DirectionEnum horizontal = DirectionEnum.DOWN;
        final int requiredBoardStones = 3;

        BoardPoint point = new BoardPoint(2, 2);
        board.setStone(point, myStone);
        assertNull(service.getDirectionBorder(board, horizontal, requiredBoardStones));

        point.set(point, 0, 1);
        board.setStone(point, myStone);
        assertNull(service.getDirectionBorder(board, horizontal, requiredBoardStones));

        point.set(point, 0, 1);
        board.setStone(point, myStone);
        assertNotNull(service.getDirectionBorder(board, horizontal, requiredBoardStones));

        point.set(point, 0, 1);
        board.setStone(point, myStone);
        assertNotNull(service.getDirectionBorder(board, horizontal, requiredBoardStones));
    }

    /**  Test the board model of the go-moku game */
    @Test
    public void testIsWinnerRighDown() throws Exception {
        System.out.println("testIsWinner");

        final BoardService service = new BoardService();
        final StoneEnum myStone = StoneEnum.WHITE_STONE;
        final BoardModel board = new BoardModel(10, 10, null);
        final DirectionEnum horizontal = DirectionEnum.RIGHT_DOWN;
        final int requiredBoardStones = 3;

        BoardPoint point = new BoardPoint(2, 2);
        board.setStone(point, myStone);
        assertNull(service.getDirectionBorder(board, horizontal, requiredBoardStones));

        point.set(point, 1, 1);
        board.setStone(point, myStone);
        assertNull(service.getDirectionBorder(board, horizontal, requiredBoardStones));

        point.set(point, 1, 1);
        board.setStone(point, myStone);
        assertNotNull(service.getDirectionBorder(board, horizontal, requiredBoardStones));

        point.set(point, 1, 1);
        board.setStone(point, myStone);
        assertNotNull(service.getDirectionBorder(board, horizontal, requiredBoardStones));
    }

    /**  Test the board model of the go-moku game */
    @Test
    public void testIsWinner() throws Exception {
        System.out.println("testIsWinner");

        final BoardService service = new BoardService();
        final StoneEnum myStone = StoneEnum.WHITE_STONE;
        final BoardModel board = new BoardModel(10, 10, null);
        final int requiredBoardStones = 3;

        BoardPoint point = new BoardPoint(8, 2);
        board.setStone(point, myStone);
        assertFalse(service.isWinner(board, requiredBoardStones));

        point.set(point, -1, 1);
        board.setStone(point, myStone);
        assertFalse(service.isWinner(board, requiredBoardStones));

        point.set(point, -1, 1);
        board.setStone(point, myStone);
        assertTrue(service.isWinner(board, requiredBoardStones));

        point.set(point, -1, 1);
        board.setStone(point, myStone);
        assertTrue(service.isWinner(board, requiredBoardStones));
    }

}
