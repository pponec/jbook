/* Copyright 2018-2020 Pavel Ponec */
package net.ponec.jbook.plainSamples;

/**
 * Arrays
 *
 * @author Pavel Ponec
 */
public class Arrays {

    void sample1() {
        char firstCharacter = 'A';
        char secondCharacter = 'B';
        char thirdCharacter = 'C';
        char[] word = {firstCharacter, secondCharacter, thirdCharacter};
    }

    void sample2() {
        char[] word = new char[3]; // Nové pole se 3 buňkami
        word[0] = 'A';
        word[1] = 'B';
        word[2] = 'C';
    }

    void sample3() {
        char[] word = {'A', 'B', 'C'};
        char firstCharacter = word[0];
        char secondCharacter = word[1];
        char thirdCharacter = word[2];
        int length = word.length; // 3 characters
    }

    void sample4() {
        String myText = "ABC";
        char[] word = myText.toCharArray();
    }

    String[] toArray(String... texts) { // <1>
        return texts; // <2>
    }

    void test() {
        String[] words = toArray("Hello", "Word!");
        System.out.println(words[0]);
    }

    void sample() {
        Object[] words = {"AA", "BB", "CC"};
        for (int x = 0; x < words.length; x = x + 1) {
            Object word = words[x];
        }
    }
}
