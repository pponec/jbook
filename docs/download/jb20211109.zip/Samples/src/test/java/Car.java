/* Copyright 2018-2020 Pavel Ponec */
class Car {
    // -------------------------
    String modelName;
    Integer enginePower;
    // -------------------------
    String getModelName() {
        return modelName;
    }
    void setModelName(String name) {
        modelName = name;
    }
    Integer getEnginePower() {
        return enginePower;
    }
    void setEnginePower(Integer power) {
        enginePower = power;
    }
}
