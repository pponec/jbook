/* Copyright 2018-2020 Pavel Ponec */
package net.ponec.jbook.tools;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

/** A binary compressor optimized for small data */
public class ExtendedCompressor {

    /** Compressed data */
    private static final byte PLAIN = 'P';

    /** Compressed data */
    private static final byte COMPRESSED = 'C';

    /** Comppress */
    public byte[] compress(final byte[] fields) {
        final ByteArrayOutputStream result = new ByteArrayOutputStream(fields.length / 4);
        try (OutputStream out = new DeflaterOutputStream(result)) {
            out.write(fields);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
        return sign(fields, result.toByteArray());
    }

    /** Decompress */
    public byte[] decompress(final byte[] signedData) {
        final byte[] data = unsign(signedData);
        if (isPlain(signedData)) {
            return data;
        }
        final InputStream in = new InflaterInputStream(new ByteArrayInputStream(data));
        try (ByteArrayOutputStream result = new ByteArrayOutputStream(512)) {
            byte[] buffer = new byte[512];
            int len;
            while ((len = in.read(buffer)) > 0) {
                result.write(buffer, 0, len);
            }
            return result.toByteArray();
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Sign the result */
    private byte[] sign(final byte[] orig, final byte[] encoded) {
        boolean plain = orig.length <= encoded.length;
        byte[] data = plain ? orig : encoded;
        byte[] result = new byte[1 + data.length];
        result[0] =  plain ? PLAIN : COMPRESSED;
        System.arraycopy(data, 0, result, 1, data.length);
        return result;
    }

    /** Unsign the result */
    private byte[] unsign(final byte[] data) {
        byte[] result = new byte[data.length - 1];
        System.arraycopy(data, 1, result, 0, result.length);
        return result;
    }

    /** The plain */
    private boolean isPlain(final byte[] data) {
        return data.length > 0 && data[0] == PLAIN;
    }
}
