/* Copyright 2018-2020 Pavel Ponec, https;//jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

import java.util.Locale;

/** Company data model */
public class Company {

    /** Name */
    private String name;
    /** Headquarters (e.g. cs-CZ for Czech Republic */
    private Locale headquarters;

    /** Default constructor */
    public Company() {
    }

    /** Parameter constructor */
    public Company(String name, Locale headquarters) {
        this.name = name;
        this.headquarters = headquarters;
    }

    /**
     * Name
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Name
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Headquarters (e.g. cs-CZ for Czech Republic
     * @return the headquarters
     */
    public Locale getHeadquarters() {
        return headquarters;
    }

    /**
     * Headquarters (e.g. cs-CZ for Czech Republic
     * @param headquarters the headquarters to set
     */
    public void setHeadquarters(Locale headquarters) {
        this.headquarters = headquarters;
    }


    
    

    
}
