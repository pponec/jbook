/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s06_vehicle;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.s06_vehicle.domain.Car;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.HtmlElement;

/** Vehicle registration servlet */
@WebServlet( "/vehicleServlet")
public class VehicleServlet extends HttpServlet {

    /** Vehicle service */
    private RegistrationService vehicleService = new RegistrationService();

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (HtmlElement html = HtmlElement.niceOf("Vehicle report", response, "css/table.css")) {
            html.getBody().addHeading(html.getTitle());
            html.getBody().addTable(getTableModel(), "numbers");
            WebTools.addFooter(html, this);
        }
    }

    /**
     * Create a vehicle report
     * @param size Number of cells per a square table side (including labels)
     * @return A result
     */
    private List<Object[]> getTableModel() {
        List<Object[]> result = new ArrayList<>();
        Object[] header = { "Order", "Manufacturer", "Model", "Made", "Serial number"
                          , "Power [kW]", "Energy", "Trunk [l]", "Owner"};
        result.add(header); 
        for (Car car : vehicleService.getFictionalCars()) {
            String ownerName = car.getOwner().getFirstname()
                           + " "
                           + car.getOwner().getSurname();
            Object[] row = { result.size()
                           , car.getModel().getManufacturer().getName()
                           , car.getModel().getName()
                           , car.getMade()
                           , car.getMotorSerialNumber()
                           , car.getEnginePower()
                           , car.getEnergy().getName()
                           , car.getTrunkVolume()
                           , ownerName
                           };
            result.add(row);
        }
        return result;
    }
}
