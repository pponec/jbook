/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

/** Car data model */
public class Car extends MotorVehicle {
    
    /** Luggage compartment volume in liters. */
    private Integer trunkVolume;

    /**
     * Luggage compartment volume in liters.
     * @return the trunkVolume
     */
    public Integer getTrunkVolume() {
        return trunkVolume;
    }

    /**
     * Luggage compartment volume in liters.
     * @param trunkVolume the trunkVolume to set
     */
    public void setTrunkVolume(Integer trunkVolume) {
        this.trunkVolume = trunkVolume;
    }

}
