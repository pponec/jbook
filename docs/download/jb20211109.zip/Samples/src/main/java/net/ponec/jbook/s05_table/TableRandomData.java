/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s05_table;

import java.io.IOException;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.HtmlElement;

/** A live example inside a servlet */
@WebServlet("/randomTableServlet")
public class TableRandomData extends HttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (HtmlElement html = HtmlElement.niceOf("Table with random numbers", response, "css/table.css")) {
            html.getBody().addHeading(html.getTitle());
            html.getBody().addTable(getTableModel(8), "numbers");
            WebTools.addFooter(html, this);
        }
    }

    /**
     * Create a random number array
     * @param size Number of cells per a square table side (including labels)
     * @return A result
     */
    private Object[][] getTableModel(int size) {
        Object[][] result = new Object[size][size];
        Random random = new Random();
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                if (y == 0) {
                    result[y][x] = (char) ('A' + x - 1);
                } else if (x == 0) {
                    result[y][x] = y;
                } else {
                    result[y][x] = random.nextInt(500);
                }
            }
        }
        return result;
    }
}
