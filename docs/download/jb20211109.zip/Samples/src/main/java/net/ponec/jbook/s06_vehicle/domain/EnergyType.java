/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

/**
 * FuelType data model
 */
public class EnergyType {

    /** Name */
    private String name;
    /** Enerty type of fuel */
    private Boolean fuel;

    /** Default constructor */
    public EnergyType() {
    }

    /** Parameter constructor */
    public EnergyType(String name, Boolean fuel) {
        this.name = name;
        this.fuel = fuel;
    }

    /**
     * Name
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Name
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Enerty type of fuel
     * @return the fuel
     */
    public Boolean getFuel() {
        return fuel;
    }

    /**
     * Enerty type of fuel
     * @param fuel the fuel to set
     */
    public void setFuel(Boolean fuel) {
        this.fuel = fuel;
    }

}
