/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s25_charset;

import net.ponec.jbook.s20_board.SimpleBoardModel;

/** The paiting board supports the 4 bits per one character */
public class ExtendedBoardModel extends SimpleBoardModel {

    /** Bit count per one character */
    public static final int BITS_PER_CHAR = 4;

    /** A character set */
    private final Character[] charset =
            { '_', 'A', 'B', 'C'
            , 'D', 'E', 'F', 'G'
            , 'H', 'I', 'J', 'K'
            , 'L', 'M', 'N', 'O' };

    /** Constructor */
    public ExtendedBoardModel(int charCount, String content) {
        super(charCount * BITS_PER_CHAR, 1, content);
    }
    
    /** Get a character of set */
    public Character getCharOfSet(int charId) {
        return charset[charId];
    }

    /** Get a character of table */
    public Character getCharOfTable(int cell) {
        return charset[getCharacterId(cell)];
    }

    /** Get a character identifier by order */
    protected int getCharacterId(int charOrder) {
        int result = 0;
        for (int j = 0; j < BITS_PER_CHAR; j++) {
            int x = j + charOrder * BITS_PER_CHAR;
            int y = 0;
            boolean stone = hasStone(x, y);
            result = result * 2 + (stone ? 1 : 0);
        }
        return result;
    }

    /** Size of character set */
    public int getCharsetSize() {
        return charset.length;
    }
}
