/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s01_hello;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;

/** A simple servlet implementation */
@WebServlet("/helloWorld")
public class HelloWorldServlet extends HttpServlet {

    /** Handles the HTTP GET method */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String html = String.join("\n",
                "<!DOCTYPE html>",
                "<html lang='en'>",
                "    <head>",
                "        <meta charset='UTF-8'/>",
                "        <title>Demo</title>",
                "        <link href='css/basic.css' rel='stylesheet'/>",
                "    </head>",
                "    <body>",
                "        <h1>Hello, World!</h1>",
                WebTools.createFooter(2, this),
                "    </body>",
                "</html>");
        PrintWriter writer = response.getWriter();
        writer.append(html);
    }
}
