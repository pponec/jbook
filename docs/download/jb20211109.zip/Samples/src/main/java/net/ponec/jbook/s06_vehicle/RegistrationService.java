/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s06_vehicle;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.ponec.jbook.s06_vehicle.domain.*;

/** An example of the service */
public class RegistrationService {
    
    /** Get a fictional cars */
    public List<Car> getFictionalCars() {

        User owner1 = createUser(1, "Jiří", "Mexedolid", LocalDate.of(2001, Month.MARCH, 15));
        User owner2 = createUser(2, "Lucie", "Zixerfxodf", LocalDate.of(1980, Month.AUGUST, 20));
        User owner3 = createUser(3, "Donald", "Choresisdi", LocalDate.of(1990, Month.OCTOBER, 30));
        
        Company skoda = new Company("Škoda Auto", new Locale("cs-CZ"));
        Company toyota = new Company("Toyota", Locale.JAPAN);
        Company ford = new Company("Ford", Locale.US);
        
        VehicleModel fabia = new VehicleModel(skoda, "Fabia", 260);
        VehicleModel rapid = new VehicleModel(skoda, "Rapid", 550);
        VehicleModel auris = new VehicleModel(toyota, "Auris", 354);
        VehicleModel focus = new VehicleModel(ford, "Focus", 375);
        
        EnergyType benzin = new EnergyType("benzin", true);
        
        List<Car> result = new ArrayList<>();
        result.add(createCar(fabia, LocalDate.of(2005,  6,  1), 47, benzin, "ABC-22-33", "123-654-987", 260, owner1));
        result.add(createCar(rapid, LocalDate.of(2013,  1, 15), 81, benzin, "RED-24-33", "359-985-785", 550, owner2));
        result.add(createCar(auris, LocalDate.of(2010, 10, 22), 85, benzin, "JOB-12-33", "987-654-123", 354, owner3));
        result.add(createCar(focus, LocalDate.of(2015,  3, 30), 77, benzin, "XYZ-54-33", "958-232-497", 375, owner3));
       
        return result;        
    }
    
    /**
     * Find a car by its engine number
     *
     * @param motorSerialNumber Serial number of the motor
     * @return The required car or the {@code null} value, of no card was found.
     */
    public Car findCar(Integer motorSerialNumber) {
        if (motorSerialNumber == null) {
            throw new IllegalArgumentException("Undefined motorSerialNumber");
        }
        for (Car car : getFictionalCars()) {
            if (motorSerialNumber.equals(car.getMotorSerialNumber())) {
                return car;
            }

        }
        return null;
    }
    
    /** Create new user with generated email */
    private User createUser
                 ( Integer personalNumber
                 , String firstname
                 , String surname
                 , LocalDate birthDate) {
                     
        User result = new User();
        result.setPersonalNumber(personalNumber);
        result.setFirstname(firstname);
        result.setSurname(surname);
        result.setBirthDate(birthDate);
        result.setEmail(String.format("%s.%s@test.com", firstname.toLowerCase(), surname.toLowerCase()));
        
        return result;
    }

    /** Create an instance of the car */
    private Car createCar
                ( VehicleModel model
                , LocalDate made
                , Integer power
                , EnergyType energy
                , String licensePlate
                , String motorSerialNumber
                , Integer trunkVolume
                , User owner) {
                    
        Car result = new Car();
        result.setModel(model);
        result.setMade(made);
        result.setEnginePower(power);
        result.setEnergy(energy);
        result.setLicensePlate(licensePlate);
        result.setMotorSerialNumber(motorSerialNumber);
        result.setTrunkVolume(trunkVolume);
        result.setOwner(owner);
        
        return result;
    }
 
}
