/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s70_gomoku;

/** A field locator of the board is a mutable object. */
public final class BoardPoint {

    private int x;
    private int y;
    
    /** Default constructor */
    public BoardPoint() {
    }

    /** Argument constructor constructor */
    public BoardPoint(final int x, final int y) {
        set(x, y);
    }
    
    /** Set new coordinates */
    public BoardPoint set(final int x, final int y) {
        this.x = x;
        this.y = y;
        return this;
    }

    /** Set new coordinates */
    public BoardPoint set(final BoardPoint point) {
        return set(point.x, point.y);
    }

    /** Set new coordinates */
    public BoardPoint set(final BoardPoint point, final int shiftX, final int shiftY) {
        return set(point.x + shiftX, point.y + shiftY);
    }

    /** Returns a X-coordinate position */
    public int getX() {
        return x;
    }

    /** Returns a Y-coordinate position */
    public int getY() {
        return y;
    }

    /** Get a point index */
    public int getPointIndex(BoardModel board) {
        return x + y * board.getWidth();
    }

    /** Set a point by an field index */
    public BoardPoint setPointIndex(final int i, final int boardWidth) {
        return set(i % boardWidth,
                 i / boardWidth);
    }

    /** Return an absolute length to a next point */
    public int getDistance(BoardPoint param) {
        int dx = Math.abs(this.x - param.x);
        int dy = Math.abs(this.y - param.y);
        return Math.max(dx, dy);
    }
    
    /** Clone the point */
    public BoardPoint clonePoint() {
        return new BoardPoint().set(this);
    }
    
    /** Compare the point to another */
    public boolean equals(Object param) {
        return param instanceof BoardPoint && equals((BoardPoint) param);
    }

    /** Compare the point to another */
    public boolean equals(BoardPoint param) {
        return this.x == param.x
            && this.y == param.y;
    }

    /** Text for a debugging */
    @Override
    public String toString() {
        return String.format("[%s,%s]", x, y);
    }
}