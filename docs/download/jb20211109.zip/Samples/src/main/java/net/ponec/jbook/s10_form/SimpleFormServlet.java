/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s10_form;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;

/** A live example inside a servlet */
@WebServlet( "/simpleFormServlet")
public class SimpleFormServlet extends HttpServlet {

    /* A common code page form request and response. */
    private static final Charset CHARSET = StandardCharsets.UTF_8;
    /** A name of supported parameter */
    private static final String PARAMETER_NAME = "text";

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding(CHARSET.toString());

        try (HtmlElement html = HtmlElement.niceOf("Simple form", response, CHARSET, "css/form.css")) {
            html.getBody().addHeading(html.getTitle());
            Element form = html.getBody().addForm()
                    .setMethod(Html.V_POST)
                    .setAction(request.getRequestURI());
            try (Element line = form.addDiv()) {
                line.addLabel().addText("Some text");
                line.addTextInput()
                        .setName(PARAMETER_NAME)
                        .setValue(request.getParameter(PARAMETER_NAME));
            }
            form.addInput()
                    .setType(Html.V_SUBMIT)
                    .setValue("Submit");

            WebTools.addFooter(html, this);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
