/* Copyright 2018-2020 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s99_menu;

import javax.servlet.http.HttpServlet;
import net.ponec.jbook.tools.WebTools;

/** Item description */
public class MenuItem {

    /** Servlet class */
    private final Class<? extends HttpServlet> servletClass;
    /** HTTP parameters */
    private final String params;
    /** Menu item */
    private final String label;

    public MenuItem(String label) {
        this(null, null, label);
    }

    public MenuItem(Class<? extends HttpServlet> servletClass, String label) {
        this(servletClass, null, label);
    }

    public MenuItem(Class<? extends HttpServlet> servletClass, String params, String label) {
        this.servletClass = servletClass;
        this.params = params;
        this.label = label;
    }

    /** Get HTTP link */
    public String getLink() {
        return WebTools.getUrlOfServlet(servletClass, params);
    }

    /** Get menu label */
    public String getLabel() {
        return label;
    }

    /** Is it a title only? */
    public boolean isTitle() {
        return servletClass == null;
    }
}
