import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Replace file of an EPUB archive
 *
 * @author Pavel Ponec
 */
public class JReplace4Subtitles {

    /** File: EPUB/toc.ncx */
    private final boolean isNcxFileAvailable = true;
    private final boolean debugMode = false;
    private final String nonBreakableSpace = "\u00A0";

    private final Charset charset = StandardCharsets.UTF_8;
    private final Pattern patternXhtml = Pattern.compile(".*\\.srt.txt");
    private final List<Replacement> repl = new ArrayList<>();

    public void run(String... args) {

        // Doctype
        addRepl("\\d{2}+:\\d{2}+:\\d{2}+,\\d{3}+.*,\\d{3}", "");
        addRepl("\\d{1,999}+", "");
        addRepl("\n", "❶");
        addRepl("\\s+", " ");
        addRepl("\\s*❶\\s*", "❶");
        addRepl("❶{3,}+", "❶❶");
        addRepl("❶❶", "\n\n");
        addRepl("❶", " ");


        // XHTML cleaning:
        try {
            replaceAllFiles(patternXhtml);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }

    }

    /** Replace all files according the pattern */
    private void replaceAllFiles(Pattern pattern) throws IOException {
        try (Stream<Path> paths = findFiles(pattern)) {
            paths.forEach(file -> {
                System.out.println("file: " + file);
                String content = readFile(file);
                for (Replacement replacement : getReplacements()) {
                    content = replacement.replace(content);
                }
                
                // Gilmore Girls fixing:
                content = content.replaceAll("^(.*)\r?\n(.*)", "$1\n$2");
                content = content.replaceAll(" - ", "\n- ");
                content = content.replaceAll("(#)(\\s*)(.+)(\\s*)(#)", "$3");
                content = content.replaceAll("^\\.", " .");
                saveFile(file, content);
            });
        }
    }

    private void addReplFileName(Pattern pattern) throws IOException {
        try (Stream<Path> paths = findFiles(pattern)) {
            paths.forEach(file -> {
                String name = file.getFileName().toString();
                addRepl(name, removeDiacritics(name));
                //System.out.println(">> MOVE " + name + " -> " + removeDiacritics(name));
            });
        }
    }
    
    private String removeDiacritics(String source) {
        return Normalizer.normalize(source, Normalizer.Form.NFD.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
    }


    /** Find files by pattern */
    private Stream<Path> findFiles(Pattern pattern) throws IOException {
        return Files.walk(Paths.get(""))
                .filter(Files::isRegularFile)
                .filter((f) -> pattern.matcher(f.toString()).matches());
    }

    protected void replace(Path file, Replacement repl) {
        String citation = readFile(file);
        saveFile(file, repl.replace(citation));
    }

    protected String readFile(Path file) {
        try {
            return new String(Files.readAllBytes(file), charset);
        } catch (IOException ex) {
            throw new IllegalStateException("Reading failed: " + file, ex);
        }
    }

    protected void saveFile(Path file, String content) {
        if (debugMode) {
            return;
        }
        try {
            final byte[] bytes = content.getBytes(charset);
            Files.write(file, bytes);
        } catch (IOException ex) {
            throw new IllegalStateException("Writing failed: " + file, ex);
        }
    }

    protected void addReplOrig(int pattern, int target) {
        addRepl(
                String.valueOf((char) pattern),
                String.valueOf((char) target));
    }

    protected void addRepl(int pattern, int target) {
        addRepl(
                String.valueOf((char) pattern),
                "");
    }

    /**
     * Add an replacement
     * @param pattern The empty value is ignored
     * @param target
     */
    protected void addRepl(String pattern, String target) {
        if (pattern == null || pattern.isEmpty()) {
            return;
        }
        //System.out.println("> " + pattern + " " + target);
        repl.add(new Replacement(Pattern.compile(pattern), target));
    }

    /** Return a replacement reqeuests */
    protected List<Replacement> getReplacements() {
        return repl;
    }

    protected class Replacement {

        /** "([^ ]*l[^ ,:]*)" */
        protected final Pattern pattern;
        /** "[$1]" */
        protected final String target;

        public Replacement(Pattern pattern, String target) {
            this.pattern = pattern;
            this.target = target;
        }

        /**
         *
         * @param textContent
         * @return
         */
        public String replace(String textContent) {
          return pattern
                .matcher(textContent)
                .replaceAll(target);
        }
    }

    public static final void main(String[] args) {
        new JReplace4Subtitles().run(args);
    }

}