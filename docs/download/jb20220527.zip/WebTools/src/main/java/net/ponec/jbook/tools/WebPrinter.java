/* Copyright 2018-2022 Pavel Ponec */
package net.ponec.jbook.tools;

import java.io.IOException;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.xml.ApiElement;
import java.lang.reflect.Array;
import java.util.Iterator;
import org.jetbrains.annotations.Nullable;

/**
 * A servlet value printer
 *
 * @author Pavel Ponec
 */
public class WebPrinter {

    protected static final String CSS_DATATYPE = "dataType";

    /** Blank space */
    protected static final String BLANK_SPACE = " ";

    /** Undefined class name */
    protected static final String UNDEFINED_TYPE = "?";

    /** Default CSS style */
    protected static final String DEFAULT_CSS = "numbers printer";

    /** Array separator */
    protected static final String ARRAY_SEPARATOR = ", ";

    /** A parent element */
    protected static final boolean LOG = "true"
            .equals(System.getenv("jbook_20191128"));

    /** A parent element */
    private final ApiElement<?> table;

    /** Total columns */
    private final int columnsCount = 4;

    /** Order number */
    private int order;

    /** Print a header into log */
    private boolean printHeader = true;

    protected WebPrinter(final ApiElement<?> table, final boolean ordered) {
        this.table = table;
        this.order = ordered ? 0 : -1;
    }

    /** Print the one row of table */
    public WebPrinter write(Object value, CharSequence label) {
        writeTableRow(Html.TD, label, value, getClassName(value));
        return this;
    }

    /** Print the one row of table */
    public WebPrinter write(Object value, CharSequence... labels) {
        return write(value, String.join("\n", labels));
    }

    /** Write an empty line */
    public void writeEmptyLine() {
        try (ApiElement<?> row = table.addElement(Html.TR)) {
            row.addElement(Html.TD)
                    .setAttribute(Html.A_COLSPAN, columnsCount + (isOrdered() ? 1 : 0))
                    .addText(BLANK_SPACE);
        }
    }

    // ---- Primitives

    /** Print the one row of table */
    public WebPrinter write(boolean value, CharSequence label) {
        writePrimitiveValue(label, value, Boolean.TYPE);
        return this;
    }

    /** Print the one row of table */
    public WebPrinter write(byte value, CharSequence label) {
        writePrimitiveValue(label, value, Byte.TYPE);
        return this;
    }

    /** Print the one row of table */
    public WebPrinter write(char value, CharSequence label) {
        writePrimitiveValue(label, value, Character.TYPE);
        return this;
    }

    /** Print the one row of table */
    public WebPrinter write(short value, CharSequence label) {
        writePrimitiveValue(label, value, Short.TYPE);
        return this;
    }

    /** Print the one row of table */
    public WebPrinter write(int value, CharSequence label) {
        writePrimitiveValue(label, value, Integer.TYPE);
        return this;
    }

    /** Print the one row of table */
    public WebPrinter write(long value, CharSequence label) {
        writePrimitiveValue(label, value, Long.TYPE);
        return this;
    }

    /** Print the one row of table */
    public WebPrinter write(float value, CharSequence label) {
        writePrimitiveValue(label, value, Float.TYPE);
        return this;
    }

    /** Print the one row of table */
    public WebPrinter write(double value, CharSequence label) {
        writePrimitiveValue(label, value, Double.TYPE);
        return this;
    }

    // --- UTILS

    /** Return a next order */
    protected String nextOrder() {
        final int result = order++;
        return result > 0 ? result + "." : "#";
    }

    /** Print the one row of a table */
    protected final void writePrimitiveValue(CharSequence label, Object value, Class<?> clazz) {
        writeTableRow(Html.TD, label, value, clazz.getName());
    }

    /** Print the one row of a table */
    protected final void writeTableRow(String htmlElement, CharSequence label, Object value, String clazz) {
        try (ApiElement<?> row = table.addElement(Html.TR)) {
            if (isOrdered()) {
                writeCell(row.addElement(htmlElement), nextOrder());
            }
            writeCell(row.addElement(htmlElement), toString(label));
            writeCell(row.addElement(htmlElement), toString(value, null));
            writeCell(row.addElement(htmlElement).setAttribute(Html.A_CLASS, CSS_DATATYPE), clazz);
        } catch (IOException e) {
            throw new IllegalArgumentException(e);
        }
        if (LOG) {
            logRowCsv(toString(label), toString(value, null), clazz);
        }
    }

    /** Log the row in CSV format */
    protected void logRowCsv(String label, String value, String clazz) {
        final boolean removePackage = true;
        if (removePackage) {
            int i, max = clazz.length();
            for (i = 0; i < max && !Character.isUpperCase(clazz.charAt(i)); i++) {
            }
            if (i < max) {
                clazz = clazz.substring(i, max);
            }
        }
        if (printHeader) {
            printHeader = false;
            System.out.println(String.join("\n",
                    ".Title",
                    "[cols=\">1h,6m,>3,4,10\",format=\"csv\",separator=\"│\",options=\"header\"]",
                    "|========",
                    " # │Code│Result│Type│Note"));
        }
        String msg = "WebWriterLog│%2d.│\"%s\"│%s│%s│\"...\"".formatted(
                order - 1,
                label.replace("\"", "\"\"").replace(".trim().", ".trim() ."),
                value,
                clazz);
        System.out.println(msg);
    }

    @Nullable
    protected static String toString(@Nullable Object value) {
        return toString(value, BLANK_SPACE);
    }

    @Nullable
    protected static String toString(@Nullable Object value, @Nullable String defaultValue) {
        if (value == null) {
            return defaultValue;
        } else if (value.getClass().isArray()) {
            StringBuilder result = new StringBuilder();
            for (int i = 0, max = Array.getLength(value); i < max; i++) {
                if (i > 0) {
                    result.append(ARRAY_SEPARATOR);
                }
                result.append(Array.get(value, i));
            }
            return result.toString();
        } else if (value instanceof Iterable) {
            StringBuilder result = new StringBuilder();
            Iterator<?> it = ((Iterable<?>) value).iterator();
            for (int i = 0; it.hasNext(); i++) {
                if (i > 0) {
                    result.append(ARRAY_SEPARATOR);
                }
                result.append(it.next());
            }
            return result.toString();
        } else {
            return value.toString();
        }
    }

    /** Write cell */
    protected void writeCell(final ApiElement cell, final Object value) throws IOException {
        String[] valueItems = String.valueOf(value).split("\n");
        for (int i = 0; i < valueItems.length; i++) {
            if (i > 0) {
                cell.addElement(Html.BR);
            }
            cell.addText(valueItems[i]);
        }
    }

    private boolean isOrdered() {
        return order >= 0;
    }

    /** New ordered instance with columns: Expression, Value */
    public static WebPrinter of(ApiElement<?> parent) {
        return printerFactory(parent, DEFAULT_CSS, true, "Expression / Statement", "Result", "Type");
    }

    /** No ordered instance with custom columns */
    public static WebPrinter ofPlain(ApiElement<?> parent, Object... headers) {
        return printerFactory(parent, DEFAULT_CSS, false, headers);
    }

    /** Common factory */
    public static WebPrinter printerFactory(ApiElement<?> parent, String css, boolean ordered, Object... headers)
            throws IllegalStateException {
        ApiElement<?> table = parent.addElement(Html.TABLE).setAttribute(Html.A_CLASS, css);
        WebPrinter result = new WebPrinter(table, ordered);
        int colums = 3;
        String[] title = new String[colums];
        for (int i = 0; i < colums; i++) {
            title[i] = toString(headers.length > 0 ? headers[i] : null, BLANK_SPACE);
        }
        result.writeTableRow(Html.TH, title[0], title[1], title[2]);
        return result;
    }

    private String getClassName(@Nullable Object value) {
        if (value == null) {
            return UNDEFINED_TYPE;
        }
        final Class<?> clazz = value.getClass();
        if (clazz.isArray()) {
            return clazz.getComponentType().getName() + "[]";

        } else {
            return clazz.getName();
        }
    }

    /** Returns a content of table element */
    @Override
    public String toString() {
        return table.toString();
    }
}
