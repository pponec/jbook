/* Copyright 2018-2021 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s70_gomoku;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;
import java.util.Optional;
import net.ponec.jbook.tools.Base64Converter;

/** The game board */
public class BoardModel {

    /** A width of the board */
    private final short width;
    /** A heigt of the board */
    private final short height;
    /** Internal fields */
    private final BitSet fields;
    /** An initial value */
    private final BoardPoint clientMove = new BoardPoint((short) 0, Short.MAX_VALUE);
    /** An initial value */
    private final BoardPoint lastMove = clientMove.clonePoint();
    /** An penultimate value */
    private final BoardPoint penultimateMove = lastMove;
    /** An instance of a Base64 converter */
    private final Base64Converter converter;
    /** New board */
    private final boolean newBoard;
    /** Optional error message */
    private String errorMessage;
    /** A game over status */
    private boolean gameOver;

    /** A constructor with defult converter
     * @param width A width of the board
     * @param height a heigh of th board
     * @param content An optional content taken from the method {@link #exportBoard() }
     */
    public BoardModel(int width, int height, String content) {
        this(width, height, content, new Base64Converter());
    }

    /** A constructor with an extended converter.
     * @param width A width of the board for the short type
     * @param height a heigh of th board for the short type
     * @param content A optional content from the method {@link #exportBoard() }
     */
    public BoardModel(int width, int height, String content, Base64Converter converter) {
        this.width = (short) width;
        this.height = (short) height;
        this.converter = converter;
        this.newBoard = content == null || content.isEmpty();
        this.fields = newBoard
                    ? new BitSet(width * height * 2)
                    : BitSet.valueOf(converter.deconvert(content));
    }

    /** Create new model from the original */
    private BoardModel(BoardModel original) {
        this.width = original.width;
        this.height = original.height;
        this.converter = original.converter;
        this.fields = (BitSet) original.fields.clone();
        this.lastMove.set(original.lastMove);
        this.penultimateMove.set(original.penultimateMove);
        this.errorMessage = original.errorMessage;
        this.gameOver = original.gameOver;
        this.newBoard = original.newBoard;
    }


    /** Set a new stone of the user to a free board point */
    public void setClientStone(BoardPoint point, StoneEnum stone) {
        clientMove.set(point);
        setStone(point, stone);
    }

    /** Set a new stone to the free board point */
    public void setStone(BoardPoint point, StoneEnum stone) {
        if (!hasStone(point, StoneEnum.NO_STONE)) {
            throw new IllegalStateException("This point is already occupied " + point);
        }
        switch (stone) {
            case BLACK_STONE:
            case WHITE_STONE:
                fields.set(convertToBitSetIndex(point, stone));
                penultimateMove.set(lastMove.getX(), lastMove.getY());
                lastMove.set(point);
                break;
            default:
                throw new IllegalArgumentException("Illegal stone" + stone);
        }
    }

    /** Get a field state */
    public StoneEnum getStone(BoardPoint point) {
        StoneEnum[] stones = {StoneEnum.WHITE_STONE, StoneEnum.BLACK_STONE};
        for (StoneEnum stone : stones) {
            if (checkStoneInternal(point, stone)) {
                return stone;
            }
        }
        return StoneEnum.NO_STONE;
    }

    /** Get an opponent stone */
    public StoneEnum getOpponentStone(StoneEnum stone) {
        switch (stone) {
            case BLACK_STONE:
                return StoneEnum.WHITE_STONE;
            case WHITE_STONE:
                return StoneEnum.BLACK_STONE;
            default:
                return stone;
        }
    }

    /** Convert a board point to the BitSet index. The NO_STONE throws an IllegalArgumentException. */
    private int convertToBitSetIndex(BoardPoint point, final StoneEnum stone) throws IllegalArgumentException {
        switch (stone) {
            case BLACK_STONE:
            case WHITE_STONE:
                return point.getPointIndex(this) * 2 + stone.ordinal();
            default:
                throw new IllegalArgumentException("Illegal stone: " + stone);
        }
    }

    /** Check it the point is inside the board */
    protected boolean isInsideBoard(BoardPoint point) {
        return point.getX() >= 0
            && point.getX() < width
            && point.getY() >= 0
            && point.getY() < height;
    }

    /** Check a required stone inside the boreder */
    public boolean hasStone(BoardPoint point, StoneEnum stone) {
        return isInsideBoard(point) && getStone(point) == stone;
    }

    /** Check the BALACK or WHITE stone on required point of board.
     * The NO_STONE throws an IllegalArgumentException. */
    private boolean checkStoneInternal(BoardPoint point, StoneEnum stone) throws IllegalArgumentException {
        return fields.get(convertToBitSetIndex(point, stone));
    }

    /** A board width */
    public short getWidth() {
        return width;
    }

    /** A board height */
    public short getHeight() {
        return height;
    }

    /** Get the last move point */
    public BoardPoint getLastMove() {
        return lastMove;
    }

    /** Return the changed points only, but for the new board return everything. */
    public List<BoardPoint> getChangedPoints(int... additionalPoints) {
        final List<BoardPoint> result = new ArrayList<>();
        if (newBoard) {
            final BoardPoint point = new BoardPoint();
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    result.add(point.set(x, y).clonePoint());
                }
            }
        } else {
            result.add(clientMove);
            result.add(lastMove);
            for (int point : additionalPoints) {
                result.add(new BoardPoint().setPointIndex(point, width));
            }
        }
        return result;
    }

    /** Set a flag: the game is over */
    public void setGameOver() {
        gameOver = true;
    }

    /** Is the game is over? */
    public boolean isGameOver() {
        return gameOver;
    }

    /** Returns a winner name */
    public Optional<String> getWinnerName(String computer, String human) {
        return gameOver
             ? Optional.of(getStone(lastMove) == StoneEnum.WHITE_STONE ? computer : human)
             : Optional.empty();
    }

    /** Set a error message */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    /** Get an error message */
    public Optional<String> getErrorMessage() {
        return Optional.ofNullable(errorMessage);
    }

    /** Clone the board model */
    public BoardModel cloneBoard() {
        return new BoardModel(this);
    }

    /** Return a board content in a String format or {@code null} if the game is over. */
    public String exportBoard() {
        return gameOver ? null : converter.convert(fields.toByteArray());
    }

}
