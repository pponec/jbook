/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

/** Car data model */
public class Car extends MotorVehicle {
    
    /** Luggage compartment volume in liters. */
    private int trunkVolume;

    /**
     * Luggage compartment volume in liters.
     * @return the trunkVolume
     */
    public int getTrunkVolume() {
        return trunkVolume;
    }

    /**
     * Luggage compartment volume in liters.
     * @param trunkVolume the trunkVolume to set
     */
    public void setTrunkVolume(int trunkVolume) {
        this.trunkVolume = trunkVolume;
    }

}
