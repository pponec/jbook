/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

/** Car data model */
public class Bike extends RoadVehicle {
    
    /** Bicycle frame size in inches. */
    private String frameSize;

    /**
     * Bicycle frame size in inches.
     * @return the frameSize
     */
    public String getFrameSize() {
        return frameSize;
    }

    /**
     * Bicycle frame size in inches.
     * @param frameSize the frameSize to set
     */
    public void setFrameSize(String frameSize) {
        this.frameSize = frameSize;
    }
    
}
