/* Copyright 2018-2022 Pavel Ponec, https;//jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

/**
 * A data model of a road vehicle that operates on rails and has an engine or a motor
 */
public abstract class MotorVehicle extends RoadVehicle {

    /** License Plate of the Vehicle */
    private String licensePlate;
    /** Type of an engine (a catalog data) */
    private EngineType engine;
    /** Serial number or the engine */
    private int motorSerialNumber;

    /**
     * License Plate of the Vehicle
     * @return the licensePlate
     */
    public String getLicensePlate() {
        return licensePlate;
    }

    /**
     * License Plate of the Vehicle
     * @param licensePlate the licensePlate to set
     */
    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    /**
     * Type of an engine
     * @return the engineType
     */
    public EngineType getEngine() {
        return engine;
    }

    /**
     * Type of an engine
     * @param engine the engineType to set
     */
    public void setEnergy(EngineType engine) {
        this.engine = engine;
    }

    /**
     * Serial number or the engine
     * @return the motorSerialNumber
     */
    public int getMotorSerialNumber() {
        return motorSerialNumber;
    }

    /**
     * Serial number or the engine
     * @param motorSerialNumber the motorSerialNumber to set
     */
    public void setMotorSerialNumber(int motorSerialNumber) {
        this.motorSerialNumber = motorSerialNumber;
    }

}
