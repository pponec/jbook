/* Copyright 2018-2022 Pavel Ponec */
package net.ponec.jbook.plainSamples;

import net.ponec.jbook.s06_vehicle.domain.Car;

/**
 * Cars
 *
 * @author Pavel Ponec
 */
public class CarService3 {

    public Car createCar(int trunkVolume) {
        Car car = new Car();
        try {
            car.setTrunkVolume(trunkVolume);
            // ... assign other attributes
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
        return car;
    }

}
