/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.tools;

import java.util.HashSet;
import java.util.Set;
import net.ponec.jbook.s70_gomoku.GoMokuServlet;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Pavel Ponec
 */
public class SampleMapImplTest {
    
    /** Class checking */
    protected static final net.ponec.jbook.tools.SourceMapImpl SOURCES = null;

    @Test
    public void remoteInstance() throws ReflectiveOperationException {
        final SourceMap instance = SourceMap.createInstance(true);
        assertNotNull(instance);
        assertTrue(instance.getClasses(GoMokuServlet.class).size() > 3);
    }

    /** Testing a unique of items. */
    @Test
    public void uniqueItems() {
        final SourceMapImpl instance = new SourceMapImpl();
        final Set<Class> items = new HashSet<>();

        for (Class servletClass : instance.classMap.keySet()) {
            addItem(servletClass, items, true);
            for (Class item : instance.classMap.get(servletClass)) {
                addItem(item, items, false);
            }
        }
        assertTrue(items.size() > 10);
    }

    /** Add new item and check the unique value */
    private void addItem(Class item, Set<Class> set, boolean mainClass) {
        boolean unique = set.add(item);
        if (!GoMokuServlet.class.isAssignableFrom(item)) {
            assertTrue(unique, "The item is not unique: " + item);
        }
    }

}
