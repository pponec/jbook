/* Copyright 2018-2022 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s70_gomoku;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.ujorm.tools.msg.MsgFormatter;

/**
 *
 * @author Pavel Ponec
 */
public class BoardPointTest {

     /**
     * Test of set method, of class BoardPoint.
     */
    @Test
    public void testSetXy() {
        System.out.println("set");
        int x = 1;
        int y = 2;
        BoardPoint instance = new BoardPoint();
        BoardPoint result = instance.set(x, y);

        Assertions.assertEquals(x, result.getX());
        Assertions.assertEquals(y, result.getY());

    }

    /**
     * Test of set method, of class BoardPoint.
     */
    @Test
    public void testSet_BoardPoint() {
        System.out.println("set");
        short x = 1;
        short y = 2;
        BoardPoint point = new BoardPoint(x, y);
        BoardPoint instance = new BoardPoint();
        BoardPoint result = instance.set(point);

        Assertions.assertEquals(x, result.getX());
        Assertions.assertEquals(y, result.getY());
    }

    /**
     * Test of getPointIndex() method of class BoardPoint.
     */
    @Test
    public void testPointIndex() {
        short x = 1;
        short y = 2;
        BoardPoint point = new BoardPoint(x, y);
        BoardModel board = new BoardModel(3, 3, null);
        int index = point.getPointIndex(board);
        Assertions.assertEquals(7, index);
    }

    /**
     * Test of set method, of class BoardPoint.
     */
    @Test
    public void testSetShift() {
        System.out.println("set");
        short x = 1;
        short y = 2;
        short shiftX = 4;
        short shiftY = 5;
        BoardPoint instance = new BoardPoint(x, y);
        BoardPoint expResult = new BoardPoint(x + shiftX, y + shiftY);
        BoardPoint result = instance.set(instance, shiftX, shiftY);

        Assertions.assertTrue(expResult.equals(result));
        Assertions.assertEquals(expResult, result);
    }

    /**
     * Test of getPointIndex method, of class BoardPoint.
     */
    @Test
    public void testGetPointIndex() {
        System.out.println("getPointIndex");
        short x = 1;
        short y = 2;
        BoardModel board = new BoardModel(3, 3, null);
        BoardPoint instance = new BoardPoint(x, y);
        int expResult = board.getWidth() * y + x;
        int result = instance.getPointIndex(board);
        Assertions.assertEquals(expResult, result);
    }

    /**
     * Test of setPointIndex method, of class BoardPoint.
     */
    @Test
    public void testSetPointIndex() {
        System.out.println("setPointIndex");
        short x = 1;
        short y = 2;
        short boardWidth = 3 ;
        int i = boardWidth * y + x;
        BoardPoint instance = new BoardPoint().setPointIndex(i, boardWidth);
        BoardPoint expResult = new BoardPoint(x, y);

        Assertions.assertEquals(expResult, instance);
    }

    /**
     * Test of getDistance method, of class BoardPoint.
     */
    @Test
    public void testGetDistance() {
        System.out.println("getDistance");
        BoardPoint param =  new BoardPoint(0,0);
        BoardPoint instance = new BoardPoint(2,2);
        int expResult = 2;
        int result = instance.getDistance(param);
        Assertions.assertEquals(expResult, result);
    }

    /**
     * Test of clonePoint method, of class BoardPoint.
     */
    @Test
    public void testClonePoint() {
        System.out.println("clonePoint");
        short x = 1;
        short y = 2;
        BoardPoint instance = new BoardPoint(x, y);
        BoardPoint expResult = new BoardPoint(x, y);
        BoardPoint result = instance.clonePoint();

        Assertions.assertTrue(expResult.equals(result));
        Assertions.assertEquals(expResult, result);

        instance.set(instance, 1, 1);
        Assertions.assertEquals(expResult, result);
    }

    /**
     * Test of equals method, of class BoardPoint.
     */
    @Test
    public void testEquals() {
        System.out.println("equals");
        short x = 1;
        short y = 2;
        BoardPoint instance = new BoardPoint(x, y);
        BoardPoint expResult = new BoardPoint(x, y);

        Assertions.assertTrue(expResult.equals(instance));
        Assertions.assertEquals(expResult, instance);

        instance = expResult.clonePoint();
        Assertions.assertEquals(expResult, instance);
    }

    /**
     * Test of toString method, of class BoardPoint.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        short x = 1;
        short y = 2;
        BoardPoint instance = new BoardPoint(x, y);
        String expResult = MsgFormatter.format("[{},{}]", x, y);
        String result = instance.toString();
        Assertions.assertEquals(expResult, result);
    }

}
