package net.ponec.jbook.plainSamples;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Atomic counter for a positive values with a validation and logging
 */
public class CounterExtendedImpl implements Counter {

    private final AtomicInteger count = new AtomicInteger();

    @Override
    public void add(int value) {
        if (value <= 0) {
            throw new IllegalArgumentException("Argument must be positive: " + value);
        }
        count.addAndGet(value);

        // Log the event:
        Logger.getGlobal().log(Level.INFO, "The current count: " + count);
    }

    @Override
    public int getCount() {
        return count.get();
    }

}
