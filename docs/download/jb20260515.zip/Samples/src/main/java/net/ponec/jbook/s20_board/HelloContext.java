/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s20_board;

import jakarta.servlet.annotation.WebServlet;
import net.ponec.jbook.tools.MyHttpServlet;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.web.request.HttpContext;

/** An extended servlet implementation based on the HttpContext class */
@WebServlet("/hello-context")
public class HelloContext extends MyHttpServlet {

    @Override
    protected void doGet(HttpContext ctx) {
        try (HtmlElement html = HtmlElement.niceOf(ctx, "css/world.css")) {
            html.getBody().addHeading("Hello, World! (Context)");
            WebTools.addFooter(html, this);
        }
    }
}
