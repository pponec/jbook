/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s50_gomoku;

import org.ujorm.tools.web.request.HttpContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/** A board game services */
public class BoardService {

    /** Logger */
    private static final Logger LOGGER = Logger.getLogger(BoardService.class.getName());
    /** Hidden data input */
    public static final String BOARD_PARAM = "board";
    /** Button parameter name */
    public static final String BUTTON_PARAM = "b";

    /** The game strategy name */
    public String getTitle() {
        return "Go-moku (plain strategy)";
    }

    /** Create a board model from input parameters */
    public BoardModel createBoardModel(HttpContext request) {
        BoardModel result;
        final int width = 23;
        final int height = 13;

        try {
            result = new BoardModel(width, height, request.getParameter(BoardService.BOARD_PARAM));
            int buttonValue = request.getParameter(BUTTON_PARAM, -1, Integer::parseInt);
            if (buttonValue >= 0) {
                BoardPoint lastMove = new BoardPoint().setPointIndex(buttonValue, width);
                result.setClientStone(lastMove, StoneEnum.BLACK_STONE);
                closeGameOnVictory(result);
                if (!result.isGameOver()) {
                    machineMoves(result);
                    closeGameOnVictory(result);
                }
            }
        } catch (RuntimeException e) {
            String msg = "An internal error (%s)".formatted(e.getClass().getSimpleName());
            result = new BoardModel(width, height, null);
            result.setErrorMessage(msg);
            LOGGER.log(Level.WARNING, msg, e);
        }
        return result;
    }

    /** Close the game in case of victory */
    public void closeGameOnVictory(BoardModel board) {
        if (isWinner(board, GoMokuServlet.WINNING_STONE_COUNT)) {
            board.setGameOver();
        }
    }

    /** Check it the point is out of border */
    protected boolean isWinner(BoardModel board, int requiredStoneCount) {
        for (DirectionEnum direction : DirectionEnum.values()) {
            if (getDirectionBorder(board, direction, requiredStoneCount) != null) {
                return true;
            }
        }
        return false;
    }

    /** Returns two border points out of line for a required stones, or the null */
    protected BoardPoint[] getDirectionBorder(BoardModel board, DirectionEnum direction, int requiredStoneCount) {
        final BoardPoint firstPoint = board.getLastMove().clonePoint();
        final BoardPoint lastPoint = firstPoint.clonePoint();
        final StoneEnum myStone = board.getStone(board.getLastMove());

        while (board.hasStone(firstPoint, myStone)) {
            direction.move(firstPoint, true);
        }
        while (board.hasStone(lastPoint, myStone)) {
            direction.move(lastPoint, false);
        }
        if (firstPoint.getDistance(lastPoint) >= (requiredStoneCount + 1)) {
            return new BoardPoint[]{firstPoint, lastPoint};
        }
        return null;
    }

    /** The machine is on the move */
    public void machineMoves(BoardModel board) {
        final StoneEnum playerStone = board.getStone(board.getLastMove());
        final StoneEnum machineStone = board.getOpponentStone(playerStone);
        getNextPoint(board).ifPresent(point -> board.setStone(point, machineStone));
    }

    /** Get the next point */
    protected Optional<BoardPoint> getNextPoint(final BoardModel board) {
        final BoardPoint lastMove = board.getLastMove();
        for (int count = GoMokuServlet.WINNING_STONE_COUNT - 1; count >= 2; count--) {
            for (DirectionEnum direction : DirectionEnum.values()) {
                final BoardPoint[] points = getDirectionBorder(board, direction, count);
                if (points != null) {
                    for (BoardPoint borderPoint : points) {
                        if (board.hasStone(borderPoint, StoneEnum.NO_STONE)) {
                            return Optional.of(borderPoint);
                        }
                    }
                }
            }
        }
        final List<BoardPoint> points = getFreePoints(board, lastMove);
        return points.isEmpty()
             ? Optional.empty()
             : Optional.of(points.get(new Random().nextInt(points.size())));
    }

    /** Get all free points around lastMove */
    public List<BoardPoint> getFreePoints(final BoardModel board, final BoardPoint lastMove) {
        final ArrayList<BoardPoint> result = new ArrayList<>();
        final boolean[] orientations = {true, false};

        for (DirectionEnum direction : DirectionEnum.values()) {
            for (boolean forward : orientations) {
                final BoardPoint borderPoint = direction.move(lastMove.clonePoint(), forward);
                if (board.hasStone(borderPoint, StoneEnum.NO_STONE)) {
                    result.add(borderPoint);
                }
            }
        }
        return result;
    }

    /** Returns a winning message. */
    public Optional<String> getWinnerMessage(BoardModel board) {
        return getWinnerMessage("The game is over, %s won!", "computer", "human", board);
    }

    /** Build a winning message. */
    public Optional<String> getWinnerMessage(String msgTemplate, String computer, String human, BoardModel board) {
        return board.getWinnerName(computer, human).map(who -> msgTemplate.formatted(who));
    }

}
