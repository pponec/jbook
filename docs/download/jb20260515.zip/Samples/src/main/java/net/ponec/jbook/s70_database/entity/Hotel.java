package net.ponec.jbook.s70_database.entity;

import java.math.BigDecimal;

public class Hotel {

    private long id = -1;
    private String name;
    private City city;
    private String street;
    private String phone;
    private BigDecimal price;
    private String currency;
    private short stars;
    private boolean isActive;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public short getStars() {
        return stars;
    }

    public void setStars(short stars) {
        this.stars = stars;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    @Override
    public String toString() {
        return "Hotel{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", city=" + city +
                ", street='" + street + '\'' +
                ", phone='" + phone + '\'' +
                ", price=" + price +
                ", currency='" + currency + '\'' +
                ", stars=" + stars +
                ", isActive=" + isActive +
                '}';
    }

    /** Create a new hotel object including the city. */
    public static Hotel of(City city) {
        final Hotel result = new Hotel();
        result.setCity(city);
        return result;
    }
}
