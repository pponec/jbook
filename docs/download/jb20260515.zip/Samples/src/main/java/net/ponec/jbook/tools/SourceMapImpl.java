/* Copyright 2018-2026 Pavel Ponec */
package net.ponec.jbook.tools;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import jakarta.servlet.http.HttpServlet;
import net.ponec.jbook.s10_form.FieldDescriptor;
import net.ponec.jbook.s10_form.UserFormServlet;
import net.ponec.jbook.s06_vehicle.RegistrationService;
import net.ponec.jbook.s06_vehicle.VehicleServlet;
import net.ponec.jbook.s06_vehicle.domain.Car;
import net.ponec.jbook.s06_vehicle.domain.EngineType;
import net.ponec.jbook.s06_vehicle.domain.MotorVehicle;
import net.ponec.jbook.s06_vehicle.domain.RoadVehicle;
import net.ponec.jbook.s06_vehicle.domain.User;
import net.ponec.jbook.s06_vehicle.domain.VehicleModel;
import net.ponec.jbook.s20_board.BoardServlet;
import net.ponec.jbook.s20_board.SimpleBoardModel;
import net.ponec.jbook.s25_charset.ExtendedBoardModel;
import net.ponec.jbook.s25_charset.StringBuilderServlet;
import net.ponec.jbook.s50_gomoku.BoardModel;
import net.ponec.jbook.s50_gomoku.BoardPoint;
import net.ponec.jbook.s50_gomoku.BoardService;
import net.ponec.jbook.s50_gomoku.DirectionEnum;
import net.ponec.jbook.s50_gomoku.ExtendedBoardService;
import net.ponec.jbook.s50_gomoku.GoMokuServlet;
import net.ponec.jbook.s50_gomoku.StoneEnum;
import net.ponec.jbook.s60_ajax.FineBoardService;
import net.ponec.jbook.s60_ajax.GoMokuAjaxServlet;
import net.ponec.jbook.s70_database.AbstractDatabaseServlet;
import net.ponec.jbook.s70_database.HotelTableServlet;
import net.ponec.jbook.s70_database.dao.AbstractDao;
import net.ponec.jbook.s70_database.dao.CityDao;
import net.ponec.jbook.s70_database.dao.HotelDao;
import net.ponec.jbook.s70_database.entity.City;
import net.ponec.jbook.s70_database.entity.Hotel;
import net.ponec.jbook.s70_database.service.DatabaseProvider;
import net.ponec.jbook.s70_database.service.HotelService;
import net.ponec.jbook.s70_database.service.HotelServiceCsv;
import net.ponec.jbook.s99_menu.MenuItem;
import net.ponec.jbook.s99_menu.MenuServlet;

/** Mapping the samples */
public class SourceMapImpl implements SourceMap, Serializable {

    /** Servlet mapping */
    final Map<Class,Class[]> classMap = new HashMap<>();

    /** Map servlet to dependences */
    SourceMapImpl() {
        mapRelations(VehicleServlet.class, Car.class, MotorVehicle.class, RoadVehicle.class, EngineType.class, VehicleModel.class, User.class, RegistrationService.class);
        mapRelations(BoardServlet.class, SimpleBoardModel.class);
        mapRelations(UserFormServlet.class, FieldDescriptor.class);
        mapRelations(BoardServlet.class, SimpleBoardModel.class);
        mapRelations(StringBuilderServlet.class, ExtendedBoardModel.class);
        mapRelations(GoMokuServlet.class, BoardModel.class, StoneEnum.class, BoardPoint.class, DirectionEnum.class, BoardService.class, ExtendedBoardService.class);
        mapRelations(GoMokuAjaxServlet.class, GoMokuServlet.class, FineBoardService.class);
        mapRelations(HotelTableServlet.class, Hotel.class, City.class, HotelDao.class, CityDao.class, HotelService.class, HotelServiceCsv.class, DatabaseProvider.class, AbstractDao.class, AbstractDatabaseServlet.class);
        mapRelations(MenuServlet.class, MenuItem.class);
    }

    /** Map related classes to the main servlet class */
    void mapRelations(Class mainClass, Class... relatedClasses) {
        classMap.put(mainClass, relatedClasses);
    }

    /** Get servlet dependencies */
    private Optional<Class[]> getDependences(final Class<? extends HttpServlet> servletClass) {
        return Optional.ofNullable(classMap.get(servletClass));
    }

    /** Return an array of related classes */
    @Override
    public List<Class> getClasses(final Class<? extends HttpServlet> servletClass) {
        final ArrayList<Class> result = new ArrayList<>(8);
        result.add(servletClass);
        getDependences(servletClass).ifPresent(items -> result.addAll(Arrays.asList(items)));
        return result;
    }
}
