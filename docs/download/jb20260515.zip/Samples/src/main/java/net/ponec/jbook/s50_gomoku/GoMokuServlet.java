/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s50_gomoku;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import net.ponec.jbook.tools.MyHttpServlet;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.web.request.HttpContext;

/** Simple board game */
@WebServlet("/go-moku")
public class GoMokuServlet extends MyHttpServlet {

    /** Logger */
    private static final Logger LOGGER = Logger.getLogger(GoMokuServlet.class.getName());

    /** The number of winning stones */
    public static final int WINNING_STONE_COUNT = 5;

    /** Cascading style sheets */
    private static final String[] CSS = new String[] {"css/board.css", "css/gomoku.css"};

    /** Message bar identifier */
    protected static final String MESSAGE_ID = "messageBox";

    /** Board model identifier */
    protected static final String BOARD_MODEL_ID = "boardModel";

    /** A board service */
    protected final BoardService service;

    protected GoMokuServlet(BoardService service) {
        this.service = service;
    }

    public GoMokuServlet() {
        this(new ExtendedBoardService());
    }


    /**
     * Handles the HTTP <code>GET</code> or <code>POST</code> method.
     * @param ctx A servlet request encoded by UTF_8 with the servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpContext ctx) {
        try (HtmlElement html = HtmlElement.niceOf(service.getTitle(), ctx, css())) {
            writeHeaderElements(html);
            html.getBody().addHeading(html.getTitle());
            try {
                BoardModel board = service.createBoardModel(ctx);
                Element form = html.getBody().addForm().setMethod(Html.V_GET);
                createFormBody(form, board);
            } catch (RuntimeException e) {
                String msg = "Internal server error caused by " + e.getClass().getSimpleName();
                LOGGER.log(Level.SEVERE, msg, e);
                html.getBody().addSpan("msg").addText(msg + ", see a server log for detail");
            }
            WebTools.addFooter(html, this);
        }
    }

    /** Create a body of the form */
    protected void createFormBody(Element form, BoardModel board) {
        createMessagePanel(form.addDiv().setId(MESSAGE_ID), board);
        createBoardBody(form.addTable("board"), board);
        createResetButton(form, "New game");
        createBoardModel(form.addSpan().setId(BOARD_MODEL_ID), board);
    }

    /** Save model data */
    protected void createBoardModel(Element form, BoardModel board) {
        form.addInput()
                .setType(Html.V_HIDDEN)
                .setName(BoardService.BOARD_PARAM)
                .setValue(board.exportBoard());
    }

    /** Build messages, if any */
    protected void createMessagePanel(Element panel, BoardModel board) {
        board.getErrorMessage().ifPresent(msg -> panel.addSpan("msg").addText(msg));
        service.getWinnerMessage(board).ifPresent(msg -> panel.addSpan("msg").addText(msg));
        panel.addText("");
    }

    /** Create a clear button element */
    protected void createResetButton(Element parent, String title) {
        parent.addAnchor(WebTools.getUrlOfServlet(getClass()), "btn", "btn-primary").addText(title);
    }

    /** Create a body of main board */
    protected void createBoardBody(final Element table, BoardModel board) {
        final BoardPoint boardPoint = new BoardPoint();
        for (int y = 0; y < board.getHeight(); y++) {
            final Element rowElement = table.addTableRow();
            createTableRow(rowElement, board, boardPoint, y);
        }
    }

    /** Create a body of table row */
    protected void createTableRow(Element row, BoardModel board, BoardPoint boardPoint, int y) {
        for (int x = 0; x < board.getWidth(); x++) {
            final Element td = row.addTableDetail();
            boardPoint.set(x, y);
            createStone(td, boardPoint, board);
        }
    }

    /** Create a body of the stone*/
    protected void createStone(final Element td, final BoardPoint boardPoint, final BoardModel board) {
        final StoneEnum stone = board.getStone(boardPoint);
        switch(stone) {
            case NO_STONE:
                td.addSubmitButton()
                    .setName(BoardService.BUTTON_PARAM)
                    .setValue(boardPoint.getPointIndex(board))
                    .addText("");
                break;
            default:
                td.addSpan(
                        stone == StoneEnum.WHITE_STONE ? "w" : "b",
                        boardPoint.equals(board.getLastMove()) ? "last" : null)
                  .addText("");
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param ctx servlet request & servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpContext ctx) throws IOException {
        doGet(ctx);
    }

    /** An empty method is ready for overloading. */
    protected void writeHeaderElements(HtmlElement html) {
    }

    /** Get CSS styles */
    protected String[] css() {
        return CSS;
    }
}
