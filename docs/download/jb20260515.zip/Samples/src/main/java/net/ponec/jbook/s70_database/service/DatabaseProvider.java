package net.ponec.jbook.s70_database.service;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import net.ponec.jbook.s70_database.dao.CityDao;
import net.ponec.jbook.s70_database.dao.HotelDao;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Logger;

/**
 * Manages the database lifecycle and provides connections to the application.
 * This class acts as both a {@link ServletContextListener} for lifecycle management
 * and a provider for the {@link HikariDataSource}.
 */
@WebListener
public class DatabaseProvider implements ServletContextListener {
    private static final Logger LOGGER = Logger.getLogger(DatabaseProvider.class.getName());
    private static final String DEFAULT_PASSWORD = "secretPassword" + System.currentTimeMillis();

    /** Data Source Pool. */
    private static HikariDataSource pool;

    /**
     * Initializes the connection pool when the web application starts.
     * @param event the ServletContextEvent
     */
    @Override
    public void contextInitialized(ServletContextEvent event) {
        if (pool == null || pool.isClosed()) {
            pool = new HikariDataSource(createConfig());
            initDatabaseTables();
            LOGGER.info("Database initialized by " + getClass().getSimpleName());
        }
    }

    /**
     * Closes the connection pool when the web application shuts down.
     * @param event the ServletContextEvent
     */
    @Override
    public void contextDestroyed(ServletContextEvent event) {
        if (pool != null && !pool.isClosed()) {
            pool.close();
            pool = null;
            LOGGER.info("Database destroyed by " + getClass().getSimpleName());
        }
    }

    /**
     * Get database connection from the pool with auto-commit set to false.
     * <p>The caller is responsible for closing the connection.</p>
     * @return A database connection with auto-commit disabled.
     */
    public static Connection getConnection() {
        if (pool == null) {
            throw new IllegalStateException("DatabaseProvider is not initialized. Call init() first.");
        }
        try {
            Connection result = pool.getConnection();
            result.setAutoCommit(false);
            return result;
        } catch (SQLException ex) {
            throw new IllegalStateException("Error getting connection from pool", ex);
        }
    }

    /** Create database tables and load demo data. */
    private void initDatabaseTables() {
        try (Connection db = getConnection()) {
            HotelService.get(db).initDatabaseTables();
            db.commit();
        } catch (Exception ex) {
            throw new IllegalStateException("Database initialization failed", ex);
        }
    }

    /**
     * Static initializer for the HikariCP connection pool.
     * Configures a high-performance DataSource with the following settings:
     * <ul>
     * <li><b>Database:</b> In-memory H2 database ("jbook3").</li>
     * <li><b>IGNORECASE=TRUE:</b> Names and comparisons are case-insensitive.</li>
     * <li><b>DB_CLOSE_DELAY=-1:</b> Prevents database deletion when the last connection closes;
     *      data persists until the JVM shuts down.</li>
     * <li><b>Security:</b> Password is retrieved dynamically via {@link #readPassword()}
     *      to keep credentials out of the source code.</li>
     * </ul>
     */
    private HikariConfig createConfig() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:h2:mem:jbook3;IGNORECASE=TRUE;DB_CLOSE_DELAY=-1");
        config.setDriverClassName(org.h2.Driver.class.getName());
        config.setUsername("sa");
        config.setPassword(readPassword());

        // Pool performance and optimization settings
        config.setMaximumPoolSize(5);
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        return config;
    }

    private static String readPassword() {
        String homeDir = System.getProperty("user.home");
        Path passwordFile = Paths.get(homeDir, ".jbookDbPassword.txt");
        if (Files.exists(passwordFile)) {
            try {
                return Files.readString(passwordFile).strip();
            } catch (IOException e) {
                throw new IllegalStateException("Can't read the file: " + passwordFile);
            }
        }
        return DEFAULT_PASSWORD;
    }
}