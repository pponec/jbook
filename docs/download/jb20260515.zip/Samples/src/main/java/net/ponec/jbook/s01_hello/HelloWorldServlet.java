/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s01_hello;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;

/** A simple servlet implementation */
@WebServlet("/hello-world")
public class HelloWorldServlet extends HttpServlet {

    /** Handles the HTTP GET request */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String html = """
                <!DOCTYPE html>
                <html lang='en'>
                    <head>
                        <meta charset='UTF-8'/>
                        <title>Demo</title>
                        <link href='css/hello.css' rel='stylesheet'/>
                    </head>
                    <body>
                        <h1>Hello, World!</h1>
                        %s
                    </body>
                </htm>
                """.formatted(WebTools.createFooter(this));
        PrintWriter writer = response.getWriter();
        writer.append(html);
    }
}
