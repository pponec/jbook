package net.ponec.jbook.s70_database.service;

import net.ponec.jbook.s70_database.entity.City;
import net.ponec.jbook.s70_database.entity.Hotel;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.stream.Stream;

public class HotelServiceCsv {
    static final String CSV_FILE_NAME = "/hotels/Hotels.csv";

    /** Get all hotels with USD currency */
    public Stream<Hotel> getAllHotelsFromCsv(String currency) {
        return getCsvStream(CSV_FILE_NAME)
                .filter(line -> !line.isEmpty())
                .filter(line -> !line.startsWith("#"))
                .skip(1) // Skip the header
                .map(line -> mapLineToHotel(line))
                .filter(hotel -> currency.equals(hotel.getCurrency()));
    }

    /** Items: 0.Hotel name|1.City|2.Country|3.Street|4.Price|5.Currency|6.Phone Number|7.Stars */
    protected Hotel mapLineToHotel(String line) {
        String[] result = line.split("\\|");
        Hotel hotel = new Hotel();
        hotel.setName(result[0]);
        hotel.setCity(getCity(result[1], result[2]));
        hotel.setStreet(result[3]);
        hotel.setPrice(new BigDecimal(result[4]));
        hotel.setCurrency(result[5]);
        hotel.setPhone(result[6]);
        hotel.setStars(Short.valueOf(result[7]));
        hotel.setActive(true);
        return hotel;
    }

    /** Create a new City object */
    private City getCity(String cityName, String countryCode) {
        City result = new City();
        result.setName(cityName);
        result.setCountryCode(countryCode);
        return result;
    }

    protected Stream<String> getCsvStream(String resource) {
        InputStream inputStream = getClass().getResourceAsStream(resource);
        if (inputStream == null) {
            throw new IllegalStateException("Resource %s was not found".formatted(resource));
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
        return reader.lines();
    }

}
