/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s06_vehicle;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import net.ponec.jbook.s06_vehicle.domain.Car;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.HtmlElement;

/** Vehicle registration servlet */
@WebServlet( "/vehicles")
public class VehicleServlet extends HttpServlet {

    /** Vehicle service */
    private final RegistrationService vehicleService = new RegistrationService();

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try (HtmlElement html = HtmlElement.niceOf("Vehicle report", response, "css/car.css")) {
            html.getBody().addHeading(html.getTitle());
            html.getBody().addTable(getTableModel(), "numbers");
            WebTools.addFooter(html, this);
        }
    }

    /**
     * Create a vehicle report
     * @return A result
     */
    private List<Object[]> getTableModel() {
        List<Object[]> result = new ArrayList<>();
        Object[] header = { "Order", "Manufacturer", "Model", "Made", "Serial number"
                          , "Power [kW]", "Energy", "Trunk [l]", "Owner"};
        result.add(header);
        for (Car car : vehicleService.getFictionalCars()) {
            String ownerName = car.getOwner().getFirstname()
                           + " "
                           + car.getOwner().getSurname();
            Object[] row = { result.size()
                           , car.getModel().getManufacturer().getName()
                           , car.getModel().getName()
                           , car.getMade()
                           , car.getMotorSerialNumber()
                           , car.getEngine().getPower()
                           , car.getEngine().getFuelName()
                           , car.getTrunkVolume()
                           , ownerName
                           };
            result.add(row);
        }
        return result;
    }
}
