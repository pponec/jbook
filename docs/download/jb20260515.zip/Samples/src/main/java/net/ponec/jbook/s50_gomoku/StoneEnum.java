/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s50_gomoku;

/** An enumeration of stones */
public enum StoneEnum {
    /** White stone */
    WHITE_STONE,
    /** Black stone */
    BLACK_STONE,
    /** No stone */
    NO_STONE
}
