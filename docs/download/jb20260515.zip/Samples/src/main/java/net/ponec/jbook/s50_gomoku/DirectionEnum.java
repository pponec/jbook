/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s50_gomoku;

/** An enumeration of directions */
public enum DirectionEnum {
    RIGHT(1, 0),
    DOWN(0, 1),
    RIGHT_UP(1, -1),
    RIGHT_DOWN(1, 1);

    /* A shift in X direction */
    final int dx;
    /* A shift in Y direction */
    final int dy;

    /** Constructor */
    private DirectionEnum(int dx, int dy) {
        this.dx = dx;
        this.dy = dy;
    }

    /** Move the point to forward or back */
    public BoardPoint move(BoardPoint point, boolean forward) {
        if (forward) {
            point.set(point, dx, dy);
        } else {
            point.set(point, -dx, -dy);
        }
        return point;
    }
}