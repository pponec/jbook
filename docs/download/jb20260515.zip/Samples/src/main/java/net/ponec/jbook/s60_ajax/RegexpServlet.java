/* Copyright 2020-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s60_ajax;

import net.ponec.jbook.tools.MyHttpServlet;
import net.ponec.jbook.tools.RegexpService;
import net.ponec.jbook.tools.WebTools;
import net.ponec.jbook.tools.model.Message;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.web.ajax.JavaScriptWriter;
import org.ujorm.tools.web.json.JsonBuilder;
import org.ujorm.tools.web.request.HttpContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.util.logging.Logger;
import static org.ujorm.tools.web.ajax.JavaScriptWriter.DEFAULT_AJAX_REQUEST_PARAM;

/**
 * A live example of the HtmlElement inside a servlet using a Dom4j library.
 * @author Pavel Ponec
 */
@WebServlet("/regexp")
public class RegexpServlet extends MyHttpServlet {
    /** Logger */
    private static final Logger LOGGER = Logger.getLogger(RegexpServlet.class.getName());
    /** A service */
    private final RegexpService service = new RegexpService();

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param ctx servlet response & servlet request
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpContext ctx) {
        try (HtmlElement html = HtmlElement.niceOf("Regular expressions", ctx,
                "css/regexp.css")) {
            new JavaScriptWriter().write(html.getHead());
            Message msg = highlight(ctx);
            try (Element body = html.getBody()) {
                body.addHeading(html.getTitle());
                try (Element form = body.addForm().setMethod(Html.V_POST).setAction("?")) {
                    form.addInput(Constants.CONTROL_CSS)
                            .setType(Html.V_TEXT)
                            .setName(Constants.REGEXP)
                            .setValue(ctx.getParameter(Constants.REGEXP))
                            .setAttribute(Html.A_PLACEHOLDER, "Regular expression");
                    form.addTextArea(Constants.CONTROL_CSS)
                            .setAttribute(Html.A_PLACEHOLDER, "Plain Text")
                            .setName(Constants.TEXT)
                            .addText(ctx.getParameter(Constants.TEXT));
                    form.addDiv().addButton("btn", "btn-primary").addText("Evaluate");
                    form.addDiv(Constants.CONTROL_CSS, Constants.AJAX_AREA).addRawText(msg);
                }
                WebTools.addFooter(html, this);
            }
        }
    }

    @Override
    protected void doPost(HttpContext ctx) throws IOException {
        if (DEFAULT_AJAX_REQUEST_PARAM.of(ctx, false)) {
            doAjax(ctx, JsonBuilder.of(ctx.writer())).close();
        } else {
            doGet(ctx);
        }
    }

    protected JsonBuilder doAjax(HttpContext ctx, JsonBuilder json) throws IOException {
        Message msg = highlight(ctx);
        json.writeClass(Constants.AJAX_AREA, e -> e
                .addElementIf(msg.isError(), Html.SPAN, "error")
                .addRawText(msg));
        return json;
    }

    /** Build a HTML result */
    protected Message highlight(HttpContext ctx) {
        return service.highlight(
                ctx.getParameter(Constants.TEXT),
                ctx.getParameter(Constants.REGEXP));
    }

    /** CSS constants and identifiers */
    static class Constants {
        /** Bootstrap form control CSS class name */
        static final String CONTROL_CSS = "text";
        /** CSS class name for the output box */
        static final String AJAX_AREA = "out";
        /** Regular expression parameter name */
        static final String REGEXP = "regexp";
        /** Plain text parameter name */
        static final String TEXT = "text";
    }

}
