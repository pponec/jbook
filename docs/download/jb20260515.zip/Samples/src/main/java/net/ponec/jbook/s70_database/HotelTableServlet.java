/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s70_database;

import net.ponec.jbook.s70_database.entity.Hotel;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.HtmlElement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import org.ujorm.tools.web.ajax.JavaScriptWriter;
import org.ujorm.tools.web.json.JsonBuilder;
import org.ujorm.tools.web.request.HttpContext;
import static net.ponec.jbook.s70_database.HotelTableServlet.Constants.*;

import java.io.IOException;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/** Show database table content */
@WebServlet("/demo-hotels")
public class HotelTableServlet extends AbstractDatabaseServlet {

    private static final int TABLE_ROW_LIMIT = 10;

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param ctx Servlet request context
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpContext ctx) {
        try (HtmlElement html = HtmlElement.niceOf("Database Hotel Report", ctx, "css/hotels.css")) {
            new JavaScriptWriter().write(html.getHead());
            try (Element body = html.getBody().setClass("hotels")) {
                body.addHeading(html.getTitle());
                createFilter(body.addForm("filter"), ctx);
                body.addDiv(AJAX_AREA).addTable(getTableModel(getParameters(ctx)), "numbers");
                WebTools.addFooter(html, this);
            }
        }
    }

    private void createFilter(Element div, HttpContext ctx) {
        div.addLabel().setFor(HOTEL).addText("Hotel");
        div.addInput()
                .setAttribute("placeholder", "hotel name")
                .setType("text")
                .setName(HOTEL)
                .setValue(ctx.getParameter(HOTEL, ""))
                .setId(HOTEL);

        div.addLabel().setFor(CITY).addText("City");
        div.addInput()
                .setAttribute("placeholder", "city name")
                .setType("text")
                .setName(CITY)
                .setValue(ctx.getParameter(CITY, ""))
                .setId(CITY);

        div.addLabel().setFor(PAGE).addText("Page");
        div.addInput()
                .setAttribute("placeholder", "page number")
                .setType("text")
                .setName(PAGE)
                .setValue(ctx.getParameter(PAGE, "1"))
                .setId(PAGE);

        // Auxiliary button to send the form in case of missing JavaScript:
        div.addButton("btn", "btn-primary").setType("submit")
                .addText("Find")
                .addScript()
                .addRawText("document.currentScript.parentNode.style.display='none'");
    }

    protected JsonBuilder doAjax(HttpContext ctx, JsonBuilder json) throws IOException {
        json.writeClass(AJAX_AREA, e -> e.addTable(getTableModel(getParameters(ctx))));
        return json;
    }

    /**
     * Create a hotel report
     * @return A result
     */
    private List<Object[]> getTableModel(Parameters params) {
        List<Object[]> result = new ArrayList<>();
        Object[] header = { "Hotel", "City", "Street", "Phone", "Price", "Currency", "Stars"};
        result.add(header);
        for (Hotel hotel : getHotelService().findActiveHotels(params.hotel, params.city, TABLE_ROW_LIMIT, params.page)) {
            Object[] row =
                    { hotel.getName()
                    , hotel.getCity().getName()
                    , hotel.getStreet()
                    , hotel.getPhone()
                    , hotel.getPrice().setScale(0, RoundingMode.HALF_UP)
                    , hotel.getCurrency()
                    , "★".repeat(hotel.getStars())
            };
            result.add(row);
        }
        return result;
    }

    /** Get HTTP parameters */
    private Parameters getParameters(HttpContext ctx) {
        String hotel = ctx.getParameter(HOTEL, "");
        String city = ctx.getParameter(CITY, "");
        int page = ctx.getParameter(PAGE, 1, Integer::parseInt);
        return new Parameters(hotel, city, Math.max(page - 1, 0));
    }

    record Parameters(String hotel, String city, int page){}

    /** CSS constants and identifiers */
    static class Constants {
        /** Bootstrap form control CSS class name */
        static final String HOTEL = "hotel";
        /** CSS class name for the output box */
        static final String CITY = "city";
        /** Page number of the report */
        static final String PAGE = "page";
        /** Table hotels */
        static final String AJAX_AREA = "table";
    }
}
