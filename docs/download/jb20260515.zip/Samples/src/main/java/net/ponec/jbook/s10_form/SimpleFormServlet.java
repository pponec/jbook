/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s10_form;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;

/** A live example inside a servlet */
@WebServlet("/simple-form")
public class SimpleFormServlet extends HttpServlet {

    /** A name of supported parameter */
    private static final String PARAMETER_NAME = "text";

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        try (HtmlElement html = HtmlElement.niceOf("Simple form", response, "css/form.css")) {
            html.getBody().addHeading(html.getTitle());
            Element form = html.getBody().addForm()
                    .setMethod("post")
                    .setAction(request.getRequestURI());
            try (Element line = form.addDiv()) {
                line.addLabel().addText("Some text");
                line.addTextInput()
                        .setName(PARAMETER_NAME)
                        .setValue(request.getParameter(PARAMETER_NAME));
            }
            form.addInput()
                    .setType(Html.V_SUBMIT)
                    .setValue("Submit");
            WebTools.addFooter(html, this);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
