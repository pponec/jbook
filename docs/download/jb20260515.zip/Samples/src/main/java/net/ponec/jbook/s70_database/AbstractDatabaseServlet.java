/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s70_database;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import net.ponec.jbook.s70_database.service.DatabaseProvider;
import net.ponec.jbook.s70_database.service.HotelService;
import net.ponec.jbook.tools.MyHttpServlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Abstract database servlet */
public abstract class AbstractDatabaseServlet extends MyHttpServlet {
    private static final Logger LOGGER = Logger.getLogger(AbstractDatabaseServlet.class.getName());
    private static final ThreadLocal<HotelService> SERVICE_HOLDER = new ThreadLocal<>();

    public HotelService getHotelService() {
        return SERVICE_HOLDER.get();
    }

    /** Open database connection per request */
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (Connection dbConnection = DatabaseProvider.getConnection()) {
            try {
                SERVICE_HOLDER.set(HotelService.get(dbConnection));
                super.service(request, response);
                dbConnection.commit();
            } catch (Exception e) {
                dbRollback(dbConnection);
                throw e;
            } finally {
                SERVICE_HOLDER.remove();
            }
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Request failed: " + e.getMessage(), e);
            if (e instanceof ServletException) throw (ServletException) e;
            if (e instanceof IOException) throw (IOException) e;
            throw new ServletException("Database or Request processing failed", e);
        }
    }

    private void dbRollback(Connection conn) {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.rollback();
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Rollback failed", ex);
        }
    }
}
