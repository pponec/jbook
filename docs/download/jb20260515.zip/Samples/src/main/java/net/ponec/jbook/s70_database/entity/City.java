package net.ponec.jbook.s70_database.entity;

public class City {

   private long id = -1;
   private String name;
   /** ISO 3166-1 alpha-2 */
   private String countryCode;

   public long getId() {
      return id;
   }

   public void setId(long id) {
      this.id = id;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getCountryCode() {
      return countryCode;
   }

   public void setCountryCode(String countryCode) {
      this.countryCode = countryCode;
   }

   @Override
   public String toString() {
      return "City{" +
              "id=" + id +
              ", name='" + name + '\'' +
              ", countryCode='" + countryCode + '\'' +
              '}';
   }
}
