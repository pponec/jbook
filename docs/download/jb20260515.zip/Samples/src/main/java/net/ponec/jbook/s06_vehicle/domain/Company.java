/* Copyright 2018-2026 Pavel Ponec, https;//jbook.ponec.net */
package net.ponec.jbook.s06_vehicle.domain;

import java.util.Locale;

/** Company data model */
public class Company {

    /** Name */
    private String name;
    /** Country (e.g. cs-CZ for Czech Republic */
    private Locale country;

    /** Default constructor */
    public Company() {
    }

    /** Parameter constructor */
    public Company(String name, Locale country) {
        this.name = name;
        this.country = country;
    }

    /**
     * Name
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * Name
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Country (e.g. cs-CZ for Czech Republic
     * @return the country
     */
    public Locale getCountry() {
        return country;
    }

    /**
     * Country (e.g. cs-CZ for Czech Republic
     * @param country the country to set
     */
    public void setCountry(Locale country) {
        this.country = country;
    }

}
