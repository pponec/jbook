/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s60_ajax;

import net.ponec.jbook.s50_gomoku.*;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.web.ajax.JavaScriptWriter;
import org.ujorm.tools.web.json.JsonBuilder;
import net.ponec.jbook.s50_gomoku.BoardModel;
import org.ujorm.tools.web.request.HttpContext;


/** Simple board game */
@WebServlet("/go-moku-ajax")
public class GoMokuAjaxServlet extends GoMokuServlet {

    /** Message bar parameter */
    protected static final String LASTPOINT_PARAM = "lastPoint";

    public GoMokuAjaxServlet() {
        super(new FineBoardService());
    }

    /** Cascading style sheets */
    private static final String[] CSS = new String[] {"css/board.css", "css/gomoku-ajax.css"};

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param ctx HTTP servlet request & response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpContext ctx) throws IOException {
        if (JavaScriptWriter.DEFAULT_AJAX_REQUEST_PARAM.of(ctx, false)) {
            doAjax(ctx, JsonBuilder.of(ctx)).close();
        } else {
            doGet(ctx);
        }
    }

    /** Write a Javascript to a header */
    @Override
    protected void writeHeaderElements(HtmlElement html) {
        new JavaScriptWriter().write(html.getHead());
    }

    /** Add last point parameter */
    @Override
    protected void createBoardModel(Element form, BoardModel board) {
        form.addInput().setType(Html.V_HIDDEN)
                .setName(LASTPOINT_PARAM)
                .setValue(board.getLastMove().getPointIndex(board));
        super.createBoardModel(form, board);
    }

    protected JsonBuilder doAjax(HttpContext ctx, JsonBuilder json) throws IOException {
        BoardModel board = service.createBoardModel(ctx);
        int lastPoint = ctx.getParameter(LASTPOINT_PARAM, 0, Integer::parseInt);
        for (BoardPoint point : board.getChangedPoints(lastPoint)) {
            String pointSelector = "tr:nth-child(%s) td:nth-child(%s)".formatted(
                    point.getY() + 1,
                    point.getX() + 1);
            json.write(pointSelector, e -> createStone(e, point, board));
        }
        json.writeId(BOARD_MODEL_ID, e -> createBoardModel(e, board));
        json.writeId(MESSAGE_ID, e -> createMessagePanel(e, board));
        return json;
    }

    /** Get CSS styles */
    @Override
    protected String[] css() {
        return CSS;
    }

}
