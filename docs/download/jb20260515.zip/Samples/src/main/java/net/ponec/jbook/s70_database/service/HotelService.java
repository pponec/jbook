package net.ponec.jbook.s70_database.service;

import net.ponec.jbook.s70_database.dao.CityDao;
import net.ponec.jbook.s70_database.dao.HotelDao;
import net.ponec.jbook.s70_database.entity.City;
import net.ponec.jbook.s70_database.entity.Hotel;

import java.sql.Connection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class HotelService {
    static final String USD_CURRENCY = "USD";

    private final HotelDao hotelDao;
    private final CityDao cityDao;
    private final HotelServiceCsv hotelServiceCsv;

    public HotelService(HotelDao hotelDao, CityDao cityDao, HotelServiceCsv hotelServiceCsv) {
        this.hotelDao = hotelDao;
        this.cityDao = cityDao;
        this.hotelServiceCsv = hotelServiceCsv;
    }

    /** Create database tables and load demo data. */
    public synchronized HotelService initDatabaseTables() {
        if (!hotelDao.hasTables()) {
            cityDao.createTable();
            hotelDao.createTable();
            insertHotelsFromCsv();
        }
        return this;
    }

    public List<Hotel> findActiveHotels(String hotel, String city, int limit, int page) {
        return hotelDao.find(hotel, city, limit, limit * page, true);
    }

    private void insertHotelsFromCsv() {
        try (Stream<Hotel> hotels = hotelServiceCsv.getAllHotelsFromCsv(USD_CURRENCY)) {
            hotels.forEach(hotel -> insertHotel(hotel));
        }
    }

    private void insertHotel(Hotel hotel) {
        City city = hotel.getCity();
        Optional<City> optionalCity = cityDao.findByName(city.getName());
        long cityId = optionalCity
                .map(dbCity -> dbCity.getId())      //  get database id
                .orElseGet(() -> cityDao.insert(city));  // else insert the city and get a new id.
        city.setId(cityId);
        hotelDao.insert(hotel);
    }

    /** Build all services */
    public static HotelService get(Connection connection) {
        CityDao cityDao = new CityDao(connection);
        HotelDao hotelDao = new HotelDao(connection);
        HotelServiceCsv csv = new HotelServiceCsv();
        HotelService result = new HotelService(hotelDao, cityDao, csv);
        return result;
    }
}
