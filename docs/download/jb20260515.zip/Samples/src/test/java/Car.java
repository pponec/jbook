/* Copyright 2018-2026 Pavel Ponec */
class Car {
    // -------------------------------------
    String modelName;
    int enginePower;
    // -------------------------------------
    String getModelName() {
        return modelName;
    }
    void setModelName(String name) {
        modelName = name;
    }
    int getEnginePower() {
        return enginePower;
    }
    void setEnginePower(int power) {
        enginePower = power;
    }
}
