package net.ponec.jbook.plainSamples;

public class ByteTest {

    private void byteTest() {
        byte x = 1;
        byte y = 22;
        byte z = (byte) 999_999;
    }

    private void shortTest() {
        short x = 1;
        short y = 22;
        short z = (short) 999_999;
    }

    private void commonTest() {
        long age = 25;
        byte code = (byte) age;
        short value = (short) 654321;
        int price = (int) 19.99;
    }
}
