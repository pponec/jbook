/* Copyright 2018-2026 Pavel Ponec */
package net.ponec.jbook.s20_board;

import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Sample
 *
 * @author Pavel Ponec
 */
public class LambdaSamples {

    public void acceptSample1() {
        Optional<String> text = Optional.ofNullable("text");

        Consumer<String> consumer = new Consumer<String>() {
            public void accept(String t) {
                doSomething(t);
            }
        };
        text.ifPresent(consumer);
    }

    public void acceptSample2() {
        Optional<String> text = Optional.ofNullable("text");
        Consumer<String> consumer = (String t) -> doSomething(t);
        text.ifPresent(consumer);
    }

    public void acceptSample3() {
        Optional<String> text = Optional.ofNullable("text");
        text.ifPresent((String t) -> doSomething(t));
    }

    // ---
    public void mapSample1() {
        Optional<String> text = Optional.ofNullable("text");
        Function<String, Integer> function = new Function<String, Integer>() {
            public Integer apply(String t) {
                return t.length();
            }
        };
        Integer lenght = text.map(function).orElse(0);
    }

    public void mapSample2() {
        Optional<String> text = Optional.ofNullable("text");
        Function<String, Integer> function = (String t) -> t.length();
        Integer length = text.map(function).orElse(0);
    }

    public void mapSample3() {
        Optional<String> text = Optional.ofNullable("text");
        Integer lenght = text.map((String t) -> t.length()).orElse(0);
    }

    // ---
    public void converterSample1() {
        Optional<String> text = Optional.ofNullable("1");
        Function<String, Integer> function = new Function<String, Integer>() {
            public Integer apply(String t) {
                return Integer.parseInt(t);
            }
        };
        Integer number = text.map(function).orElse(0);
    }

    public void converterSample2() {
        Optional<String> text = Optional.ofNullable("1");
        Function<String, Integer> function = (String t) -> Integer.parseInt(t);
        int number = text.map(function).orElse(0);
    }

    public void converterSample3() {
        Optional<String> text = Optional.ofNullable("1");
        int number = text.map(t -> Integer.parseInt(t)).orElse(0);
    }

    public void converterSample4() {
        Optional<String> text = Optional.ofNullable("75");
        int number = text.map(Integer::parseInt).orElse(0);
    }

    // --- Conversion

    public void conv01() {
        Function<String, Integer> converter = (String t) -> { return Integer.parseInt(t); };
        int number = converter.apply("1");
    }

    // ---
    /**
     * Helper method
     */
    private void doSomething(String text) {
        // do something ....
    }

}
