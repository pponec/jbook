package net.ponec.jbook.s70_database;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RecordTest {

    @Test
    void doRecoredTest() {
        var car = new Car("Ford", 100);
        assertEquals("Ford", car.modelName);
        assertEquals("Car[modelName=Ford, enginePower=100]", "" + car);
    }

    // @Test
    void doManyTest() {
        var arrayList = new ArrayList<String>() {{
            add("A");
            add("B");
        }};
        var many = new Many(1, arrayList);
        assertEquals("A", many.items.get(0));
        assertEquals(0, Many.counter);
        assertSame(arrayList, many.items);
    }

    record Car (String modelName, int enginePower) {}

    record Many(int id, List<String> items) {
        public static int counter = 0;

        public List<String> items() {
            ++ Many.counter;
            return List.copyOf(items);
        }
        public List<String> getItems() {
            return getItems();
        }
    }

}