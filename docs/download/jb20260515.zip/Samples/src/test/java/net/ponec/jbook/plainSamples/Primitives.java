/* Copyright 2018-2026 Pavel Ponec */
package net.ponec.jbook.plainSamples;

/**
 * Primitives
 *
 * @author Pavel Ponec
 */
public class Primitives {

    public void sample1() {
        int myNumber = 10;
        char myCharacter = 'A';
        boolean validInterval = true;

        byte limitedCharacter = 'A';
    }

    public void sample2() {
        int maxLimit = 4 + 6;
        int myNumber = 2 * 3;
        boolean validInterval = myNumber <= maxLimit;
        boolean evenNumber = (myNumber % 2) == 0;
        boolean validOddNumber = validInterval && evenNumber;
    }

    public void sample3() {
        Integer myNumber = 10;
        Character myCharacter = 'A';
        Boolean validInterval = true;
    }

    public void sample4() {
        byte firstCharacter = 'A';
        byte secondCharacter = 'B';
        byte thirdCharacter = 'C';
        byte[] word = {firstCharacter, secondCharacter, thirdCharacter};
    }

    public void sample5() {
        int i = Integer.parseInt("465");
    }

}
