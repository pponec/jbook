package net.ponec.jbook.s70_database.service;

import net.ponec.jbook.s70_database.entity.Hotel;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class HotelServiceInitTest {

    @Test
    void getAllHotelsFromCsv() {
        HotelServiceCsv instance = new HotelServiceCsv();
        List<Hotel> hotels = instance.getAllHotelsFromCsv(HotelService.USD_CURRENCY).toList();

        assertNotNull(hotels);
        assertEquals(511, hotels.size());
        Hotel theFirst = hotels.get(0);
        assertEquals("Hotel Zlatý lev", theFirst.getName());
        assertEquals("Prague", theFirst.getCity().getName());
        assertEquals("CZ", theFirst.getCity().getCountryCode());
        assertEquals(new BigDecimal("125"), theFirst.getPrice());
    }
}