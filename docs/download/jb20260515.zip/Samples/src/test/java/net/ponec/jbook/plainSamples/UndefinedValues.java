/* Copyright 2018-2026 Pavel Ponec */
package net.ponec.jbook.plainSamples;

import net.ponec.jbook.plainSamples.domains.Car;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 *
 * @author Pavel Ponec
 */
public class UndefinedValues {

    @Test
    void test() {
        assertTrue(checkValidCar(new Car()));
        assertFalse(checkValidCar(null));

        assertTrue(checkValidDouble(1.1));
        assertFalse(checkValidDouble(Double.NaN));
        assertFalse(checkValidDouble(0.0 / 0));
    }

    boolean checkValidCar(Car car) {
        return car != null;
    }

    boolean checkValidDouble(double number) {
        return !Double.isNaN(number);
    }
}
