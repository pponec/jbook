/* Copyright 2026-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.tools;

import jakarta.servlet.annotation.WebServlet;
import net.ponec.jbook.tools.model.Message;
import org.jetbrains.annotations.NotNull;
import org.ujorm.tools.common.StringUtils;
import org.ujorm.tools.converter.HtmlToJavaConverter;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.web.ajax.JavaScriptWriter;
import org.ujorm.tools.web.ao.HttpParameter;
import org.ujorm.tools.web.json.JsonBuilder;
import org.ujorm.tools.web.request.HttpContext;

import java.io.IOException;
import java.util.Map;
import java.util.logging.Logger;

import static net.ponec.jbook.tools.ElementConverterServlet.Constants.*;

/**
 * Servlet to converting a HTML code to Java Element code.
 * @author Pavel Ponec
 */
@WebServlet(ElementConverterServlet.URL_PATTERN )
public class ElementConverterServlet extends MyHttpServlet {

    /** URL pattern */
    static final String URL_PATTERN = "/element";
    /** Logger */
    private static final Logger LOGGER = Logger.getLogger(ElementConverterServlet.class.getName());
    /** A generator service */
    private final HtmlToJavaConverter service = new HtmlToJavaConverter();

    /** Handles the HTTP <code>GET</code> method. */
    @Override
    protected void doGet(HttpContext ctx) {
        final var requestData = getRequestData(ctx);
        final CharSequence[] css =
                { PRETIFY_URL.concat("prettify.css")
                        , "/css/source.css"
                        , "/css/converter.css"
                };
        try (var html = HtmlElement.niceOf("HTML to Elements Converter", ctx, css)) {
            writeJavaScript(html);
            try (var body = addBodyWithPrettyPrint(html)) {
                body.addHeading(html.getTitle());
                printAjaxWarningMessage(body);
                try (Element form = body.addForm().setMethod(Html.V_POST).setAction("?")) {
                    form.addTextArea(CONTROL_CSS)
                            .setName(PARAMETER_NAME)
                            .setAttribute(Html.A_PLACEHOLDER, "Write any HTML Code")
                            .setAttribute(Html.A_MAXLENGTH, INPUT_MAX_LENGTH + 1)
                            .addText(requestData.html(INPUT_MAX_LENGTH));
                    form.addLabel(INLINE_STYLE)
                            .addText("Inline style:")
                            .addCheckBox(INLINE_STYLE)
                            .setCheckBoxValue(requestData.inlineStyle);
                    form.addLabel(INLINE_STYLE)
                            .addText("CSS\u00A0constants:")
                            .addCheckBox(SEPARATED_CSS_CONSTANTS)
                            .setCheckBoxValue(requestData.separatedCss);
                    try (var btnBar = form.addDiv()) {
                        btnBar.addButton("btn", "btn-primary")
                                .setTitle("Convert HTML code to Java Elements")
                                .setType(Html.V_SUBMIT)
                                .addText("⚙️ Convert to Elements");
                        btnBar.addButton("btn", "copy")
                                .setTitle("Copy to Clipborad")
                                .setType(Html.BUTTON)
                                .setAttribute(Html.A_ONCLICK, onClickJs())
                                .addText("📋 Copy");
                        btnBar.addSpan("copy-done").addText(" ");
                    }
                    printJavaCode(form.addDiv(CONTROL_CSS, RESULT_CSS), requestData);
                }
                WebTools.createSourceFooter(body, getClass());
            }
        }
    }

    private void printJavaCode(Element parent, RequestData requestData) {
        final var msg = buildJavaCode(requestData);
        parent.addPreformatted(msg.isError()
                ? ERROR_CSS
                : "prettyprint lang-java linenums")
                .addText(msg);
    }

    private @NotNull RequestData getRequestData(HttpContext ctx) {
        final var result = new RequestData(
                ctx.parameter(PARAMETER_NAME, DEFAULT_HTML),
                ctx.parameter(INLINE_STYLE, Boolean::parseBoolean, true),
                ctx.parameter(SEPARATED_CSS_CONSTANTS, Boolean::parseBoolean, true)
        );
        return result;
    }

    @NotNull
    protected JsonBuilder doAjax(HttpContext ctx, JsonBuilder output) throws IOException {
        final var data = getRequestData(ctx);
        output.writeClass(RESULT_CSS, e -> printJavaCode(e, data));
        output.writeJsKey(RELOAD_JS); // Refresh code highlights
        return output;
    }

    private void printAjaxWarningMessage(Element element) {
        if (!AJAX_ENABLED) {
            String msg = """
                    AJAX is temporarily disabled to reduce server load.
                    Please use the submit button.
                    """;
            element.addDiv("warning").addText(msg);
        }
    }

    /** Javascript evnent on the click */
    @NotNull
    private String onClickJs() {
        return ("navigator.clipboard.writeText(document.querySelector('.%s').innerText);" +
                "document.querySelector('.copy-done').textContent = '%s';")
                .formatted(RESULT_CSS, MSG_COPY);
    }

    /** Load prettyPrint and create Body */
    private Element addBodyWithPrettyPrint(HtmlElement html) {
        //new JavaScriptWriter().write(html.getHead(), Map.of(RELOAD_JS, "PR.prettyPrint()"));
        html.addJavascriptLink(true, PRETIFY_URL.concat("prettify.js"));
        return html.addBody().setAttribute("onload", "prettyPrint()");
    }

    /** Write a Javascript to a header */
    private void writeJavaScript(@NotNull final HtmlElement html) {
        if (AJAX_ENABLED) {
            new JavaScriptWriter().write(html.getHead(), Map.of(RELOAD_JS, "PR.prettyPrint()"));
        }
    }

    /** Build a text result */
    protected Message buildJavaCode(RequestData data) {
        if (data.html.length() > INPUT_MAX_LENGTH) {
            return Message.of(new IllegalArgumentException(getLengthWarningMessage()));
        }
        try {
            return Message.of(service.convertHtmlToJavaElements(
                    data.html,
                    !data.inlineStyle,
                    data.separatedCss));
        } catch (Exception ex) {
            return Message.of(ex);
        }
    }

    private String getLengthWarningMessage() {
        return """
                On this page, the HTML code must not exceed %s characters.
                To convert longer texts, please use the %s class from the Ujorm framework.
                """.formatted(StringUtils.formatSeparator(INPUT_MAX_LENGTH),
                service.getClass().getSimpleName());
    }

    record RequestData(@NotNull String html, boolean inlineStyle, boolean separatedCss) {
        String html(final int limit) {
            return html.length() > limit
                    ? html.substring(0, limit) + "..."
                    : html;
        }
    };

    /** Text constants and identifiers */
    enum Constants implements HttpParameter {
        /** A name of supported parameter */
        PARAMETER_NAME("text"),
        /** ID + NAME + CSS for the inline checkbox */
        INLINE_STYLE("box-style"),
        /** CSS constants are in the separated class. */
        SEPARATED_CSS_CONSTANTS("css-constants"),
        /** Bootstrap form control CSS class name */
        CONTROL_CSS("form-control"),
        /** Bootstrap form control CSS class name */
        RESULT_CSS("result"),
        /** CSS class name for the error case */
        ERROR_CSS("error"),
        /** Google pretify URL */
        PRETIFY_URL("/css/google-code-prettify/"),
        /** Message after copy */
        MSG_COPY("Text has been copied");

        /** A key to reload Prettify Javascript */
        static final String RELOAD_JS = "reload";
        /** Default HTML value */
        static final String DEFAULT_HTML = "<html/>";
        /** Max length of the text area */
        static final int INPUT_MAX_LENGTH = 100_000;
        /** Enable AJAX feature */
        static final boolean AJAX_ENABLED = false;

        /** Parameter name */
        final String name;

        Constants(String name) {
            this.name = name;
        }

        /** Returns the key name. */
        @Override
        final public String toString() {
            return name;
        }
    }
}
