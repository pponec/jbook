/*
 * Copyright 2020-2024 Pavel Ponec, https://github.com/pponec/demo-ajax
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.ponec.jbook.tools;

import org.jetbrains.annotations.NotNull;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.web.json.JsonBuilder;
import org.ujorm.tools.web.request.HttpContext;
import org.ujorm.tools.xml.config.HtmlConfig;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import static org.ujorm.tools.web.ajax.JavaScriptWriter.DEFAULT_AJAX_REQUEST_PARAM;

/**
 * A live example of the HtmlElement inside a Servlet using a ujo-web library.
 *
 * @author Pavel Ponec
 */
public abstract class MyHttpServlet extends HttpServlet {
    /** Logger */
    protected static final Logger LOGGER = Logger.getLogger(MyHttpServlet.class.getName());

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected final void doGet(
            final HttpServletRequest request,
            final HttpServletResponse response) throws IOException {
        try {
            doGet(HttpContext.ofServlet(request, response));
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, e.getMessage(), e);
            int httpStatus = HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
            String message = String.format("%s: %s",  e.getClass().getSimpleName(), e.getMessage());

            response.setStatus(httpStatus);
            response.setHeader("Error-Message", message);
            response.getWriter().write(message);
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param requestContext servlet request and response
     */
    abstract protected void doGet(HttpContext requestContext);

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param input servlet request
     * @param output servlet response
     */
    public final void doPost(HttpServletRequest input, HttpServletResponse output) {
        final Map<String, String[]> map = input.getParameterMap();
        try {
            doPost(HttpContext.ofServlet(input, output));
        } catch (Exception e) {
            final int httpStatus = HttpServletResponse.SC_INTERNAL_SERVER_ERROR;
            final String msg = "Internal error";
            output.setStatus(httpStatus);
            output.setHeader("Error-Message", msg);
            LOGGER.log(Level.SEVERE, msg, e);
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param ctx servlet response
     * @throws Exception if an I/O error occurs
     */
    protected void doPost(HttpContext ctx) throws Exception {
        if (DEFAULT_AJAX_REQUEST_PARAM.of(ctx, false)) {
            doAjax(ctx, JsonBuilder.of(ctx, (HtmlConfig) HtmlConfig.ofEmptyElement()
                    .setNewLine(" ")))
                    .close();
        } else {
            doGet(ctx);
        }
    }

    @NotNull
    protected JsonBuilder doAjax(HttpContext ctx, JsonBuilder output) throws IOException {
        return output;
    }

    /** Create a new HTML element */
    protected @NotNull HtmlElement getHtmlElement(
            HttpContext ctx,
            HtmlConfig config) {
        return HtmlElement.of(ctx, config);
    }

}
