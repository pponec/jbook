/* Copyright 2018-2026 Pavel Ponec */
package net.ponec.jbook.tools;

import java.io.IOException;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.ujorm.tools.Check;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.xml.ApiElement;

/**
 * Common services with static methdos
 * @author Pavel Ponec
 */
public class DomBuilder<T extends ApiElement> {

    /** A parent element */
    private final T parent;

    protected DomBuilder(@NotNull final T parent) {
        this.parent = parent;
    }

    public DomBuilder<T> addText(Object... text) throws IOException {
        for (int i = 0; i < text.length; i++) {
            if (i > 0) {
                parent.addText(" ");
            }
            parent.addText(text[i]);
        }
        return this;
    }

    public DomBuilder<T> addLinkedText(String urlLink, Object... text) throws IOException {
        DomBuilder.of(parent.addElement(Html.A).setAttribute(Html.A_HREF, urlLink))
                .addText(text);
        return this;
    }

    /** Create a HTML table */
    public T createTable(@NotNull final Object[][] data, @Nullable final String... cssClass) {
        final T result = (T) parent.addElement(Html.TABLE);

        if (Check.hasLength(cssClass)) {
            result.setAttribute(Html.A_CLASS, String.join(" ", cssClass));
        }

        for (Object[] rowValue : data) {
            final ApiElement rowElement = result.addElement(Html.TR);
            for (Object value : rowValue) {
                rowElement.addElement(Html.TD).addText(value);
            }
        }
        return result;
    }

    public static final <T extends ApiElement> DomBuilder<T> of(@NotNull final T parent) {
        return new DomBuilder<>((T) parent);
    }
}
