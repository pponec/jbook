/* Copyright 2018-2026 Pavel Ponec */
package net.ponec.jbook.tools;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.logging.Logger;

/**
 * Source Privacy Policy
 * @author Pavel Ponec
 */
@WebServlet(PrivacyPolicyServlet.URL_PATTERN)
public class PrivacyPolicyServlet extends HttpServlet {
    /** URL pattern */
    static final String URL_PATTERN = "/privacy-policy";

    /** Maximum IP address retention period in days */
    final int maxDays = 14;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/plain; charset=UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(getBody(req));
    }

    private String getBody(HttpServletRequest req) {
        final String lang = req.getLocale().getLanguage();
        return switch (lang) {

            default -> """
                Server Log Files and Security
                
                To ensure the security and stability of our services, our web server \
                automatically collects and stores IP addresses in server log files. \
                This processing is based on our legitimate interest (pursuant to Art. 6(1)(f) GDPR \
                in conjunction with Recital 49) to detect and prevent cyber attacks (e.g., DDoS attacks, \
                hacking, or unauthorized access). These logs are stored for a maximum of %s days \
                and are automatically deleted thereafter, unless they are required for the investigation \
                of a specific security incident.
                """.formatted(maxDays);

            case "es" -> """
                Archivos de registro del servidor y seguridad
                
                Para garantizar la seguridad y estabilidad de nuestros servicios, nuestro servidor web \
                recopila y almacena automáticamente direcciones IP en los archivos de registro del servidor. \
                Este tratamiento se basa en nuestro interés legítimo (de conformidad con el Art. 6(1)(f) del RGPD \
                en relación con el Recital 49) para detectar y prevenir ataques cibernéticos (por ejemplo, ataques DDoS, \
                piratería o acceso no autorizado). Estos registros se almacenan durante un máximo de %s días \
                y se eliminan automáticamente a partir de entonces, a menos que sean necesarios para la investigación \
                de un incidente de seguridad específico.
                """.formatted(maxDays);

            case "de" -> """
                Server-Log-Dateien und Sicherheit
                
                Um die Sicherheit und Stabilität unserer Dienste zu gewährleisten, erhebt und speichert unser \
                Webserver automatisch IP-Adressen in Server-Log-Dateien. \
                Diese Verarbeitung basiert auf unserem berechtigten Interesse (gemäß Art. 6 Abs. 1 lit. f DSGVO \
                in Verbindung mit Erwägungsgrund 49), Cyberangriffe (z. B. DDoS-Angriffe, Hacking oder unbefugten Zugriff) \
                zu erkennen und zu verhindern. Diese Protokolle werden für maximal %s Tage gespeichert und danach \
                automatisch gelöscht, es sei denn, sie werden für die Untersuchung eines bestimmten Sicherheitsvorfalls benötigt.
                """.formatted(maxDays);

            case "cs" -> """
                Soubory serverových protokolů a zabezpečení
                
                Pro zajištění bezpečnosti a stability našich služeb náš webový server \
                automaticky shromažďuje a ukládá IP adresy v souborech protokolů serveru. \
                Toto zpracování je založeno na našem oprávněném zájmu (podle čl. 6 odst. 1 písm. f) GDPR \
                ve spojení s recitálem 49) detekovat a předcházet kybernetickým útokům (např. DDoS útokům, \
                hackingu nebo neoprávněnému přístupu). Tyto protokoly jsou uchovávány po dobu maximálně %s dnů \
                a poté jsou automaticky smazány, pokud nejsou vyžadovány pro vyšetřování konkrétního bezpečnostního incidentu.
                """.formatted(maxDays);

        };
    }
}