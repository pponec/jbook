

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Replace file of an EPUB archive
 *
 * @author Pavel Ponec
 */
public class JReplaceAdoc {

    /** File: EPUB/toc.ncx */
    private final boolean debugMode = false;
    private final String nonBreakableSpace = "\u00A0";
    /** Výraz `{nbsp}` generuje chyby při spojení se znakem {@code `} */
    //private final String nonBreakableSpace = "{nbsp}";

    private final Charset charset = StandardCharsets.UTF_8;
    private final Pattern patternFile = Pattern.compile(".*\\.asciidoc");
    private final List<Replacement> repl = new ArrayList<>();

    public void run(String... args) {

        if (true) {
            // Nedělitelné znaky pro jednoslovné předložky.
            // Předložce může předcházet i nedělitelná mezera, kterou samotný výraz `\s` nezachytí.
            String target0 = "$1$2" + nonBreakableSpace + "$4";
            addRepl("([\\s\\u00A0])([aiouvskzAIOUVSKZ])(\\s+)([a-záéěíýóúůčďňřšťž_\\*])", target0);
        }

        if (true) {
            String target1 = "$1$2" + nonBreakableSpace + "$4"; // "$1$2{nbsp}$4";
            addRepl("([\\s\\u00A0])(do|na|za|že|po)(\\s+)([`_])",target1);
            addRepl("([\\s\\u00A0])([aiouvskz–_AIOUVSKZ])(\\s+)([A-záéěíýóúůčďňřšťž_\\*])",target1);
            addRepl("(\\()([aiouvskz–_AIOUVSKZ])(\\s+)([A-záéěíýóúůčďňřšťž_\\*])",target1);
        }

        String target2 = "$1$2" + nonBreakableSpace + "$4";
        addRepl("([\\s\\u00A0])(do|na|za|že|po)(\\s+)([`_])", target2);
        addRepl("([\\s\\u00A0])([aiouvskz–_AIOUVSKZ])(\\s+)([`_])", target2);
        addRepl("(\\()([aiouvskz–_AIOUVSKZ])(\\s+)(<<)", target2);

        // XHTML cleaning:
        try {
            replaceAllFiles(patternFile);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Replace all files according the pattern */
    private void replaceAllFiles(Pattern pattern) throws IOException {
        try (Stream<Path> paths = findFiles(pattern)) {
            paths.forEach(file -> {
                System.out.println("file: " + file);
                String citation = readFile(file);
                for (Replacement replacement : getReplacements()) {
                    citation = replacement.replace(citation);
                }
                saveFile(file, citation);
            });
        }
    }

    private String fixBody(String body) {
        throw new UnsupportedOperationException("TODO");
    }

    /** Find files by pattern */
    private Stream<Path> findFiles(Pattern pattern) throws IOException {
        return Files.walk(Paths.get(""))
                .filter(Files::isRegularFile)
                .filter((f) -> pattern.matcher(f.toString()).matches());
    }

    protected void replace(Path file, Replacement repl) {
        String citation = readFile(file);
        saveFile(file, repl.replace(citation));
    }

    protected String readFile(Path file) {
        try {
            return new String(Files.readAllBytes(file), charset);
        } catch (IOException ex) {
            throw new IllegalStateException("Reading failed: " + file, ex);
        }
    }

    protected void saveFile(Path file, String content) {
        if (debugMode) {
            return;
        }
        try {
            final byte[] bytes = content.getBytes(charset);
            Files.write(file, bytes);
        } catch (IOException ex) {
            throw new IllegalStateException("Writing failed: " + file, ex);
        }
    }

    protected void addReplOrig(int pattern, int target) {
        addRepl(
                String.valueOf((char) pattern),
                String.valueOf((char) target));
    }

    protected void addRepl(int pattern, int target) {
        addRepl(
                String.valueOf((char) pattern),
                "");
    }

    /**
     * Add an replacement
     * @param pattern The empty value is ignored
     * @param target
     */
    protected void addRepl(String pattern, String target) {
        if (pattern == null || pattern.isEmpty()) {
            return;
        }
        //System.out.println("> " + pattern + " " + target);
        repl.add(new Replacement(Pattern.compile(pattern), target));
    }

    /** Return a replacement reqeuests */
    protected List<Replacement> getReplacements() {
        return repl;
    }

    protected class Replacement {

        /** "([^ ]*l[^ ,:]*)" */
        protected final Pattern pattern;
        /** "[$1]" */
        protected final String target;

        public Replacement(Pattern pattern, String target) {
            this.pattern = pattern;
            this.target = target;
        }

        /**
         *
         * @param citation
         * @return
         */
        public String replace(String citation) {
          return pattern
                .matcher(citation)
                .replaceAll(target);
        }
    }

    public static final void main(String[] args) {
        new JReplaceAdoc().run(args);
    }

}
