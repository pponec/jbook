package net.ponec.jbook.tools;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class WebToolsTest {

    @Test
    public void testGetUrlOfServlet_value() {
        assertEquals(SourceViewer.URL_PATTERN, WebTools.getUrlOfServlet(SourceViewer.class));
    }

    @Test
    public void testGetUrlOfServlet_urlPatterns() {
        assertEquals(ElementConverterServlet.URL_PATTERN, WebTools.getUrlOfServlet(ElementConverterServlet.class));
    }

    @Test
    public void testGetUrlOfServlet_params() {
        assertEquals(
                ElementConverterServlet.URL_PATTERN + "?text=%3Chtml%2F%3E",
                WebTools.getUrlOfServlet(ElementConverterServlet.class, "text=%3Chtml%2F%3E"));
    }
}
