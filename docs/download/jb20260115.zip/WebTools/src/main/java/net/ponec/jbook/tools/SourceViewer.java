/* Copyright 2018-2026 Pavel Ponec */
package net.ponec.jbook.tools;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import org.jetbrains.annotations.NotNull;
import org.ujorm.tools.msg.MsgFormatter;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.web.ajax.JavaScriptWriter;
import static org.ujorm.tools.web.ajax.JavaScriptWriter.DEFAULT_AJAX_REQUEST_PARAM;
import org.ujorm.tools.web.json.JsonBuilder;
import org.ujorm.tools.web.request.HttpContext;
import org.ujorm.tools.xml.config.HtmlConfig;

/**
 * Source viewer
 * @author Pavel Ponec
 */
@WebServlet(SourceViewer.URL_PATTERN)
public class SourceViewer extends MyHttpServlet {

    /** A private logger */
    static final Logger LOGGER = Logger.getLogger(SourceViewer.class.getName());

    /** Max rows of the source code */
    static final int DEFAULT_SOURCE_ROWS = 13;

    /** URL pattern */
    static final String URL_PATTERN = "/sample";

    /** Source parameter */
    static final String PARAM_SRC = "src";

    /** Index parameter */
    static final String PARAM_IDX = "idx";

    /** Google pretify URL */
    static final String PRETIFY_URL = "/css/google-code-prettify/";

    /** A key to reload Prettify Javascript */
    static final String RELOAD_JS = "reload";

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param requestContext servlet request context
     */
    @Override
    protected void doGet(HttpContext requestContext) {
        final Model model = new Model(requestContext);
        final String title = getPageTitle(model);
        final CharSequence[] css =
                { PRETIFY_URL.concat("prettify.css")
                , "/css/source.css"
                , "/css/tabs.css"
        };

        try (HtmlElement html = HtmlElement.of("Java resources", requestContext.writer(), css)) {
            new JavaScriptWriter().write(html.getHead(), Map.of(RELOAD_JS, "PR.prettyPrint()"));
            html.addJavascriptLink(true, PRETIFY_URL.concat("prettify.js"));
            Element body = html.getBody().setAttribute("onload", "prettyPrint()");
            body.addHeading(1, title);

            try (Element form = body.addForm("content")) {
                createFormBody(form, model);
            }
            WebTools.createSourceFooter(body, model.getMainClass());
        }
    }

    /** Create a page title */
    private String getPageTitle(final Model model) {
        return MsgFormatter.format("Source code{} of the {} servlet class"
                , model.size() > 1 ? "s" : ""
                , model.getMainClass().getSimpleName());
    }

    /** Create a body of the form */
    private void createFormBody(final Element form, final Model model) throws IllegalStateException {
        try (Element ul = form.addUnorderedlist("nav", "nav-pills")) {
            for (int i = 0, max = model.size(); i < max; i++) {
                ul.addListItem(i == model.getIndex() ? "active" : null)
                        .addSubmitButton()
                        .setNameValue(PARAM_IDX, i)
                        .addText(model.getClass(i).getSimpleName());
            }
        }
        form.addHiddenInput(PARAM_SRC, model.getMainClass().getName());
        if (HttpServlet.class.isAssignableFrom(model.getMainClass())) {
            int maxSourceRows = SourceViewer.this.getMaxSourceRows(model.getMainClass());
            String body = WebTools.getResourceAsString(model.getSelectedClass(), maxSourceRows);
            form.addPreformatted("prettyprint lang-java linenums").addText(body);
        }
    }

    /** Get souce count from a resource bundle */
    private int getMaxSourceRowCount() {
        final Properties prop = new Properties();
        try (InputStream is = getClass().getResourceAsStream("/WebTools.properties")) {
            prop.load(is);
            int result = Integer.parseInt(prop.getProperty("maxSourceRows", "" + DEFAULT_SOURCE_ROWS));
            return result <= 0 ? Integer.MAX_VALUE : result;
        }
        catch (Exception e) {
            return DEFAULT_SOURCE_ROWS;
        }
    }

    private int getMaxSourceRows(Class<HttpServlet> mainClass) {
        int maxSources = getMaxSourceRowCount();
        if (maxSources == Integer.MAX_VALUE) {
            return maxSources;
        }
        if (Pattern.matches(".*\\.s0[1-5]_.*", mainClass.getPackage().toString())) {
            return Integer.MAX_VALUE;
        }
        return maxSources;
    }

    /** Process a POST request */
    @Override
    protected void doPost(HttpContext ctx)
            throws ServletException, IOException {
        if (DEFAULT_AJAX_REQUEST_PARAM.of(ctx, false)) {
            HtmlConfig config = (HtmlConfig) HtmlConfig.ofEmptyElement().setNewLine(" ");
            doAjax(ctx, JsonBuilder.of(ctx, config)).close();
        } else {
            doGet(ctx);
        }
    }

    /** Process an AJAX request */
    @Override
    protected JsonBuilder doAjax(HttpContext ctx, JsonBuilder json) throws IOException {
        json.write(Html.FORM, e -> createFormBody(e, new Model(ctx)));
        json.writeJsKey(RELOAD_JS); // Refresh code highlights
        return json;
    }

    /** Servlet data model */
    private static final class Model {

        /** Sample Map */
        private static final SourceMap SAMPLE_MAP = SourceMap.createInstance(false);

        /** Main servlet class */
        private final Class<HttpServlet> mainClass;

        /** Class list */
        private final List<Class> classList;

        /** An index of the class list */
        private final int index;

        public Model(@NotNull final HttpContext ctx) {
            mainClass = createClass(ctx);
            classList = SAMPLE_MAP.getClasses(mainClass);
            index = createIndex(ctx);
        }

        /** Get a resource class where a HttpServlet class is returned by default */
        @NotNull
        private Class<HttpServlet> createClass(@NotNull HttpContext ctx) {
            final String servletClass = ctx.getParameter(PARAM_SRC);
            try {
                return (Class<HttpServlet>) Class.forName(servletClass);
            } catch (ClassNotFoundException e) {
                LOGGER.log(Level.WARNING, "Missing source for the " + servletClass, e);
                return HttpServlet.class;
            }
        }

        public int createIndex(@NotNull HttpContext ctx) {
            final int index = ctx.getParameter(PARAM_IDX, 0, Integer::parseInt);
            try {
                return getClass(index) != null ? index : 0; // Check renge of the result;
            } catch (RuntimeException e) {
                LOGGER.log(Level.WARNING, "Incorrect parametr value:" + index, e);
                return 0;
            }
        }

        public Class getClass(int i) {
            return classList.get(i);
        }

        public Class getSelectedClass() {
            return classList.get(index);
        }

        public Class<HttpServlet> getMainClass() {
            return mainClass;
        }

        public int getIndex() {
            return index;
        }

        public int size() {
            return classList.size();
        }
    }
}