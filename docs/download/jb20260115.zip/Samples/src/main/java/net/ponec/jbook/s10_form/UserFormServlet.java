/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s10_form;

import java.io.IOException;
import java.util.regex.Pattern;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.web.request.HttpContext;

/** A live example inside a servlet */
@WebServlet("/user-form")
public class UserFormServlet extends HttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     * @param request HTTP servlet request
     * @param response HTTP servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (HtmlElement html = HtmlElement.niceOf("Simple user form", response,  "css/form2.css")) {
            html.getBody().addHeading(html.getTitle());
            Element form = html.getBody().addForm()
                    .setMethod(Html.V_POST)
                    .setAction(request.getRequestURI());
            for (FieldDescriptor field : getFieldDescriptors()) {
                createInputField(field, form, request);
            }
            WebTools.addFooter(html, this);
        }
    }

    /** Create an input field including label and validation message */
    private void createInputField(FieldDescriptor field, Element form, HttpServletRequest request) {
        String cssStyle = field.isSubmit() ? "submit" : "";
        String inputId = field.getName() + "Id";
        Element result = form.addDiv(cssStyle); // An envelope
        result.addLabel().setFor(inputId)
                .addText(field.getLabel());
        Element inputRow = result.addDiv();
        inputRow.addInput()
                .setType(field.isSubmit() ? "submit" : "text")
                .setName(field.getName())
                .setValue(field.getValue(request))
                .setId(inputId);

        String errorMessage = getErrorMessage(request, field);
        if (errorMessage != null) {
             inputRow.addSpan().addText(errorMessage);
        }
    }

    /** Check the POST value and return an error message of the null */
    public String getErrorMessage(HttpServletRequest request, FieldDescriptor field) {
        boolean postMethod = "post".equalsIgnoreCase(request.getMethod());
        if (postMethod) {
            final String value = field.getValue(request);
            if (value == null || value.isEmpty()) {
                return "Required field";
            } else if (!Pattern.matches(field.getRegexp(), value)) {
                return "Wrong value for: " + field.getRegexp(); // Localize it!
            }
        }
        return null;
    }

    /** Form field description data */
    private FieldDescriptor[] getFieldDescriptors() {
        FieldDescriptor[] result =
                        { new FieldDescriptor("First name", "firstname", ".{2,30}")
                        , new FieldDescriptor("Last name", "lastname", ".{2,30}")
                        , new FieldDescriptor("E-mail", "email", "[a-z0-9.-]+@[a-z0-9.-]+\\.[a-z]{2,4}")
                        , new FieldDescriptor("Phone number", "phone", "[+ 0-9]{9,15}")
                        , new FieldDescriptor("Nickname", "nick", ".{3,10}")
                        , new FieldDescriptor("", "submit", ".*", true)};
        return result;
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param request HTTP servlet request
     * @param response HTTP servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
