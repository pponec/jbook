package net.ponec.jbook.s70_database.dao;

import net.ponec.jbook.s70_database.entity.City;
import net.ponec.jbook.s70_database.entity.Hotel;
import org.ujorm.tools.sql.SqlParamBuilder;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

public class HotelDao extends AbstractDao<Hotel> {
    private static final Logger LOGGER = Logger.getLogger(HotelDao.class.getName());

    public HotelDao(Connection connection) {
        super(connection);
    }

    @Override
    public void createTable() {
        executeStatements("""
                CREATE TABLE hotel (
                    id BIGINT PRIMARY KEY AUTO_INCREMENT,
                    name VARCHAR(255) NOT NULL,
                    city_id BIGINT NOT NULL,
                    street VARCHAR(255) NOT NULL,
                    phone VARCHAR(50) NOT NULL,
                    price DECIMAL(19, 4) NOT NULL,
                    currency CHAR(3) NOT NULL DEFAULT 'USD',
                    stars SMALLINT NOT NULL,
                    is_active BOOLEAN NOT NULL DEFAULT true,
                    CONSTRAINT fk_hotel_city FOREIGN KEY (city_id) REFERENCES CITY(id),
                    CONSTRAINT chk_stars CHECK (stars BETWEEN 1 AND 5)
                );
                CREATE UNIQUE INDEX idx_hotel_city ON hotel(name, city_id);
                """);
    }

    public List<Hotel> find(String hotel, String city, int limit, int offset, boolean active) {
        String sql = """
                    SELECT hotel.id
                         , hotel.name
                         , hotel.street
                         , hotel.phone
                         , hotel.price
                         , hotel.currency
                         , hotel.stars
                         , hotel.is_active
                         , city.name as cityName
                    FROM hotel
                    JOIN city ON city.id = hotel.city_id
                    WHERE is_active = :active %s %s
                    ORDER BY name, cityName
                    LIMIT :limit
                    OFFSET :offset;
                    """.formatted(
                            hotel.isEmpty() ? "" : "AND hotel.name LIKE :hotel",
                            city.isEmpty()  ? "" : "AND city.name  LIKE :city");
        try (SqlParamBuilder builder = builder()) {
            return builder.sql(sql)
                    .bind("active", active)
                    .bind(!hotel.isEmpty(), "hotel", escape(hotel) + "%")
                    .bind(!city.isEmpty(), "city", escape(city) + "%")
                    .bind("limit", limit)
                    .bind("offset", offset)
                    .streamMap(rs -> map(rs, "cityName"))
                    .toList();
        }
    }

    @Override
    public Optional<Hotel> findById(long id) {
        String sql = """
                    SELECT id, name, city_id, street, phone, price, currency, stars, is_active
                    FROM hotel
                    WHERE id = :id
                    """;
        try (SqlParamBuilder builder = builder()) {
            return builder.sql(sql)
                    .bind("id", id)
                    .streamMap(rs -> map(rs, null))
                    .findFirst();
        }
    }

    @Override
    public long insert(Hotel entity) {
        String sql = """
                        INSERT INTO hotel
                        ( name, city_id, street, phone, price, currency, stars ) VALUES
                        ( :name, :cityId, :street, :phone, :price, :currency, :stars )
                        """;
        try (SqlParamBuilder builder = builder()) {
            LOGGER.fine("Hotel: " + entity);
            builder.sql(sql)
                    .bind("name", entity.getName())
                    .bind("cityId", entity.getCity().getId())
                    .bind("street", entity.getStreet())
                    .bind("phone", entity.getPhone())
                    .bind("price", entity.getPrice())
                    .bind("currency", entity.getCurrency())
                    .bind("stars", entity.getStars())
                    .executeInsert();
            return getLastInsertedId(builder);
        }
    }

    public boolean hasTables() {
        try {
            String requiredTableName = "hotel";
            DatabaseMetaData metaData = dbConnection.getMetaData();
            try (ResultSet resultSet = metaData.getTables(null, null, requiredTableName, null)) {
                return resultSet.next();
            }
        } catch (SQLException ex) {
            throw new org.ujorm.tools.sql.SQLException(ex);
        }
    }

    /** Map a ResultSet to Hotel
     * @param rs ResultSet
     * @param cityColumn Optional name of the database city column name.
     * @return New instance of the Hotel entity.
     */
    private Hotel map(ResultSet rs, String cityColumn) throws java.sql.SQLException {
        Hotel result = new Hotel();
        result.setId(rs.getLong("id"));
        result.setName(rs.getString("name"));
        result.setStreet(rs.getString("street"));
        result.setPhone(rs.getString("phone"));
        result.setPrice(rs.getBigDecimal("price"));
        result.setCurrency(rs.getString("currency"));
        result.setStars(rs.getShort("stars"));
        result.setActive(rs.getBoolean("is_active"));

        if (cityColumn != null) {
            result.setCity(new City());
            result.getCity().setName(rs.getString(cityColumn));
        }
        return result;
    }
}


