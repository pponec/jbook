/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s60_ajax;

import net.ponec.jbook.s50_gomoku.*;
import java.util.Optional;


/**
 * Advanced game strategy for GoMoku.
 * This service implements a heuristic approach to find the best move by
 * evaluating threats and opportunities across the entire board.
 * @author Google Gemini
 */
public class FineBoardService extends BoardService {

    @Override
    public String getTitle() {
        return "Go-moku (AI Heuristic Strategy)";
    }

    /**
     * Determines the next optimal point for the machine move.
     * The strategy follows these priorities:
     * 1. Winning: Complete a row of 5 stones.
     * 2. Blocking: Stop the opponent from completing a row of 5 stones.
     * 3. Developing: Create or block rows of 4, then 3, then 2 stones.
     * * @param board The current state of the game board.
     * @return An Optional containing the best point, or empty if no move is possible.
     */
    @Override
    protected Optional<BoardPoint> getNextPoint(final BoardModel board) {
        final StoneEnum machineStone = board.getOpponentStone(board.getStone(board.getLastMove()));
        final StoneEnum opponentStone = board.getStone(board.getLastMove());

        // Priority 1: Check if the machine can win in this move (4 stones already in line)
        Optional<BoardPoint> winningMove = findBestMoveForStone(board, machineStone, 4);
        if (winningMove.isPresent()) return winningMove;

        // Priority 2: Check if the opponent can win in their next move and block them
        Optional<BoardPoint> blockWinningMove = findBestMoveForStone(board, opponentStone, 4);
        if (blockWinningMove.isPresent()) return blockWinningMove;

        // Priority 3: Progressive strategy - look for rows of 3, 2, or 1 to build or block
        for (int count = 3; count >= 1; count--) {
            // Try to build own advantage
            Optional<BoardPoint> attackMove = findBestMoveForStone(board, machineStone, count);
            if (attackMove.isPresent()) return attackMove;

            // Try to block opponent's potential advantage
            Optional<BoardPoint> defenseMove = findBestMoveForStone(board, opponentStone, count);
            if (defenseMove.isPresent()) return defenseMove;
        }

        // Fallback: Use the basic strategy from the parent class (random move near the last move)
        return super.getNextPoint(board);
    }

    /**
     * Check if the given point is within the board boundaries.
     * * @param board The game board.
     * @param point The point to check.
     * @return True if the point is inside the board.
     */
    protected boolean isWithin(BoardModel board, BoardPoint point) {
        return point.getX() >= 0
                && point.getY() >= 0
                && point.getX() < board.getWidth()
                && point.getY() < board.getHeight();
    }

    /**
     * Searches the entire board to find a sequence of stones of a specific length
     * that can be extended by a move into an empty space.
     * * @param board The game board.
     * @param stone The type of stone to look for.
     * @param requiredCount The number of stones already in a row.
     * @return An Optional with the empty BoardPoint next to the sequence.
     */
    private Optional<BoardPoint> findBestMoveForStone(BoardModel board, StoneEnum stone, int requiredCount) {
        for (int x = 0; x < board.getWidth(); x++) {
            for (int y = 0; y < board.getHeight(); y++) {
                BoardPoint current = new BoardPoint(x, y);

                if (board.getStone(current) == stone) {
                    for (DirectionEnum dir : DirectionEnum.values()) {
                        BoardPoint[] borders = getDirectionBorderFromPoint(board, current, dir, stone, requiredCount);
                        if (borders != null) {
                            for (BoardPoint border : borders) {
                                if (isWithin(board, border) && board.hasStone(border, StoneEnum.NO_STONE)) {
                                    return Optional.of(border);
                                }
                            }
                        }
                    }
                }
            }
        }
        return Optional.empty();
    }

    /**
     * A generalized version of the border detection that starts from any given point.
     * It scans in both directions of an axis to count the total length of a stone sequence.
     * * @param board The game board.
     * @param point The starting point for the scan.
     * @param direction The direction (axis) to check.
     * @param stone The stone type to match.
     * @param requiredCount The minimum length of the sequence to trigger a match.
     * @return An array of two points representing the immediate empty spaces at the ends of the sequence.
     */
    protected BoardPoint[] getDirectionBorderFromPoint(BoardModel board, BoardPoint point, DirectionEnum direction, StoneEnum stone, int requiredCount) {
        final BoardPoint firstPoint = point.clonePoint();
        final BoardPoint lastPoint = point.clonePoint();

        int count = 0;
        // Move to the edge of the continuous line in the forward direction
        while (board.hasStone(firstPoint, stone)) {
            direction.move(firstPoint, true);
            count++;
        }
        // Move to the edge of the continuous line in the backward direction
        while (board.hasStone(lastPoint, stone)) {
            direction.move(lastPoint, false);
            count++;
        }

        // Subtract 1 because the starting 'point' was counted in both loops
        if ((count - 1) >= requiredCount) {
            return new BoardPoint[]{firstPoint, lastPoint};
        }
        return null;
    }
}