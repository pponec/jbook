/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s01_hello;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.HtmlElement;

/** An extended servlet implementation based on the Element model */
@WebServlet("/hello-element")
public class HelloWorldElement extends HttpServlet {

    /** Handles the HTTP GET request */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (HtmlElement html = HtmlElement.niceOf(response, "css/world.css")) {
            html.getBody().addHeading("Hello, World! (Element)");
            WebTools.addFooter(html, this);
        }
    }
}
