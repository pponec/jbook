package net.ponec.jbook.s70_database.dao;

import org.ujorm.tools.sql.SqlParamBuilder;

import java.sql.Connection;
import java.util.Optional;

/** Common DAO object
 * @param <E> Entity type
 */
public abstract class AbstractDao<E> {

   protected final Connection dbConnection;

    public AbstractDao(Connection dbConnection) {
        this.dbConnection = dbConnection;
    }

    public abstract void createTable();

    /** Find an entity by the name */
    public abstract Optional<E> findById(long id);

    /** Insert the entity to the database and return the new identifier */
    public abstract long insert(E entity);

    /** Supports many DDL statements */
    public void executeStatements(String sqlStatement) {
        try (SqlParamBuilder builder = builder()) {
            for (String sql : sqlStatement.split(";")) {
                if (!sql.trim().isEmpty()) {
                    builder.sql(sql).execute();
                }
            }
        }
    }

    /** Return the ID of the last inserted row */
    protected long getLastInsertedId(SqlParamBuilder builder) {
            return builder.generatedKeys(rs -> rs.getLong(1))
                    .findFirst().get();
    }

    /** Create builder */
    protected SqlParamBuilder builder() {
        return new SqlParamBuilder(dbConnection);
    }

    /** Escape special characters for the LIKE operator */
    protected String escape(String value) {
        return value == null ? null : value
                .replace("\\", "\\\\")
                .replace("%", "\\%")
                .replace("_", "\\_");
    }

}
