/* Copyright 2018-2026 Pavel Ponec, https://jbook.ponec.net */
package net.ponec.jbook.s20_board;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import net.ponec.jbook.tools.MyHttpServlet;
import net.ponec.jbook.tools.WebTools;
import org.ujorm.tools.web.Element;
import org.ujorm.tools.web.Html;
import org.ujorm.tools.web.HtmlElement;
import org.ujorm.tools.web.request.HttpContext;

/** Drawing board */
@WebServlet("/board")
public class BoardServlet extends MyHttpServlet {

    /** Logger */
    private static final Logger LOGGER = Logger.getLogger(BoardServlet.class.getName());

    /** Hidden data input */
    public static final String BOARD_PARAM = "board";

    /** Cell prefix */
    public static final String BUTTON_PARAM = "b";

    /**
     * Handles the HTTP <code>GET</code> or <code>POST</code> method.
     * @param ctx A servlet request context
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpContext ctx) {
        try (HtmlElement html = HtmlElement.niceOf("Painting board", ctx, "css/paint.css")) {
            SimpleBoardModel boardModel = createBoardModel(ctx);
            html.getBody().addHeading(html.getTitle());
            Element form = createFormElement(html.getBody(), boardModel);
            boardModel.getErrorMessage().ifPresent(msg -> form.addSpan("msg").addText(msg)); // Print an error message
            createMainBoard(form, boardModel);
            createResetButton(form, "New picture");
            WebTools.addFooter(html, this);
        }
    }

    /** Create a board model from input parameters */
    private SimpleBoardModel createBoardModel(HttpContext ctx) {
        int width = 21;
        int height = 9;
        SimpleBoardModel result;

        try {
            result = new SimpleBoardModel(width, height, ctx.getParameter(BoardServlet.BOARD_PARAM));
            int buttonValue = ctx.getParameter(BUTTON_PARAM, -1, Integer::parseInt);
            if (buttonValue >= 0) {
                result.flipStone(buttonValue);
            }
        } catch (RuntimeException e) {
            String msg = "An error processing parameters";
            LOGGER.log(Level.WARNING, msg, e);
            result = new SimpleBoardModel(width, height, null);
            result.setErrorMessage(msg);
        }
        return result;
    }

    /** Create a form element including hidden fields */
    private Element createFormElement(final Element parent, SimpleBoardModel board) {
        Element result = parent.addForm()
                .setMethod(Html.V_GET);
        result.addInput()
                .setType(Html.V_HIDDEN)
                .setName(BOARD_PARAM)
                .setValue(board.exportBoard());
        return result;
    }

    /** Create a clear button element */
    private void createResetButton(Element parent, String title) {
        parent.addAnchor(WebTools.getUrlOfServlet(getClass()), "btn", "btn-primary").addText(title);
    }

    /** Create a boad element */
    protected void createMainBoard(Element parent, SimpleBoardModel board) {
        final Element table = parent.addTable("board");
        for (int y = 0; y < board.getHeight(); y++) {
            final Element rowElement = table.addTableRow();
            for (int x = 0; x < board.getWidth(); x++) {
                rowElement.addTableDetail(board.hasStone(x, y) ? "s" : null)
                        .addSubmitButton()
                        .setName(BUTTON_PARAM)
                        .setValue(y * board.getWidth() + x)
                        .addText("");
            }
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     * @param ctx Servlet request context
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpContext ctx)
            throws ServletException, IOException {
        doGet(ctx);
    }
}
